#!/bin/bash
# Non-interactive version of restoration script for ETAP installer
# Restores raw .img files from /extra/os/base-images
# Usage: ./restoration-script-noninteractive.sh <target_disk>

set -euo pipefail

# Check if target disk is provided
if [ $# -ne 1 ]; then
    echo "Usage: $0 <target_disk>"
    echo "Example: $0 /dev/sdb"
    exit 1
fi

TARGET_DISK="$1"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
BACKUP_DIR="/extra/os/base-images"

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Banner
print_header "4-Partition Restoration System (Raw Images - Non-Interactive)"
echo ""
echo "Target disk: $TARGET_DISK"
echo "Backup location: $BACKUP_DIR"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Validate target disk
if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

# Safety check: Exclude sda disk to prevent accidental system damage
if [[ "$TARGET_DISK" == "/dev/sda"* ]]; then
    print_error "SAFETY ERROR: sda disk is excluded for safety!"
    print_error "sda is typically the system disk and should not be used for restoration."
    print_error "Supported disks: sdb, sdc, nvme*"
    print_error ""
    print_error "If you really need to restore to sda, use the interactive restoration script instead."
    exit 1
fi

print_info "Selected disk: $TARGET_DISK (safe disk confirmed)"

# Check if backup directory exists
if [ ! -d "$BACKUP_DIR" ]; then
    print_error "Backup directory $BACKUP_DIR not found"
    exit 1
fi

# Check for required backup files (now .img instead of .img.gz)
REQUIRED_FILES=("efi.img" "root.img" "var.img" "home.img")
MISSING_FILES=()

print_info "Checking for required backup files..."
for file in "${REQUIRED_FILES[@]}"; do
    full_path="$BACKUP_DIR/$file"
    if [ ! -f "$full_path" ]; then
        MISSING_FILES+=("$file")
        print_error "Missing: $full_path"
    else
        size=$(du -h "$full_path" | cut -f1)
        print_info "Found: $file ($size)"
    fi
done

if [ ${#MISSING_FILES[@]} -gt 0 ]; then
    print_error "Cannot proceed! Missing ${#MISSING_FILES[@]} required backup files:"
    for file in "${MISSING_FILES[@]}"; do
        echo "  ❌ $BACKUP_DIR/$file"
    done
    echo ""
    print_error "Please ensure all required image files are present before running restoration."
    exit 1
fi

print_success "All ${#REQUIRED_FILES[@]} required backup files found"
echo ""

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Unmount any mounted partitions from target disk
print_header "Unmounting Target Disk Partitions"
umount ${TARGET_DISK}* 2>/dev/null || true
swapoff ${TARGET_DISK}* 2>/dev/null || true
print_success "Target disk unmounted"
echo ""

# Wipe disk and create fresh partition table
print_header "Wiping Disk and Creating Partition Table"
print_info "Wiping partition table..."
wipefs -af "$TARGET_DISK" 2>/dev/null || true
dd if=/dev/zero of="$TARGET_DISK" bs=1M count=100 conv=fsync 2>/dev/null || true

print_info "Creating GPT partition table..."
parted -s "$TARGET_DISK" mklabel gpt
print_success "GPT partition table created"
echo ""

# Define fixed partition sizes (in MiB) - Updated sizes
print_header "Partition Layout Configuration"
EFI_SIZE=1536        # 1.5GB for EFI
ROOT_SIZE=30720      # 30GB for Root (increased from 20GB)
VAR_SIZE=15360       # 15GB for Var (increased from 10GB)
HOME_SIZE=5120       # 5GB for Home
VARLOG_SIZE=5120     # 5GB for /var/log
VARTMP_SIZE=2048     # 2GB for /var/tmp
VARAUDIT_SIZE=5120   # 5GB for /var/log/audit
EMBEDD_SIZE=2048     # 2GB for /embedd_d
APP_SIZE=5120        # 5GB for /app (reduced from 10GB)
TMP_SIZE=3072        # 3GB for /tmp
# EXTRA will use remaining space

print_info "Partition 1 (EFI): ${EFI_SIZE}MB (1.5GB)"
print_info "Partition 2 (Root /): ${ROOT_SIZE}MB (30GB) - Image ~20GB, will be expanded"
print_info "Partition 3 (Home): ${HOME_SIZE}MB (5GB)"
print_info "Partition 4 (Var): ${VAR_SIZE}MB (15GB) - Image ~10GB, will be expanded"
print_info "Partition 5 (/var/log): ${VARLOG_SIZE}MB (5GB)"
print_info "Partition 6 (/var/tmp): ${VARTMP_SIZE}MB (2GB)"
print_info "Partition 7 (/var/log/audit): ${VARAUDIT_SIZE}MB (5GB)"
print_info "Partition 8 (/embedd_d): ${EMBEDD_SIZE}MB (2GB)"
print_info "Partition 9 (/app): ${APP_SIZE}MB (5GB)"
print_info "Partition 10 (/tmp): ${TMP_SIZE}MB (3GB)"
print_info "Partition 11 (/extra): Remaining space"
echo ""

# Calculate total disk size needed
TOTAL_FIXED=$((EFI_SIZE + ROOT_SIZE + VAR_SIZE + HOME_SIZE + VARLOG_SIZE + VARTMP_SIZE + VARAUDIT_SIZE + EMBEDD_SIZE + APP_SIZE + TMP_SIZE))
TOTAL_FIXED_GB=$((TOTAL_FIXED / 1024))
print_info "Total fixed partitions: ${TOTAL_FIXED}MB (${TOTAL_FIXED_GB}GB)"

# Get target disk size
disk_size_bytes=$(blockdev --getsize64 "$TARGET_DISK")
disk_size_mb=$((disk_size_bytes / 1024 / 1024))
disk_size_gb=$((disk_size_mb / 1024))
print_info "Target disk size: ${disk_size_mb}MB (${disk_size_gb}GB)"

# Check if disk is large enough
if [ $disk_size_mb -lt $TOTAL_FIXED ]; then
    print_error "Disk is too small! Need at least ${TOTAL_FIXED_GB}GB but disk is ${disk_size_gb}GB"
    exit 1
fi

remaining=$((disk_size_mb - TOTAL_FIXED - 2))  # Leave 2MB margin
remaining_gb=$((remaining / 1024))
print_info "Space for /extra partition: ${remaining}MB (${remaining_gb}GB)"
echo ""

# Read UUID mappings if available
print_header "Reading UUID Mappings"
declare -A PARTITION_UUIDS
declare -A PARTITION_FSTYPES
declare -A PARTITION_PARTUUIDS

if [ -f "$BACKUP_DIR/uuid_mapping.txt" ]; then
    while IFS=':' read -r part_num uuid fstype size_mb partuuid; do
        # Skip empty lines and comments
        [[ -z "$part_num" || "$part_num" =~ ^# ]] && continue
        
        PARTITION_UUIDS[$part_num]=$uuid
        PARTITION_FSTYPES[$part_num]=$fstype
        PARTITION_PARTUUIDS[$part_num]=$partuuid
        print_info "Partition $part_num: UUID=$uuid, FS=$fstype"
    done < "$BACKUP_DIR/uuid_mapping.txt"
else
    print_warn "uuid_mapping.txt not found, UUIDs will be auto-generated"
fi
echo ""

# Create partitions with fixed sizes and proper alignment
print_header "Creating Partitions"

# Use parted's optimal alignment by specifying percentages and letting parted handle alignment
print_info "Creating partition 1 (EFI): 1MiB - 1537MiB (1.5GB)"
parted -s "$TARGET_DISK" mkpart primary fat32 1MiB 1537MiB 2>/dev/null
parted -s "$TARGET_DISK" set 1 esp on 2>/dev/null

print_info "Creating partition 2 (Root /): 1537MiB - 32257MiB (30GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 1537MiB 32257MiB 2>/dev/null

print_info "Creating partition 3 (Home): 32257MiB - 37377MiB (5GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 32257MiB 37377MiB 2>/dev/null

print_info "Creating partition 4 (Var): 37377MiB - 52737MiB (15GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 37377MiB 52737MiB 2>/dev/null

print_info "Creating partition 5 (/var/log): 52737MiB - 57857MiB (5GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 52737MiB 57857MiB 2>/dev/null

print_info "Creating partition 6 (/var/tmp): 57857MiB - 59905MiB (2GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 57857MiB 59905MiB 2>/dev/null

print_info "Creating partition 7 (/var/log/audit): 59905MiB - 65025MiB (5GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 59905MiB 65025MiB 2>/dev/null

print_info "Creating partition 8 (/embedd_d): 65025MiB - 67073MiB (2GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 65025MiB 67073MiB 2>/dev/null

print_info "Creating partition 9 (/app): 67073MiB - 72193MiB (5GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 67073MiB 72193MiB 2>/dev/null

print_info "Creating partition 10 (/tmp): 72193MiB - 75265MiB (3GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 72193MiB 75265MiB 2>/dev/null

# Calculate remaining space for last partition
remaining_start=75265
remaining_end=$((disk_size_mb - 10))  # Leave 10MB margin
remaining_size=$((remaining_end - remaining_start))
remaining_gb=$((remaining_size / 1024))

print_info "Creating partition 11 (/extra): ${remaining_start}MiB - ${remaining_end}MiB (${remaining_size}MB = ${remaining_gb}GB remaining)"
parted -s "$TARGET_DISK" mkpart primary ext4 ${remaining_start}MiB ${remaining_end}MiB 2>/dev/null

print_success "All partitions created"
echo ""

# Wait for kernel to update partition table
print_info "Waiting for partition table to update..."
sleep 2
partprobe "$TARGET_DISK" 2>/dev/null || true
sleep 2
echo ""

# Restore images for main 4 partitions
restore_partition_image() {
    local part_num=$1
    local label=$2
    local partition=$(get_partition_name $part_num)
    local image_file="$BACKUP_DIR/${label}.img"
    
    if [ ! -f "$image_file" ]; then
        print_error "CRITICAL: Image file $image_file not found!"
        print_error "This should not happen - file check should have caught this earlier."
        return 1
    fi
    
    if [ ! -b "$partition" ]; then
        print_error "Partition $partition not found"
        return 1
    fi
    
    print_header "Restoring: $label (Partition $part_num)"
    print_info "Image: $image_file"
    print_info "Target: $partition"
    print_info "Image size: $(du -h "$image_file" | cut -f1)"
    
    # Get partition size
    local part_size=$(blockdev --getsize64 "$partition" 2>/dev/null || echo "0")
    local part_size_mb=$((part_size / 1024 / 1024))
    print_info "Partition size: ${part_size_mb}MB"
    
    # Get image size
    local image_size=$(stat -c%s "$image_file")
    local image_mb=$((image_size / 1024 / 1024))
    print_info "Image file size: ${image_mb}MB"
    
    # Check if partition is large enough
    if [ "$image_size" -gt "$part_size" ]; then
        print_error "Partition too small! Need ${image_mb}MB but partition is ${part_size_mb}MB"
        print_warn "Continuing anyway - data may be truncated!"
    fi
    
    # Write raw image directly to partition
    print_info "Writing raw image to partition $label (this may take a while)..."
    
    # Use pv for progress if available
    if command -v pv &> /dev/null; then
        pv -N "$label" -pterb "$image_file" | \
            dd of="$partition" bs=16M conv=sync,noerror oflag=sync status=none iflag=fullblock
    else
        dd if="$image_file" of="$partition" bs=16M conv=sync,noerror oflag=sync status=progress iflag=fullblock
    fi
    
    local dd_exit=$?
    sync
    
    if [ $dd_exit -eq 0 ]; then
        print_success "Image restored: $label"
        
        # Format the partition immediately after restoration
        local fstype=""
        case $part_num in
            1) fstype=${PARTITION_FSTYPES[1]:-vfat} ;;
            2) fstype=${PARTITION_FSTYPES[2]:-ext4} ;;
            3) fstype=${PARTITION_FSTYPES[3]:-ext4} ;;
            4) fstype=${PARTITION_FSTYPES[4]:-ext4} ;;
        esac
        
        print_info "Formatting partition $part_num ($partition) as $fstype"
        case $fstype in
            vfat|fat32)
                mkfs.vfat -F 32 "$partition" > /dev/null 2>&1 || true
                ;;
            ext4)
                mkfs.ext4 -F "$partition" > /dev/null 2>&1 || true
                ;;
            ext3)
                mkfs.ext3 -F "$partition" > /dev/null 2>&1 || true
                ;;
            *)
                print_warn "Unknown filesystem type: $fstype, using ext4"
                mkfs.ext4 -F "$partition" > /dev/null 2>&1 || true
                ;;
        esac
        print_success "Formatted $partition as $fstype"
    else
        print_warn "Image restoration completed with warnings for: $label"
    fi
    
    echo ""
}

# Restore main 4 partitions
print_header "Restoring Partition Images"
echo ""

# Track restoration success
RESTORATION_FAILED=false

if ! restore_partition_image 1 "efi"; then
    print_error "Failed to restore EFI partition"
    RESTORATION_FAILED=true
fi

if ! restore_partition_image 2 "root"; then
    print_error "Failed to restore Root partition"
    RESTORATION_FAILED=true
fi

if ! restore_partition_image 3 "home"; then
    print_error "Failed to restore Home partition"
    RESTORATION_FAILED=true
fi

if ! restore_partition_image 4 "var"; then
    print_error "Failed to restore Var partition"
    RESTORATION_FAILED=true
fi

# Check if any restoration failed
if [ "$RESTORATION_FAILED" = true ]; then
    print_error "One or more partition restorations failed!"
    print_error "Cannot continue with installation."
    exit 1
fi

print_success "All partition images restored successfully!"
echo ""

# Expand filesystems to fill larger partitions
print_header "Expanding Filesystems to Fill Partitions"
echo ""

expand_filesystem() {
    local part_num=$1
    local label=$2
    local partition=$(get_partition_name $part_num)
    local fstype=${PARTITION_FSTYPES[$part_num]:-ext4}
    
    if [ ! -b "$partition" ]; then
        print_warn "Partition $partition not found, skipping expansion"
        return
    fi
    
    print_info "Expanding $label ($partition, $fstype)..."
    
    case $fstype in
        ext4|ext3|ext2)
            # First check and repair filesystem if needed
            e2fsck -fy "$partition" > /dev/null 2>&1 || true
            # Resize filesystem to fill partition
            resize2fs "$partition" > /dev/null 2>&1
            if [ $? -eq 0 ]; then
                print_success "Expanded $label filesystem to fill partition"
            else
                print_warn "Could not expand $label filesystem (may already be correct size)"
            fi
            ;;
        xfs)
            # XFS needs to be mounted to expand
            TEMP_MOUNT="/mnt/temp_xfs_${part_num}"
            mkdir -p "$TEMP_MOUNT"
            if mount "$partition" "$TEMP_MOUNT" 2>/dev/null; then
                xfs_growfs "$TEMP_MOUNT" > /dev/null 2>&1
                if [ $? -eq 0 ]; then
                    print_success "Expanded $label filesystem to fill partition"
                else
                    print_warn "Could not expand $label filesystem"
                fi
                umount "$TEMP_MOUNT"
            else
                print_warn "Could not mount $partition for XFS expansion"
            fi
            rmdir "$TEMP_MOUNT" 2>/dev/null || true
            ;;
        vfat|fat32)
            # FAT filesystems don't need expansion in the same way
            print_info "$label (FAT) doesn't need expansion"
            ;;
        *)
            print_warn "Unknown filesystem type for expansion: $fstype"
            ;;
    esac
}

# Expand Root (20GB image -> 30GB partition)
if [ -f "$BACKUP_DIR/root.img" ]; then
    expand_filesystem 2 "Root"
fi

# Expand Var (10GB image -> 15GB partition)
if [ -f "$BACKUP_DIR/var.img" ]; then
    expand_filesystem 4 "Var"
fi

print_success "Filesystem expansion complete"
echo ""

# Format additional partitions (5-11)
print_header "Formatting Additional Partitions"

# Map partition numbers to their filesystems
declare -A PART_FS_MAP
PART_FS_MAP[5]="ext4"   # /var/log
PART_FS_MAP[6]="ext4"   # /var/tmp
PART_FS_MAP[7]="ext4"   # /var/log/audit
PART_FS_MAP[8]="ext4"   # /embedd_d
PART_FS_MAP[9]="ext4"   # /app
PART_FS_MAP[10]="ext4"  # /tmp
PART_FS_MAP[11]="ext4"  # /extra

for part_num in {5..11}; do
    partition=$(get_partition_name $part_num)
    fstype=${PART_FS_MAP[$part_num]}
    
    if [ ! -b "$partition" ]; then
        print_warn "Partition $partition not found, skipping"
        continue
    fi
    
    print_info "Formatting partition $part_num ($partition) as $fstype"
    
    case $fstype in
        ext4)
            mkfs.ext4 -F "$partition" > /dev/null 2>&1
            ;;
        ext3)
            mkfs.ext3 -F "$partition" > /dev/null 2>&1
            ;;
        xfs)
            mkfs.xfs -f "$partition" > /dev/null 2>&1
            ;;
        btrfs)
            mkfs.btrfs -f "$partition" > /dev/null 2>&1
            ;;
        vfat|fat32)
            mkfs.vfat -F 32 "$partition" > /dev/null 2>&1
            ;;
        *)
            print_warn "Unknown filesystem type: $fstype, using ext4"
            mkfs.ext4 -F "$partition" > /dev/null 2>&1
            ;;
    esac
    
    print_success "Formatted $partition as $fstype"
done
echo ""

# Set UUIDs for all partitions (read from backup)
print_header "Setting UUIDs from Backup"

# First, check if we have UUID mapping file
if [ ! -f "$BACKUP_DIR/uuid_mapping.txt" ]; then
    print_warn "uuid_mapping.txt not found, UUIDs will be auto-generated"
else
    # Set UUIDs for all partitions
    for part_num in {1..11}; do
        partition=$(get_partition_name $part_num)
        uuid=${PARTITION_UUIDS[$part_num]}
        fstype=${PARTITION_FSTYPES[$part_num]}
        
        if [ ! -b "$partition" ]; then
            continue
        fi
        
        if [ -z "$uuid" ] || [ "$uuid" = "unknown" ]; then
            print_warn "No UUID for partition $part_num, will use auto-generated UUID"
            continue
        fi
        
        print_info "Setting UUID for partition $part_num ($partition): $uuid"
        
        case $fstype in
            ext4|ext3|ext2)
                tune2fs -U "$uuid" "$partition" > /dev/null 2>&1 || print_warn "Failed to set UUID for $partition"
                ;;
            xfs)
                xfs_admin -U "$uuid" "$partition" > /dev/null 2>&1 || print_warn "Failed to set UUID for $partition"
                ;;
            vfat|fat32)
                # For EFI/FAT partitions, try multiple methods to set the original UUID from backup
                if [ "$part_num" = "1" ]; then
                    # EFI partition - try harder to set the UUID from backup
                    print_info "Attempting to set EFI UUID to backup value: $uuid"
                    
                    # Method 1: Try mlabel with different formats
                    fat_uuid=$(echo "$uuid" | tr -d '-' | cut -c1-8 | tr '[:lower:]' '[:upper:]')
                    if mlabel -i "$partition" -N "${fat_uuid}" > /dev/null 2>&1; then
                        print_success "EFI partition UUID set to original backup UUID: $uuid"
                    else
                        # Method 2: Try with fatlabel
                        if command -v fatlabel &> /dev/null; then
                            if fatlabel "$partition" "${fat_uuid}" > /dev/null 2>&1; then
                                print_success "EFI partition UUID set using fatlabel: $uuid"
                            else
                                # Method 3: Reformat with specific UUID
                                print_info "Reformatting EFI partition to set specific UUID..."
                                if mkfs.vfat -F 32 -i "${fat_uuid}" "$partition" > /dev/null 2>&1; then
                                    print_success "EFI partition reformatted with backup UUID: $uuid"
                                else
                                    print_warn "All methods failed - EFI will use auto-generated UUID"
                                    print_warn "This may cause boot issues - manual fstab editing may be required"
                                fi
                            fi
                        else
                            # Method 3: Reformat with specific UUID (fallback)
                            print_info "Reformatting EFI partition to set specific UUID..."
                            if mkfs.vfat -F 32 -i "${fat_uuid}" "$partition" > /dev/null 2>&1; then
                                print_success "EFI partition reformatted with backup UUID: $uuid"
                            else
                                print_warn "All methods failed - EFI will use auto-generated UUID"
                                print_warn "This may cause boot issues - manual fstab editing may be required"
                            fi
                        fi
                    fi
                else
                    # Try to set UUID for non-EFI FAT partitions
                    fat_uuid=$(echo "$uuid" | tr -d '-' | cut -c1-8 | tr '[:lower:]' '[:upper:]')
                    if mlabel -i "$partition" -N "${fat_uuid}" > /dev/null 2>&1; then
                        print_success "Set UUID for FAT partition $part_num"
                    else
                        print_info "FAT partition $part_num will use auto-generated UUID"
                    fi
                fi
                ;;
            btrfs)
                btrfstune -U "$uuid" "$partition" > /dev/null 2>&1 || print_warn "Failed to set UUID for $partition"
                ;;
            *)
                print_warn "Cannot set UUID for filesystem type: $fstype"
                ;;
        esac
    done
fi

print_success "UUIDs configured"
echo ""

# Mount root partition and setup system
print_header "Setting Up Root Partition"
MOUNT_POINT="/mnt/restore_root"
mkdir -p "$MOUNT_POINT"
ROOT_PART=$(get_partition_name 2)

if mount "$ROOT_PART" "$MOUNT_POINT" 2>/dev/null; then
    print_success "Mounted root partition at $MOUNT_POINT"
    
    # Create mount point directories in root partition based on fstab
    print_info "Creating mount point directories..."
    
    # Standard mount points from your fstab
    MOUNT_DIRS=(
        "boot/efi"
        "home"
        "var"
        "var/log"
        "var/tmp"
        "var/log/audit"
        "embedd_d"
        "app"
        "tmp"
        "extra"
    )
    
    for dir in "${MOUNT_DIRS[@]}"; do
        mkdir -p "$MOUNT_POINT/$dir"
        print_info "Created: /$dir"
    done
    
    # Set proper permissions for sensitive directories
    chmod 1777 "$MOUNT_POINT/tmp" 2>/dev/null || true
    chmod 1777 "$MOUNT_POINT/var/tmp" 2>/dev/null || true
    chmod 755 "$MOUNT_POINT/var/log" 2>/dev/null || true
    chmod 700 "$MOUNT_POINT/var/log/audit" 2>/dev/null || true
    
    print_success "Mount point directories created"
    echo ""
    
    # Copy fstab from backup (UUIDs should match since we try to preserve them)
    if [ -f "$BACKUP_DIR/fstab.backup" ]; then
        mkdir -p "$MOUNT_POINT/etc"
        cp "$BACKUP_DIR/fstab.backup" "$MOUNT_POINT/etc/fstab"
        print_success "Installed fstab from backup"
        
        # Verify EFI UUID matches fstab
        EFI_PART=$(get_partition_name 1)
        if [ -b "$EFI_PART" ]; then
            current_efi_uuid=$(blkid -s UUID -o value "$EFI_PART" 2>/dev/null || echo "")
            fstab_efi_uuid=$(grep "/boot/efi" "$MOUNT_POINT/etc/fstab" 2>/dev/null | grep -o "UUID=[A-Fa-f0-9-]*" | cut -d= -f2 || echo "")
            
            if [ -n "$current_efi_uuid" ] && [ -n "$fstab_efi_uuid" ]; then
                if [ "$current_efi_uuid" = "$fstab_efi_uuid" ]; then
                    print_success "EFI UUID matches fstab: $current_efi_uuid"
                else
                    print_warn "EFI UUID mismatch!"
                    print_warn "Partition UUID: $current_efi_uuid"
                    print_warn "fstab UUID: $fstab_efi_uuid"
                    print_warn "System may not boot properly - manual fstab editing required"
                fi
            fi
        fi
    else
        print_warn "fstab.backup not found, skipping fstab installation"
    fi
    
    echo ""
    umount "$MOUNT_POINT"
    print_success "Unmounted root partition"
else
    print_warn "Could not mount root partition to setup directories"
fi

rmdir "$MOUNT_POINT" 2>/dev/null || true
echo ""

# Final summary
print_header "Restoration Complete"
print_success "All partitions have been restored successfully!"
echo ""
print_info "Restored partitions:"
lsblk "$TARGET_DISK" -o NAME,SIZE,FSTYPE,UUID,MOUNTPOINT
echo ""

print_success "Restoration completed successfully!"
