#!/bin/bash

# ETAP Installer for Ubuntu 24.04
# Simple 3-screen installer

# Check if dialog is installed
if ! command -v dialog &> /dev/null; then
    echo "Installing dialog..."
    sudo apt-get update && sudo apt-get install -y dialog
fi

# Set dialog colors for better visibility
export DIALOGRC=/tmp/dialogrc
cat > /tmp/dialogrc << 'EOF'
# Dialog color configuration for better visibility
screen_color = (WHITE,BLUE,ON)
shadow_color = (BLACK,BLACK,ON)
dialog_color = (BLACK,WHITE,OFF)
title_color = (BLUE,WHITE,ON)
border_color = (WHITE,WHITE,ON)
button_active_color = (WHITE,BLUE,ON)
button_inactive_color = (BLACK,WHITE,OFF)
button_key_active_color = (WHITE,BLUE,ON)
button_key_inactive_color = (RED,WHITE,OFF)
button_label_active_color = (YELLOW,BLUE,ON)
button_label_inactive_color = (BLACK,WHITE,ON)
inputbox_color = (BLACK,WHITE,OFF)
inputbox_border_color = (BLACK,WHITE,OFF)
searchbox_color = (BLACK,WHITE,OFF)
searchbox_title_color = (BLUE,WHITE,ON)
searchbox_border_color = (WHITE,WHITE,ON)
position_indicator_color = (BLUE,WHITE,ON)
menubox_color = (BLACK,WHITE,OFF)
menubox_border_color = (WHITE,WHITE,ON)
item_color = (BLACK,WHITE,OFF)
item_selected_color = (WHITE,BLUE,ON)
tag_color = (BLUE,WHITE,ON)
tag_selected_color = (YELLOW,BLUE,ON)
tag_key_color = (RED,WHITE,OFF)
tag_key_selected_color = (RED,BLUE,ON)
check_color = (BLACK,WHITE,OFF)
check_selected_color = (WHITE,BLUE,ON)
uarrow_color = (GREEN,WHITE,ON)
darrow_color = (GREEN,WHITE,ON)
itemhelp_color = (WHITE,BLACK,OFF)
form_active_text_color = (BLACK,WHITE,OFF)
form_text_color = (BLACK,WHITE,OFF)
form_item_readonly_color = (CYAN,WHITE,ON)
gauge_color = (BLUE,WHITE,ON)
EOF

# Global variables
INSTALLER_TITLE="ETAP INSTALLER"
SELECTED_DISK=""
CUSTOMER_NAME=""
CUSTOMER_ID=""
TERMINAL_ID=""
TERMINAL_NAME=""
VPN_FILENAME=""
APP_IMAGE=""
MY_IP=""
INSTALL_DURATION=""

# Function to get IPv4 address
get_ipv4_address() {
    # Try multiple methods to get IPv4 address
    local ip=""
    
    # Method 1: Try ip route (most reliable)
    ip=$(ip route get 8.8.8.8 2>/dev/null | grep -oP 'src \K\S+' | head -n1)
    
    # Method 2: Try hostname -I if first method fails
    if [[ -z "$ip" ]]; then
        ip=$(hostname -I 2>/dev/null | awk '{print $1}')
    fi
    
    # Method 3: Try ifconfig as fallback
    if [[ -z "$ip" ]]; then
        ip=$(ifconfig 2>/dev/null | grep -oP 'inet \K192\.168\.\d+\.\d+|inet \K10\.\d+\.\d+\.\d+|inet \K172\.(1[6-9]|2[0-9]|3[01])\.\d+\.\d+' | head -n1)
    fi
    
    # Method 4: Try ip addr as final fallback
    if [[ -z "$ip" ]]; then
        ip=$(ip addr 2>/dev/null | grep -oP 'inet \K192\.168\.\d+\.\d+|inet \K10\.\d+\.\d+\.\d+|inet \K172\.(1[6-9]|2[0-9]|3[01])\.\d+\.\d+' | head -n1)
    fi
    
    # Default if no IP found
    if [[ -z "$ip" ]]; then
        ip="No IP Found"
    fi
    
    MY_IP="$ip"
}

# Function to show IP in background (called before each dialog)
show_ip_background() {
    # Clear screen and show SRE | IP in bottom right
    clear
    # Get terminal dimensions
    local rows=$(tput lines)
    local cols=$(tput cols)
    local ip_text="SRE | IP: $MY_IP"
    local ip_length=${#ip_text}
    
    # Position at bottom right (accounting for text length)
    local row=$((rows - 1))
    local col=$((cols - ip_length - 2))
    
    # Ensure minimum position (don't go off screen)
    if [[ $col -lt 1 ]]; then
        col=1
    fi
    
    echo -e "\033[${row};${col}H\033[37;44m $ip_text \033[0m"
}

# Function to clear IP background
clear_ip_background() {
    clear
}

# Function to show welcome screen (Screen 1)
show_welcome() {
    show_ip_background
    dialog --title "$INSTALLER_TITLE" \
           --msgbox "Welcome to ETAP Installer\n\nThis installer will guide you through the installation process.\n\nPress OK to continue." 10 50
}

# Function to show main menu (Screen 2)
show_main_menu() {
    while true; do
        show_ip_background
        choice=$(dialog --title "$INSTALLER_TITLE" \
                       --cancel-label "Exit" \
                       --menu "Select an option:" 12 50 2 \
                       "INSTALL" "Install ETAP system" \
                       "CREATE APP IMAGE" "Create app image" \
                       3>&1 1>&2 2>&3)
        
        case $? in
            0)  # OK pressed
                case $choice in
                    "INSTALL")
                        return 0  # Continue to installation
                        ;;
                    "CREATE APP IMAGE")
                        if run_create_app_image; then
                            # After successful app image creation, return to menu
                            continue
                        else
                            # If user cancelled or error, return to menu
                            continue
                        fi
                        ;;
                esac
                ;;
            1|255)  # Cancel or ESC pressed
                clear_ip_background
                echo "ETAP Installer cancelled by user."
                exit 0
                ;;
        esac
    done
}

# Function to run app image creation
run_create_app_image() {
    show_ip_background
    
    # Check if create-app-tar script exists
    if [[ ! -f "./create-app-tar-noninteractive.sh" ]]; then
        dialog --title "Error" \
               --msgbox "create-app-tar-noninteractive.sh script not found!\n\nPlease ensure the script is in the current directory." 10 60
        return 1
    fi
    
    # Get available disks (exclude sda)
    local disks=()
    local disk_options=()
    while IFS= read -r line; do
        if [[ $line == /dev/sdb* ]] || [[ $line == /dev/sdc* ]] || [[ $line == /dev/nvme* ]]; then
            size=$(lsblk -b -d -o SIZE "$line" 2>/dev/null | tail -n1)
            if [[ -n $size ]]; then
                size_gb=$((size / 1024 / 1024 / 1024))
                disks+=("$line")
                disk_options+=("$line" "${size_gb}GB")
            fi
        fi
    done < <(lsblk -d -n -o NAME | sed 's/^/\/dev\//')
    
    if [[ ${#disks[@]} -eq 0 ]]; then
        show_ip_background
        dialog --title "Error" \
               --msgbox "No suitable disks found!\n\nOnly sdb, sdc, and nvme drives are supported.\nsda is excluded for safety." 10 50
        return 1
    fi
    
    # Select source disk
    show_ip_background
    local source_disk
    source_disk=$(dialog --title "Create App Image" \
                        --menu "Select source disk with /app partition:" 15 60 10 \
                        "${disk_options[@]}" \
                        3>&1 1>&2 2>&3)
    
    if [[ $? -ne 0 ]]; then
        return 1  # User cancelled
    fi
    
    # TAR is the only option now - skip image type selection
    local image_type="TAR"
    
    # Get app image name
    show_ip_background
    local app_name
    app_name=$(dialog --title "Create App TAR Archive" \
                     --inputbox "Enter app image name (without extension):\n\nExample: etap-inc, ecpay, pos-system\n\nOutput: <name>.tar" 14 60 \
                     3>&1 1>&2 2>&3)
    
    if [[ $? -ne 0 ]] || [[ -z "$app_name" ]]; then
        return 1  # User cancelled or empty name
    fi
    
    # Clean the app name (remove only spaces and dangerous characters)
    # Allow: letters (a-z, A-Z), numbers (0-9), hyphens (-), underscores (_), dots (.)
    app_name=$(echo "$app_name" | tr -d ' ' | sed 's/[^a-zA-Z0-9._-]//g')
    
    # Limit length to 50 characters
    if [[ ${#app_name} -gt 50 ]]; then
        app_name="${app_name:0:50}"
    fi
    
    if [[ -z "$app_name" ]]; then
        show_ip_background
        dialog --title "Error" \
               --msgbox "Invalid app image name!\n\nPlease use only:\n- Letters (a-z, A-Z)\n- Numbers (0-9)\n- Hyphens (-)\n- Underscores (_)\n- Dots (.)" 12 50
        return 1
    fi
    
    # Set output file (TAR only)
    local output_file="/extra/os/app-images/${app_name}.tar"
    local file_extension=".tar"
    
    # Check if image already exists
    if [[ -f "$output_file" ]]; then
        show_ip_background
        dialog --title "File Exists" \
               --yesno "App image '${app_name}${file_extension}' already exists.\n\nDo you want to overwrite it?" 8 50
        
        if [[ $? -ne 0 ]]; then
            return 1  # User chose not to overwrite
        fi
    fi
    
    # Confirm creation
    show_ip_background
    dialog --title "Confirm TAR Archive Creation" \
           --yesno "Create TAR archive with these settings?\n\nSource disk: $source_disk\nApp image name: ${app_name}.tar\nType: TAR archive (uncompressed)\nOutput location: /extra/os/app-images\n\nThis may take several minutes." 14 65
    
    if [[ $? -ne 0 ]]; then
        return 1  # User cancelled
    fi
    
    # Run app image creation with progress
    local temp_log="/tmp/create_app_$(date +%Y%m%d_%H%M%S).log"
    local start_time=$(date +%s)
    
    {
        echo "10"
        echo "# Preparing to create app image..."
        sleep 1
        
        echo "20"
        echo "# Starting TAR archive creation..."
        echo "# This may take several minutes..."
        
        # Check if create-app-tar-noninteractive.sh exists
        if [[ ! -f "./create-app-tar-noninteractive.sh" ]]; then
            echo "# ERROR: create-app-tar-noninteractive.sh script not found!"
            sleep 2
        else
            chmod +x ./create-app-tar-noninteractive.sh
            if ./create-app-tar-noninteractive.sh "$source_disk" "$app_name" > "$temp_log" 2>&1; then
                echo "90"
                echo "# TAR archive creation completed!"
                sleep 1
                
                echo "100"
                echo "# Finalizing..."
                sleep 1
            else
                echo "# ERROR: TAR archive creation failed!"
                sleep 2
            fi
        fi
        
    } | dialog --title "Creating App Image" --gauge "Initializing..." 8 70 0
    
    # Calculate duration
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    local duration_formatted=$(printf '%02d:%02d:%02d' $((duration/3600)) $((duration%3600/60)) $((duration%60)))
    
    # Check if creation was successful
    if [[ -f "$output_file" ]]; then
        local file_size=$(du -h "$output_file" | cut -f1)
        show_ip_background
        dialog --title "Success" \
               --msgbox "TAR archive created successfully!\n\nFile: ${app_name}.tar\nSize: $file_size\nType: TAR archive (uncompressed)\nLocation: /extra/os/app-images\nCreation Time: $duration_formatted\n\nThe archive is now available for installation." 15 65
        
        # Clean up temp log
        rm -f "$temp_log"
        return 0
    else
        show_ip_background
        dialog --title "Error" \
               --msgbox "App image creation failed!\n\nPlease check the log file:\n$temp_log\n\nPress OK to return to menu." 10 60
        return 1
    fi
}

# Function to select app image in separate dialog
select_app_image() {
    local app_images=()
    local menu_items=()
    
    # Use /extra/os/app-images directory
    local app_images_dir="/extra/os/app-images"
    
    if [[ -d "$app_images_dir" ]]; then
        # Debug: Log what we're looking for
        echo "DEBUG: Searching for app images in $app_images_dir" >> /tmp/app_debug.log
        echo "DEBUG: Looking for files: *.img and *.tar (non-empty files only)" >> /tmp/app_debug.log
        
        # List all files in directory for debugging
        echo "DEBUG: All files in directory:" >> /tmp/app_debug.log
        ls -la "$app_images_dir"/ >> /tmp/app_debug.log 2>&1
        
        # Collect .tar files only (tar archives)
        local temp_files=()
        
        # Find .tar files and exclude empty files
        while IFS= read -r -d '' file; do
            # Check if file is not empty (size > 0)
            if [[ -s "$file" ]]; then
                temp_files+=("$file")
                echo "DEBUG: Found .tar file: $file" >> /tmp/app_debug.log
            else
                echo "DEBUG: Skipped empty file: $file" >> /tmp/app_debug.log
            fi
        done < <(find "$app_images_dir" -maxdepth 1 -name "*.tar" -type f -print0 2>/dev/null)
        
        echo "DEBUG: Total files found: ${#temp_files[@]}" >> /tmp/app_debug.log
        
        # Sort files alphabetically by basename
        IFS=$'\n' temp_files=($(printf '%s\n' "${temp_files[@]}" | sort))
        
        # Build menu items with sorted files
        for file in "${temp_files[@]}"; do
            basename_file=$(basename "$file")
            app_images+=("$basename_file")
            # Get file size for display
            local size=$(du -h "$file" 2>/dev/null | cut -f1)
            menu_items+=("$basename_file" "$size")
            echo "DEBUG: Added to menu: $basename_file ($size)" >> /tmp/app_debug.log
        done
    else
        echo "DEBUG: Directory $app_images_dir does not exist" >> /tmp/app_debug.log
    fi
    
    if [[ ${#app_images[@]} -eq 0 ]]; then
        show_ip_background
        dialog --title "App Image Selection" \
               --msgbox "No TAR app images found in /extra/os/app-images\n\nApp image installation will be skipped." 10 60
        APP_IMAGE=""
        return 0
    fi
    
    while true; do
        # Add options at the top
        local full_menu=("SKIP" "No app image" "SEARCH" "Search for specific image" "${menu_items[@]}")
        
        show_ip_background
        local selected
        selected=$(dialog --title "App Image Selection" \
                         --cancel-label "Back" \
                         --menu "Select a TAR app image to install:\n\nFound ${#app_images[@]} TAR image(s) (alphabetically sorted)" \
                         25 80 15 \
                         "${full_menu[@]}" \
                         3>&1 1>&2 2>&3)
        
        if [[ $? -ne 0 ]]; then
            return 1
        fi
        
        case "$selected" in
            "SKIP")
                APP_IMAGE=""
                return 0
                ;;
            "SEARCH")
                # Search functionality
                show_ip_background
                local search_term
                search_term=$(dialog --title "Search TAR App Images" \
                                   --inputbox "Enter search term (partial filename):" 10 60 \
                                   3>&1 1>&2 2>&3)
                
                if [[ $? -ne 0 ]] || [[ -z "$search_term" ]]; then
                    continue  # Go back to main menu
                fi
                
                # Filter images based on search term
                local filtered_menu=()
                local found_count=0
                for ((i=0; i<${#app_images[@]}; i++)); do
                    if [[ "${app_images[i]}" == *"$search_term"* ]]; then
                        filtered_menu+=("${app_images[i]}" "${menu_items[$((i*2+1))]}")
                        ((found_count++))
                    fi
                done
                
                if [[ $found_count -eq 0 ]]; then
                    show_ip_background
                    dialog --title "Search Results" \
                           --msgbox "No TAR images found matching: '$search_term'\n\nPress OK to try again." 8 50
                    continue
                fi
                
                # Add back option to filtered results
                filtered_menu=("BACK" "Back to full list" "${filtered_menu[@]}")
                
                show_ip_background
                local search_selected
                search_selected=$(dialog --title "Search Results" \
                                        --menu "Found $found_count TAR image(s) matching '$search_term':" \
                                        20 80 10 \
                                        "${filtered_menu[@]}" \
                                        3>&1 1>&2 2>&3)
                
                if [[ $? -ne 0 ]] || [[ "$search_selected" == "BACK" ]]; then
                    continue  # Go back to main menu
                fi
                
                # User selected a filtered image
                APP_IMAGE="$search_selected"
                return 0
                ;;
            *)
                # User selected a regular image
                APP_IMAGE="$selected"
                return 0
                ;;
        esac
    done
}

# Function to get basic installation inputs
get_basic_inputs() {
    while true; do
        # Get available disks (exclude sda)
        local disks=()
        local disk_list=""
        while IFS= read -r line; do
            if [[ $line == /dev/sdb* ]] || [[ $line == /dev/sdc* ]] || [[ $line == /dev/nvme* ]]; then
                size=$(lsblk -b -d -o SIZE "$line" 2>/dev/null | tail -n1)
                if [[ -n $size ]]; then
                    size_gb=$((size / 1024 / 1024 / 1024))
                    disks+=("$line")
                    if [[ -z "$disk_list" ]]; then
                        disk_list="$line (${size_gb}GB)"
                    else
                        disk_list="$disk_list, $line (${size_gb}GB)"
                    fi
                fi
            fi
        done < <(lsblk -d -n -o NAME | sed 's/^/\/dev\//')
        
        if [[ ${#disks[@]} -eq 0 ]]; then
            show_ip_background
            dialog --title "Error" --msgbox "No suitable disks found!\n\nOnly sdb, sdc, and nvme drives are supported.\nsda is excluded for safety." 10 50
            exit 1
        fi
        
        # Set default disk if only one available
        local default_disk=""
        if [[ ${#disks[@]} -eq 1 ]]; then
            default_disk="${disks[0]}"
        fi
        
        # Show menu with BACK option instead of form with Cancel
        show_ip_background
        local action
        action=$(dialog --title "INSTALLATION SETUP - Basic Information" \
                       --cancel-label "Back" \
                       --menu "Available disks: $disk_list\n\nChoose an action:" \
                       15 70 3 \
                       "FILL_FORM" "Enter installation details" \
                       "BACK" "Back to main menu" \
                       "EXIT" "Exit installer" \
                       3>&1 1>&2 2>&3)
        
        case $? in
            0)  # OK pressed
                case $action in
                    "FILL_FORM")
                        # Show the actual form
                        show_ip_background
                        local form_result
                        form_result=$(dialog --title "INSTALLATION SETUP - Basic Information" \
                                            --form "Enter installation details:\n\nAvailable disks: $disk_list" \
                                            18 70 6 \
                                            "Selected Disk:"     1 1 "$default_disk"  1 20 20 0 \
                                            "Customer Name:"     2 1 "$CUSTOMER_NAME" 2 20 20 0 \
                                            "Customer ID:"       3 1 "$CUSTOMER_ID"   3 20 10 0 \
                                            "Terminal ID:"       4 1 "$TERMINAL_ID"   4 20 15 0 \
                                            "Terminal Name:" 5 1 "$TERMINAL_NAME" 5 20 20 0 \
                                            "VPN Filename:"      6 1 "$VPN_FILENAME"  6 20 20 0 \
                                            3>&1 1>&2 2>&3)
                        
                        if [[ $? -ne 0 ]]; then
                            continue  # Go back to menu if user cancels form
                        fi
                        ;;
                    "BACK")
                        return 2  # Back to main menu
                        ;;
                    "EXIT")
                        clear_ip_background
                        echo "ETAP Installer cancelled by user."
                        exit 0
                        ;;
                esac
                ;;
            1|255)  # Cancel or ESC pressed
                return 2  # Back to main menu
                ;;
        esac
        
        # Parse form results
        local line_num=1
        while IFS= read -r line; do
            case $line_num in
                1) SELECTED_DISK="$line" ;;
                2) CUSTOMER_NAME="$line" ;;
                3) CUSTOMER_ID="$line" ;;
                4) TERMINAL_ID="$line" ;;
                5) TERMINAL_NAME="$line" ;;
                6) VPN_FILENAME="$line" ;;
            esac
            ((line_num++))
        done <<< "$form_result"
        
        # Validate required fields
        local errors=""
        
        # Check if selected disk is valid
        local disk_valid=false
        for disk in "${disks[@]}"; do
            if [[ "$SELECTED_DISK" == "$disk" ]]; then
                disk_valid=true
                break
            fi
        done
        
        if [[ "$disk_valid" == false ]]; then
            errors+="- Invalid disk selection. Choose from: $disk_list\n"
        fi
        
        if [[ -z "$CUSTOMER_NAME" ]]; then
            errors+="- Customer Name is required\n"
        fi
        
        if [[ -z "$CUSTOMER_ID" ]]; then
            errors+="- Customer ID is required\n"
        fi
        
        if [[ -z "$TERMINAL_ID" ]]; then
            errors+="- Terminal ID is required\n"
        fi
        
        if [[ -z "$TERMINAL_NAME" ]]; then
            errors+="- Terminal Name is required\n"
        fi
        
        if [[ -z "$VPN_FILENAME" ]]; then
            errors+="- VPN Filename is required\n"
        fi
        
        # Show errors if any
        if [[ -n "$errors" ]]; then
            show_ip_background
            dialog --title "Input Errors" --msgbox "Please fix the following errors:\n\n$errors" 12 60
            continue
        fi
        
        # All inputs are valid
        break
    done
}

# Function to get all inputs with professional workflow
get_all_inputs() {
    # Step 1: Get basic installation information
    local basic_result
    if get_basic_inputs; then
        basic_result=$?
    else
        basic_result=$?
        if [[ $basic_result -eq 2 ]]; then
            return 2  # Pass back the "back to main menu" code
        else
            return 1  # Regular cancel/error
        fi
    fi
    
    # Step 2: Select app image in separate dialog
    if ! select_app_image; then
        return 1
    fi
    
    return 0
}

# Function to show summary and install (Screen 3)
show_summary_and_install() {
    while true; do
        local summary="INSTALLATION SUMMARY\n\n"
        summary+="Selected Disk: $SELECTED_DISK\n"
        summary+="Customer Name: $CUSTOMER_NAME\n"
        summary+="Customer ID: $CUSTOMER_ID\n"
        summary+="Terminal ID: $TERMINAL_ID\n"
        summary+="Terminal Name: $TERMINAL_NAME\n"
        summary+="VPN Filename: $VPN_FILENAME\n"
        if [[ -n "$APP_IMAGE" ]]; then
            summary+="App Image: $APP_IMAGE\n"
        else
            summary+="App Image: None selected\n"
        fi
        
        summary+="\nSystem Cleanup: Enabled (automatic)\n"
        summary+="\nReady to install with 11-partition layout"
        
        show_ip_background
        local action
        action=$(dialog --title "INSTALLATION SUMMARY" \
                       --cancel-label "Back" \
                       --menu "$summary" 25 80 5 \
                       "INSTALL" "Start installation" \
                       "MODIFY_BASIC" "Modify basic information" \
                       "MODIFY_APP" "Change app image selection" \
                       "BACK" "Go back to input screens" \
                       "EXIT" "Exit installer" \
                       3>&1 1>&2 2>&3)
        
        case $action in
            "INSTALL")
                # Run actual installation
                if run_installation; then
                    # Show completion
                    local completion_msg="ETAP installation completed successfully!\n\nCustomer: $CUSTOMER_NAME\nTerminal: $TERMINAL_ID\nLocation: $TERMINAL_NAME\nVPN: $VPN_FILENAME"
                    if [[ -n "$APP_IMAGE" ]]; then
                        completion_msg+="\nApp Image: $APP_IMAGE"
                    fi
                    completion_msg+="\nSystem Cleanup: Completed (automatic)"
                    if [[ -n "$INSTALL_DURATION" ]]; then
                        completion_msg+="\nInstallation Time: $INSTALL_DURATION"
                    fi
                    completion_msg+="\n\nSystem is ready for use!"
                    
                    show_ip_background
                    dialog --title "INSTALLATION COMPLETE" \
                           --msgbox "$completion_msg" 18 60
                    
                    # Final action
                    show_ip_background
                    local final_action
                    final_action=$(dialog --title "INSTALLATION COMPLETE" \
                                         --menu "Installation completed successfully!" 10 60 2 \
                                         "MENU" "Go back to menu (install another disk)" \
                                         "FINISH" "Exit installer" \
                                         3>&1 1>&2 2>&3)
                    
                    case $final_action in
                        "MENU")
                            # Clear variables for new installation
                            SELECTED_DISK=""
                            CUSTOMER_NAME=""
                            CUSTOMER_ID=""
                            TERMINAL_ID=""
                            TERMINAL_NAME=""
                            VPN_FILENAME=""
                            APP_IMAGE=""
                            INSTALL_DURATION=""
                            return 2  # Special return code to indicate menu restart
                            ;;
                        "FINISH"|*)
                            clear
                            echo "ETAP installation completed successfully!"
                            if [[ -n "$INSTALL_DURATION" ]]; then
                                echo "Total installation time: $INSTALL_DURATION"
                            fi
                            echo "Please reboot the system to complete the setup."
                            return 0
                            ;;
                    esac
                else
                    # Installation failed
                    show_ip_background
                    dialog --title "INSTALLATION FAILED" \
                           --msgbox "Installation failed! Please check the logs and try again.\n\nPress OK to return to summary." 10 60
                    continue
                fi
                ;;
            "MODIFY_BASIC")
                # Modify basic information only
                if get_basic_inputs; then
                    continue  # Return to summary with updated info
                else
                    continue  # Stay in summary if user cancelled
                fi
                ;;
            "MODIFY_APP")
                # Modify app image selection only
                if select_app_image; then
                    continue  # Return to summary with updated app image
                else
                    continue  # Stay in summary if user cancelled
                fi
                ;;
            "TOGGLE_CLEANUP")
                # This option is removed - system cleanup is now automatic
                continue
                ;;
            "BACK")
                return 1  # Go back to full input workflow
                ;;
            "EXIT"|*)
                exit 0
                ;;
        esac
    done
}

# Function to run the actual installation process
run_installation() {
    local log_file="/tmp/etap_install_$(date +%Y%m%d_%H%M%S).log"
    
    # Record overall installation start time
    local overall_start_time=$(date '+%Y-%m-%d %H:%M:%S')
    local overall_start_seconds=$(date +%s)
    
    # Debug: Log initial state
    echo "=== ETAP Installation Debug Log ===" > "$log_file"
    echo "Date: $(date)" >> "$log_file"
    echo "Overall installation start time: $overall_start_time" >> "$log_file"
    echo "Selected disk: $SELECTED_DISK" >> "$log_file"
    echo "Customer: $CUSTOMER_NAME" >> "$log_file"
    echo "App image: $APP_IMAGE" >> "$log_file"
    echo "Current directory: $(pwd)" >> "$log_file"
    echo "Available files:" >> "$log_file"
    ls -la ./restoration-script* >> "$log_file" 2>&1
    echo "===============================" >> "$log_file"
    
    # Create a wrapper script that calls your original restoration script non-interactively
    create_restoration_wrapper() {
        local target_disk="$1"
        local wrapper_path="/var/tmp/restoration_wrapper_$$.sh"  # Use /var/tmp instead of /tmp
        local script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
        
        cat > "$wrapper_path" << EOF
#!/bin/bash
# Wrapper for restoration script - calls non-interactive version

# Change to the installer directory
cd "$script_dir"

# Check if non-interactive restoration script exists
if [ ! -f "./restoration-script-noninteractive.sh" ]; then
    echo "ERROR: restoration-script-noninteractive.sh not found in $script_dir"
    echo "Available files:"
    ls -la ./restoration-script*
    exit 1
fi

# Make it executable
chmod +x ./restoration-script-noninteractive.sh

# Run the non-interactive restoration script
echo "Running: ./restoration-script-noninteractive.sh $target_disk"
./restoration-script-noninteractive.sh "$target_disk"
EOF
        
        chmod +x "$wrapper_path"
        echo "$wrapper_path"
    }
    
    # Show progress dialog with actual restoration
    {
        echo "5"
        echo "# Preparing disk $SELECTED_DISK..."
        sleep 1
        
        echo "15"
        echo "# Starting partition restoration..."
        echo "# This may take several minutes..."
        
        # Run restoration script directly
        echo "Running restoration script..." >> "$log_file"
        echo "Target disk: $SELECTED_DISK" >> "$log_file"
        echo "Current directory: $(pwd)" >> "$log_file"
        
        # Make sure restoration script is executable
        chmod +x ./restoration-script-noninteractive.sh
        
        # Run the restoration script directly
        if ./restoration-script-noninteractive.sh "$SELECTED_DISK" >> "$log_file" 2>&1; then
            echo "60"
            echo "# Partition restoration completed successfully!"
            echo "Restoration completed successfully" >> "$log_file"
        else
            local exit_code=$?
            echo "# ERROR: Restoration failed with exit code $exit_code!"
            echo "ERROR: Restoration failed with exit code $exit_code" >> "$log_file"
            echo "Check log file: $log_file" >> "$log_file"
            return 1
        fi
        
        sleep 1
        
        echo "70"
        echo "# Installing system for $CUSTOMER_NAME..."
        sleep 1
        
        if [[ -n "$APP_IMAGE" ]]; then
            echo "80"
            echo "# Installing app image: $APP_IMAGE..."
            
            # Find app image file in /extra/os/app-images directory
            local app_image_file=""
            
            if [[ -f "/extra/os/app-images/$APP_IMAGE" ]]; then
                app_image_file="/extra/os/app-images/$APP_IMAGE"
                echo "Found app image: $app_image_file" >> "$log_file"
            fi
            
            # Install app image if found
            if [[ -n "$app_image_file" ]]; then
                # Get app partition (partition 9)
                local app_partition
                if [[ "$SELECTED_DISK" == *"nvme"* ]] || [[ "$SELECTED_DISK" == *"mmcblk"* ]]; then
                    app_partition="${SELECTED_DISK}p9"
                else
                    app_partition="${SELECTED_DISK}9"
                fi
                
                # Log with same format as main restoration
                echo "========================================" >> "$log_file"
                echo "Restoring: app (Partition 9)" >> "$log_file"
                echo "========================================" >> "$log_file"
                echo "[INFO] Image: $app_image_file → $app_partition" >> "$log_file"
                
                # Record start time
                local app_start_time=$(date '+%Y-%m-%d %H:%M:%S')
                local app_start_seconds=$(date +%s)
                echo "[INFO] Start time: $app_start_time" >> "$log_file"
                
                # Handle different app image types
                if [[ "$APP_IMAGE" == *.img ]]; then
                    # Raw partition image - write directly to partition 9
                    echo "[INFO] Type: Raw partition image" >> "$log_file"
                    # Suppress all progress output to avoid conflicting with dialog gauge
                    if command -v pv &> /dev/null; then
                        pv "$app_image_file" 2>/dev/null | dd of="$app_partition" bs=16M conv=sync,noerror oflag=sync status=none iflag=fullblock 2>>"$log_file" || true
                    else
                        dd if="$app_image_file" of="$app_partition" bs=16M conv=sync,noerror oflag=sync status=none iflag=fullblock 2>>"$log_file" || true
                    fi
                    sync
                elif [[ "$APP_IMAGE" == *.tar ]]; then
                    # TAR archive - use dedicated restore script
                    echo "[INFO] Type: TAR archive (uncompressed)" >> "$log_file"
                    if [[ -f "./restore-app-tar.sh" ]]; then
                        chmod +x ./restore-app-tar.sh
                        echo "[INFO] Using restore-app-tar.sh script" >> "$log_file"
                        ./restore-app-tar.sh "$SELECTED_DISK" "$app_image_file" >> "$log_file" 2>&1 || true
                    else
                        # Fallback to manual extraction
                        echo "[INFO] restore-app-tar.sh not found, using fallback method" >> "$log_file"
                        local app_mount="/mnt/app_install"
                        mkdir -p "$app_mount"
                        if mount "$app_partition" "$app_mount" 2>/dev/null; then
                            tar -xf "$app_image_file" -C "$app_mount" 2>/dev/null || true
                            umount "$app_mount"
                        fi
                        rmdir "$app_mount" 2>/dev/null || true
                    fi
                else
                    # Archive format (tar.gz or .img.gz) - mount and extract
                    echo "[INFO] Type: Compressed archive" >> "$log_file"
                    local app_mount="/mnt/app_install"
                    mkdir -p "$app_mount"
                    if mount "$app_partition" "$app_mount" 2>/dev/null; then
                        if [[ "$APP_IMAGE" == *.gz ]]; then
                            gzip -d -c "$app_image_file" | tar -xf - -C "$app_mount" 2>/dev/null || true
                        else
                            tar -xf "$app_image_file" -C "$app_mount" 2>/dev/null || true
                        fi
                        umount "$app_mount"
                    fi
                    rmdir "$app_mount" 2>/dev/null || true
                fi
                
                # Record finish time
                local app_finish_time=$(date '+%Y-%m-%d %H:%M:%S')
                local app_finish_seconds=$(date +%s)
                local app_duration=$((app_finish_seconds - app_start_seconds))
                local app_duration_formatted=$(printf '%02d:%02d:%02d' $((app_duration/3600)) $((app_duration%3600/60)) $((app_duration%60)))
                
                echo "[INFO] Finish time: $app_finish_time" >> "$log_file"
                echo "[INFO] Duration: $app_duration_formatted ($app_duration seconds)" >> "$log_file"
                echo "[SUCCESS] Restored: app" >> "$log_file"
            else
                echo "App image file not found: $APP_IMAGE" >> "$log_file"
            fi
            
            # Install SQL file after app image installation
            echo "82"
            echo "# Installing app SQL file..."
            
            if [[ -f "./install-app-sql.sh" ]]; then
                chmod +x ./install-app-sql.sh
                
                echo "Installing customized app.sql to $SELECTED_DISK partition 9..." >> "$log_file"
                echo "Variables: TERMINAL_ID=$TERMINAL_ID, TERMINAL_NAME=$TERMINAL_NAME, CUSTOMER_ID=$CUSTOMER_ID" >> "$log_file"
                
                # Run SQL installation script with variables
                if ./install-app-sql.sh "$SELECTED_DISK" "$TERMINAL_ID" "$TERMINAL_NAME" "$CUSTOMER_ID" >> "$log_file" 2>&1; then
                    echo "App SQL installation completed successfully" >> "$log_file"
                else
                    echo "App SQL installation failed, but continuing..." >> "$log_file"
                fi
            else
                echo "App SQL script not found, skipping SQL installation" >> "$log_file"
            fi
            sleep 1
        fi
        
        # Setup Docker systemd service (only if app image was installed)
        if [[ -n "$APP_IMAGE" ]]; then
            echo "85"
            echo "# Setting up Docker auto-start service..."
            
            if [[ -f "./setup-docker-systemd.sh" ]]; then
                chmod +x ./setup-docker-systemd.sh
                
                echo "Setting up Docker systemd service on $SELECTED_DISK..." >> "$log_file"
                
                # Run systemd setup script
                if ./setup-docker-systemd.sh "$SELECTED_DISK" >> "$log_file" 2>&1; then
                    echo "Docker systemd service setup completed successfully" >> "$log_file"
                else
                    echo "Docker systemd service setup failed, but continuing..." >> "$log_file"
                fi
            else
                echo "Docker systemd setup script not found, skipping" >> "$log_file"
            fi
            sleep 1
        fi
        
        echo "87"
        echo "# Configuring VPN: $VPN_FILENAME..."
        
        # Run VPN restoration directly without the interactive script
        echo "Configuring VPN for $VPN_FILENAME on $SELECTED_DISK..." >> "$log_file"
        
        # Determine root partition (partition 2 in 11-partition layout)
        if [[ "$SELECTED_DISK" == *"nvme"* ]] || [[ "$SELECTED_DISK" == *"mmcblk"* ]]; then
            ROOT_PARTITION="${SELECTED_DISK}p2"
        else
            ROOT_PARTITION="${SELECTED_DISK}2"
        fi
        
        # Mount root partition
        local vpn_mount="/mnt/vpn_install"
        mkdir -p "$vpn_mount" >> "$log_file" 2>&1
        
        if mount "$ROOT_PARTITION" "$vpn_mount" >> "$log_file" 2>&1; then
            echo "Mounted root partition for VPN configuration" >> "$log_file"
            
            local vpn_config_path="$vpn_mount/etc/openvpn"
            
            # Create OpenVPN directory if it doesn't exist
            if [ ! -d "$vpn_config_path" ]; then
                echo "OpenVPN directory not found, creating: $vpn_config_path" >> "$log_file"
                mkdir -p "$vpn_config_path" >> "$log_file" 2>&1
            fi
            
            # Check if OpenVPN directory exists or was created
            if [ -d "$vpn_config_path" ]; then
                echo "Found OpenVPN directory: $vpn_config_path" >> "$log_file"
                
                # Backup existing VPN configuration
                if ls "$vpn_config_path"/*.conf 1> /dev/null 2>&1; then
                    mkdir -p "$vpn_config_path/backup" >> "$log_file" 2>&1
                    cp "$vpn_config_path"/*.conf "$vpn_config_path/backup/" >> "$log_file" 2>&1
                    echo "Backed up existing VPN configuration" >> "$log_file"
                fi
                
                # Remove old VPN configuration (force delete with verbose logging)
                echo "Listing VPN files before deletion:" >> "$log_file"
                ls -la "$vpn_config_path"/*.conf >> "$log_file" 2>&1 || echo "No .conf files found" >> "$log_file"
                
                # Force remove all .conf files
                find "$vpn_config_path" -maxdepth 1 -name "*.conf" -type f -delete >> "$log_file" 2>&1
                
                echo "Listing VPN files after deletion:" >> "$log_file"
                ls -la "$vpn_config_path"/*.conf >> "$log_file" 2>&1 || echo "All .conf files deleted" >> "$log_file"
                echo "Removed old VPN configuration" >> "$log_file"
                
                # Download new VPN configuration
                local vpn_url="https://vpnfile.etapinc.com:4443/ovpn-certs"
                local vpn_ecpay_url="https://vpnfile-ecpay.etapinc.com:4443/ovpn-certs"
                
                echo "Downloading VPN configuration: $VPN_FILENAME" >> "$log_file"
                
                if wget --no-check-certificate "$vpn_url/${VPN_FILENAME}.ovpn" -O "$vpn_config_path/${VPN_FILENAME}.conf" >> "$log_file" 2>&1; then
                    echo "VPN configuration downloaded successfully from primary server" >> "$log_file"
                else
                    echo "Primary VPN server failed, trying backup server..." >> "$log_file"
                    if wget --no-check-certificate "$vpn_ecpay_url/${VPN_FILENAME}.ovpn" -O "$vpn_config_path/${VPN_FILENAME}.conf" >> "$log_file" 2>&1; then
                        echo "VPN configuration downloaded successfully from backup server" >> "$log_file"
                    else
                        echo "Failed to download VPN configuration from both servers" >> "$log_file"
                        # Restore from backup if available
                        if [ -d "$vpn_config_path/backup" ]; then
                            cp "$vpn_config_path/backup"/*.conf "$vpn_config_path/" >> "$log_file" 2>&1
                        fi
                    fi
                fi
                
                # List new configuration
                ls -lh "$vpn_config_path"/*.conf >> "$log_file" 2>&1
            else
                echo "Failed to create OpenVPN directory: $vpn_config_path" >> "$log_file"
            fi
            
            # Unmount
            umount "$vpn_mount" >> "$log_file" 2>&1
            rmdir "$vpn_mount" >> "$log_file" 2>&1
            echo "VPN configuration completed" >> "$log_file"
        else
            echo "Failed to mount root partition for VPN configuration" >> "$log_file"
        fi
        sleep 1
        
        echo "92"
        echo "# Setting hostname: $TERMINAL_ID..."
        
        # Run hostname setup if script exists
        if [[ -f "./set-hostname.sh" ]]; then
            chmod +x ./set-hostname.sh
            
            echo "Setting hostname to $TERMINAL_ID on $SELECTED_DISK..." >> "$log_file"
            
            # Run hostname setup script with terminal ID
            if ./set-hostname.sh "$SELECTED_DISK" "$TERMINAL_ID" >> "$log_file" 2>&1; then
                echo "Hostname setup completed successfully" >> "$log_file"
            else
                echo "Hostname setup failed, but continuing..." >> "$log_file"
            fi
        else
            echo "Hostname script not found, skipping hostname setup" >> "$log_file"
        fi
        sleep 1
        
        echo "95"
        echo "# Fixing networking configuration..."
        
        # Run networking fix if script exists
        if [[ -f "./fix-networking.sh" ]]; then
            chmod +x ./fix-networking.sh
            
            echo "Fixing networking configuration on $SELECTED_DISK..." >> "$log_file"
            
            # Run networking fix script
            if ./fix-networking.sh "$SELECTED_DISK" >> "$log_file" 2>&1; then
                echo "Networking fix completed successfully" >> "$log_file"
            else
                echo "Networking fix failed, but continuing..." >> "$log_file"
            fi
        else
            echo "Networking fix script not found, skipping networking fix" >> "$log_file"
        fi
        sleep 1
        
        # Run system cleanup (now automatic)
        echo "97"
        echo "# Running system cleanup (automatic)..."
        
        echo "System cleanup is ENABLED automatically - proceeding with cleanup" >> "$log_file"
        
        if [[ -f "./system-cleanup.sh" ]]; then
            chmod +x ./system-cleanup.sh
            
            echo "Running system cleanup on $SELECTED_DISK..." >> "$log_file"
            echo "System cleanup enabled automatically - starting cleanup process" >> "$log_file"
            echo "Current working directory: $(pwd)" >> "$log_file"
            echo "System cleanup script path: $(realpath ./system-cleanup.sh)" >> "$log_file"
            
            # Run system cleanup script
            echo "About to execute: ./system-cleanup.sh $SELECTED_DISK" >> "$log_file"
            if ./system-cleanup.sh "$SELECTED_DISK" >> "$log_file" 2>&1; then
                echo "System cleanup completed successfully" >> "$log_file"
                echo "System cleanup script finished with success" >> "$log_file"
            else
                local cleanup_exit_code=$?
                echo "System cleanup failed with exit code: $cleanup_exit_code" >> "$log_file"
                echo "System cleanup script finished with error" >> "$log_file"
            fi
        else
            echo "System cleanup script not found at: $(pwd)/system-cleanup.sh" >> "$log_file"
            echo "Available files:" >> "$log_file"
            ls -la ./system-cleanup* >> "$log_file" 2>&1 || echo "No system-cleanup files found" >> "$log_file"
        fi
        sleep 1
        
        # Create swap file (automatic)
        echo "97.5"
        echo "# Creating swap file (12GB)..."
        
        echo "Creating swap file on $SELECTED_DISK partition 11 (/extra)..." >> "$log_file"
        
        if [[ -f "./create-swap-file.sh" ]]; then
            chmod +x ./create-swap-file.sh
            
            echo "Creating 12GB swap file in /extra partition..." >> "$log_file"
            echo "Current working directory: $(pwd)" >> "$log_file"
            echo "Swap file script path: $(realpath ./create-swap-file.sh)" >> "$log_file"
            
            # Run swap file creation script with 12GB size
            echo "About to execute: ./create-swap-file.sh $SELECTED_DISK 12" >> "$log_file"
            if ./create-swap-file.sh "$SELECTED_DISK" 12 >> "$log_file" 2>&1; then
                echo "Swap file creation completed successfully" >> "$log_file"
                echo "Swap file script finished with success" >> "$log_file"
            else
                local swap_exit_code=$?
                echo "Swap file creation failed with exit code: $swap_exit_code" >> "$log_file"
                echo "Swap file script finished with error (continuing anyway)" >> "$log_file"
            fi
        else
            echo "Swap file script not found at: $(pwd)/create-swap-file.sh" >> "$log_file"
            echo "Skipping swap file creation" >> "$log_file"
        fi
        sleep 1
        
        echo "98"
        echo "# Finalizing installation..."
        sleep 1
        
        echo "100"
        echo "# Installation complete!"
        
        # Calculate and log overall installation time
        local overall_finish_time=$(date '+%Y-%m-%d %H:%M:%S')
        local overall_finish_seconds=$(date +%s)
        local overall_duration=$((overall_finish_seconds - overall_start_seconds))
        local overall_duration_formatted=$(printf '%02d:%02d:%02d' $((overall_duration/3600)) $((overall_duration%3600/60)) $((overall_duration%60)))
        
        echo "===============================" >> "$log_file"
        echo "=== OVERALL INSTALLATION TIMING ===" >> "$log_file"
        echo "Overall installation start time: $overall_start_time" >> "$log_file"
        echo "Overall installation finish time: $overall_finish_time" >> "$log_file"
        echo "Total installation duration: $overall_duration_formatted (${overall_duration} seconds)" >> "$log_file"
        echo "===============================" >> "$log_file"
        
    } | dialog --title "INSTALLATION IN PROGRESS" --gauge "Starting installation..." 8 70 0
    
    # Check if installation was successful
    # Look for positive success indicators rather than absence of errors
    if [[ -f "$log_file" ]]; then
        # Check for critical failure patterns first (actual failures, not just ERROR text)
        if grep -q "Restoration failed" "$log_file" || \
           grep -q "Installation failed" "$log_file" || \
           grep -q "SAFETY ERROR" "$log_file" || \
           grep -q "Failed to mount root partition" "$log_file" || \
           grep -q "Failed to update /etc/hostname" "$log_file"; then
            echo "Installation failed - critical error detected" >> "$log_file"
            return 1
        fi
        
        # Look for success indicators from each major step
        local restoration_ok=false
        local hostname_ok=false
        local networking_ok=false
        local cleanup_ok=true  # Default to true if cleanup is disabled
        local sql_ok=true      # Default to true if no app image selected
        local docker_ok=true   # Default to true if no app image selected
        
        # Check if restoration completed
        if grep -q "Restoration completed successfully" "$log_file"; then
            restoration_ok=true
        fi
        
        # Check if hostname setup completed (look for multiple success indicators)
        if grep -q "Hostname setup completed successfully" "$log_file" || grep -q "SUCCESS.*Hostname setup completed" "$log_file"; then
            hostname_ok=true
        fi
        
        # Check if networking fix completed (optional - don't fail if missing)
        if grep -q "Networking fix completed successfully" "$log_file" || grep -q "SUCCESS.*Networking fix completed" "$log_file"; then
            networking_ok=true
        else
            # Networking fix is optional - check if it was attempted
            if grep -q "Fixing networking configuration" "$log_file" || grep -q "fix-networking.sh" "$log_file"; then
                print_warn "Networking fix was attempted but may have failed - check logs" >> "$log_file"
                networking_ok=true  # Don't fail installation for networking issues
            else
                networking_ok=true  # Not attempted, that's okay
            fi
        fi
        
        # Check if SQL installation completed (only if app image was selected)
        if [[ -n "$APP_IMAGE" ]]; then
            if grep -q "App SQL installation completed successfully" "$log_file" || grep -q "SUCCESS.*App SQL installation completed" "$log_file"; then
                sql_ok=true
            else
                sql_ok=false
            fi
        fi
        
        # Check if system cleanup completed (now always enabled)
        if grep -q "System cleanup completed successfully" "$log_file" || grep -q "SUCCESS.*System cleanup completed" "$log_file"; then
            cleanup_ok=true
        else
            cleanup_ok=false
        fi
        
        # Check if swap file was created (optional - don't fail if missing)
        local swap_ok=true  # Default to true (optional step)
        if grep -q "Swap file creation completed successfully" "$log_file" || grep -q "SUCCESS.*Swap file" "$log_file"; then
            swap_ok=true
        else
            # Swap creation is optional - check if it was attempted
            if grep -q "Creating swap file" "$log_file" || grep -q "create-swap-file.sh" "$log_file"; then
                swap_ok=false  # Was attempted but failed
            else
                swap_ok=true  # Not attempted, that's okay
            fi
        fi
        
        # Installation is successful if all enabled steps worked
        if [[ "$restoration_ok" == true ]] && [[ "$hostname_ok" == true ]] && [[ "$networking_ok" == true ]] && [[ "$sql_ok" == true ]] && [[ "$cleanup_ok" == true ]] && [[ "$swap_ok" == true ]]; then
            echo "Installation completed successfully - all steps verified" >> "$log_file"
            if [[ -n "$APP_IMAGE" ]]; then
                echo "Steps completed: Restoration=✓ Hostname=✓ Networking=✓ SQL=✓ Cleanup=✓ Swap=✓" >> "$log_file"
            else
                echo "Steps completed: Restoration=✓ Hostname=✓ Networking=✓ Cleanup=✓ Swap=✓" >> "$log_file"
            fi
            
            # Add final timing summary to log
            echo "" >> "$log_file"
            echo "=== FINAL INSTALLATION SUMMARY ===" >> "$log_file"
            echo "Customer: $CUSTOMER_NAME" >> "$log_file"
            echo "Terminal ID: $TERMINAL_ID" >> "$log_file"
            echo "Target Disk: $SELECTED_DISK" >> "$log_file"
            echo "Installation completed at: $(date '+%Y-%m-%d %H:%M:%S')" >> "$log_file"
            if [[ -n "$overall_start_time" ]]; then
                local final_finish_time=$(date '+%Y-%m-%d %H:%M:%S')
                local final_finish_seconds=$(date +%s)
                local final_duration=$((final_finish_seconds - overall_start_seconds))
                local final_duration_formatted=$(printf '%02d:%02d:%02d' $((final_duration/3600)) $((final_duration%3600/60)) $((final_duration%60)))
                echo "Total time: $final_duration_formatted (${final_duration} seconds)" >> "$log_file"
                
                # Store duration in global variable for completion screen
                INSTALL_DURATION="$final_duration_formatted"
            fi
            echo "Log file: $log_file" >> "$log_file"
            echo "===============================" >> "$log_file"
            
            return 0
        else
            echo "Installation incomplete - missing success indicators" >> "$log_file"
            if [[ -n "$APP_IMAGE" ]]; then
                echo "Restoration OK: $restoration_ok, Hostname OK: $hostname_ok, Networking OK: $networking_ok, SQL OK: $sql_ok, Cleanup OK: $cleanup_ok, Swap OK: $swap_ok" >> "$log_file"
            else
                echo "Restoration OK: $restoration_ok, Hostname OK: $hostname_ok, Networking OK: $networking_ok, Cleanup OK: $cleanup_ok, Swap OK: $swap_ok" >> "$log_file"
            fi
            echo "System cleanup is now automatic (always enabled)" >> "$log_file"
            return 1
        fi
    else
        echo "Log file not found" >> "$log_file"
        return 1
    fi
}

# Main installation flow (3 screens)
main() {
    # Get IPv4 address at startup
    get_ipv4_address
    
    # Screen 1: Welcome (show only once)
    show_welcome
    
    # Screen 2: Main Menu (CREATE APP IMAGE or INSTALL)
    show_main_menu
    
    while true; do
        # Screen 3: All inputs (formerly Screen 2)
        local input_result
        if get_all_inputs; then
            input_result=$?
        else
            input_result=$?
            if [[ $input_result -eq 2 ]]; then
                # User chose to go back to main menu - break to show main menu again
                show_main_menu
                continue
            else
                # User cancelled - exit
                clear_ip_background
                echo "ETAP installation cancelled."
                exit 0
            fi
        fi
        
        # Screen 4: Summary and install (formerly Screen 3)
        local install_result
        if show_summary_and_install; then
            install_result=$?
            if [[ $install_result -eq 2 ]]; then
                # User chose MENU - restart installation process
                continue
            else
                # User chose FINISH - exit
                break
            fi
        fi
        # If user chose BACK, loop back to inputs
    done
    
    # Cleanup
    clear_ip_background
    echo "ETAP installation completed."
}

# Trap to cleanup on exit
trap 'clear; rm -f /tmp/dialogrc' EXIT

# Run main function
main

