#!/bin/bash
# Create Swap File Script for ETAP Installer
# Creates a swap file in /extra partition on target disk
# Usage: ./create-swap-file.sh <target_disk> [size_in_gb]

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check parameters
if [ $# -lt 1 ] || [ $# -gt 2 ]; then
    echo "Usage: $0 <target_disk> [size_in_gb]"
    echo ""
    echo "Examples:"
    echo "  $0 /dev/sdb           # Creates 12GB swap file (default)"
    echo "  $0 /dev/sdb 8         # Creates 8GB swap file"
    echo "  $0 /dev/nvme0n1 16    # Creates 16GB swap file"
    echo ""
    echo "This will create a swap file in /extra partition (partition 11)"
    exit 1
fi

TARGET_DISK="$1"
SWAP_SIZE_GB="${2:-12}"  # Default to 12GB if not specified

# Configuration
SWAP_DIR="/extra"
SWAP_FILE="$SWAP_DIR/swapfile"

# Banner
print_header "Swap File Creation"
echo ""
echo "Target disk: $TARGET_DISK"
echo "Swap size: ${SWAP_SIZE_GB}GB"
echo "Swap location: $SWAP_FILE"
echo ""

# Validate target disk
if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

# Safety check: Exclude sda disk
if [[ "$TARGET_DISK" == "/dev/sda"* ]]; then
    print_error "SAFETY ERROR: sda disk is excluded for safety!"
    print_error "sda is typically the installer/system disk."
    print_error "Supported disks: sdb, sdc, nvme*"
    exit 1
fi

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Get extra partition (partition 11)
EXTRA_PARTITION=$(get_partition_name 11)

if [ ! -b "$EXTRA_PARTITION" ]; then
    print_error "Extra partition $EXTRA_PARTITION not found."
    print_error "Make sure the disk has been properly partitioned."
    exit 1
fi

print_success "Found extra partition: $EXTRA_PARTITION"
echo ""

# Mount extra partition
MOUNT_POINT="/mnt/extra_swap_setup"
mkdir -p "$MOUNT_POINT"

print_info "Mounting extra partition..."
if mount "$EXTRA_PARTITION" "$MOUNT_POINT" 2>/dev/null; then
    print_success "Mounted extra partition at $MOUNT_POINT"
else
    print_error "Failed to mount extra partition $EXTRA_PARTITION"
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

# Check available space
print_header "Checking Available Space"
AVAILABLE_SPACE=$(df -BG "$MOUNT_POINT" | tail -1 | awk '{print $4}' | sed 's/G//')
REQUIRED_SPACE=$((SWAP_SIZE_GB + 1))  # Add 1GB buffer

print_info "Available space: ${AVAILABLE_SPACE}GB"
print_info "Required space: ${REQUIRED_SPACE}GB (${SWAP_SIZE_GB}GB swap + 1GB buffer)"

if [ $AVAILABLE_SPACE -lt $REQUIRED_SPACE ]; then
    print_error "Not enough space on /extra partition!"
    print_error "Available: ${AVAILABLE_SPACE}GB, Required: ${REQUIRED_SPACE}GB"
    umount "$MOUNT_POINT" 2>/dev/null || true
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

print_success "Sufficient space available"
echo ""

# Check if swap file already exists
SWAP_FILE_TARGET="$MOUNT_POINT/swapfile"

if [ -f "$SWAP_FILE_TARGET" ]; then
    print_warn "Swap file already exists: $SWAP_FILE_TARGET"
    EXISTING_SIZE=$(du -h "$SWAP_FILE_TARGET" | cut -f1)
    print_info "Existing swap file size: $EXISTING_SIZE"
    echo ""
    read -p "Remove existing swap file and create new one? (yes/no): " confirm
    if [[ "$confirm" != "yes" ]]; then
        print_info "Operation cancelled by user"
        umount "$MOUNT_POINT" 2>/dev/null || true
        rmdir "$MOUNT_POINT" 2>/dev/null || true
        exit 0
    fi
    print_info "Removing existing swap file..."
    rm -f "$SWAP_FILE_TARGET"
fi

# Create swap file
print_header "Creating Swap File"
print_info "Creating ${SWAP_SIZE_GB}GB swap file at $SWAP_FILE..."
print_info "This may take a few minutes..."
echo ""

# Record start time
START_TIME=$(date '+%Y-%m-%d %H:%M:%S')
START_SECONDS=$(date +%s)
print_info "Start time: $START_TIME"

# Create swap file using fallocate (faster than dd)
if fallocate -l "${SWAP_SIZE_GB}G" "$SWAP_FILE_TARGET" 2>/dev/null; then
    print_success "Swap file created using fallocate"
else
    # Fallback to dd if fallocate fails
    print_warn "fallocate failed, using dd instead (slower)..."
    dd if=/dev/zero of="$SWAP_FILE_TARGET" bs=1M count=$((SWAP_SIZE_GB * 1024)) status=progress 2>/dev/null || {
        print_error "Failed to create swap file"
        umount "$MOUNT_POINT" 2>/dev/null || true
        rmdir "$MOUNT_POINT" 2>/dev/null || true
        exit 1
    }
    print_success "Swap file created using dd"
fi

sync

# Record finish time
FINISH_TIME=$(date '+%Y-%m-%d %H:%M:%S')
FINISH_SECONDS=$(date +%s)
DURATION=$((FINISH_SECONDS - START_SECONDS))
DURATION_FORMATTED=$(printf '%02d:%02d:%02d' $((DURATION/3600)) $((DURATION%3600/60)) $((DURATION%60)))

print_info "Finish time: $FINISH_TIME"
print_info "Duration: $DURATION_FORMATTED ($DURATION seconds)"
echo ""

# Set correct permissions
print_info "Setting permissions (600)..."
chmod 600 "$SWAP_FILE_TARGET"
print_success "Permissions set"

# Make swap
print_info "Formatting as swap..."
if mkswap "$SWAP_FILE_TARGET" > /dev/null 2>&1; then
    print_success "Swap file formatted"
else
    print_error "Failed to format swap file"
    umount "$MOUNT_POINT" 2>/dev/null || true
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

# Get swap file info
SWAP_UUID=$(blkid -s UUID -o value "$SWAP_FILE_TARGET" 2>/dev/null || echo "none")
SWAP_SIZE_ACTUAL=$(du -h "$SWAP_FILE_TARGET" | cut -f1)

print_info "Swap file UUID: $SWAP_UUID"
print_info "Swap file size: $SWAP_SIZE_ACTUAL"
echo ""

# Update fstab on root partition
print_header "Updating /etc/fstab"
ROOT_PARTITION=$(get_partition_name 2)
ROOT_MOUNT="/mnt/root_swap_fstab"
mkdir -p "$ROOT_MOUNT"

if mount "$ROOT_PARTITION" "$ROOT_MOUNT" 2>/dev/null; then
    print_success "Mounted root partition"
    
    FSTAB_FILE="$ROOT_MOUNT/etc/fstab"
    
    if [ -f "$FSTAB_FILE" ]; then
        # Check if swap entry already exists
        if grep -q "$SWAP_FILE" "$FSTAB_FILE" 2>/dev/null; then
            print_warn "Swap entry already exists in fstab, updating..."
            # Remove old entry
            sed -i "\|$SWAP_FILE|d" "$FSTAB_FILE"
        fi
        
        # Add swap entry
        echo "$SWAP_FILE none swap sw 0 0" >> "$FSTAB_FILE"
        print_success "Added swap entry to /etc/fstab"
        
        # Show fstab swap entries
        print_info "Swap entries in fstab:"
        grep -E "swap|swapfile" "$FSTAB_FILE" || echo "  (none found)"
    else
        print_warn "fstab not found, swap will need to be enabled manually after boot"
    fi
    
    umount "$ROOT_MOUNT" 2>/dev/null || true
else
    print_warn "Could not mount root partition to update fstab"
    print_info "You can manually add this line to /etc/fstab after boot:"
    echo "  $SWAP_FILE none swap sw 0 0"
fi

rmdir "$ROOT_MOUNT" 2>/dev/null || true
echo ""

# Sync and unmount
sync

print_info "Unmounting extra partition..."
if umount "$MOUNT_POINT" 2>/dev/null; then
    print_success "Unmounted extra partition"
else
    print_warn "Could not unmount cleanly, but swap file was created"
fi

rmdir "$MOUNT_POINT" 2>/dev/null || true

# Summary
print_header "Swap File Creation Complete"
print_success "Swap file created successfully!"
echo ""
print_info "Swap File Details:"
echo "  📁 Location: $SWAP_FILE"
echo "  📊 Size: ${SWAP_SIZE_GB}GB"
echo "  🔒 Permissions: 600 (rw-------)"
echo "  🆔 UUID: $SWAP_UUID"
echo "  ⏱️  Creation time: $DURATION_FORMATTED"
echo ""
print_info "On the target system:"
echo "  - Swap will be automatically enabled on boot (via /etc/fstab)"
echo "  - Check swap status: swapon --show"
echo "  - Check memory usage: free -h"
echo "  - Manually enable: swapon $SWAP_FILE"
echo "  - Manually disable: swapoff $SWAP_FILE"
echo ""
print_success "Swap file creation completed successfully!"

# Output specific message for installer detection
echo "Swap file creation completed successfully"

