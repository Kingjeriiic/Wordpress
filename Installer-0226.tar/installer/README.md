# ETAP Installer for Ubuntu 24.04
3
A professional dialog-based installer for ETAP systems with 11-partition restoration layout.

## Feature

- **3-Screen Professional Interface**: Welcome → Input → Summary
- **11-Partition Layout**: EFI, Root, Var, Home + 7 additional partitions
- **Real Restoration**: Integrates with actual partition restoration script
- **App Image Selection**: Browse and search app images with alphabetical sorting
- **VPN Integration**: Automatic VPN configuration during installation
- **IP Display**: Shows SRE IP address in bottom right corner
- **Safety**: Excludes sda disk to prevent accidental system damage

## Quick Start

1. **Run as root**:
   ```bash
   sudo ./run-installer.sh
   ```

2. **Check requirements first** (optional):
   ```bash
   sudo ./install-utils.sh check
   ```

## Directory Structure

```
/extra/os/
├── base-images/          # Required partition images
│   ├── efi.img.gz       # EFI partition image
│   ├── root.img.gz      # Root partition image  
│   ├── var.img.gz       # Var partition image
│   ├── home.img.gz      # Home partition image
│   ├── uuid_mapping.txt # UUID mappings (optional)
│   └── fstab.backup     # fstab backup (optional)
└── app-images/          # Application images (optional)
    ├── app1.img.gz
    ├── app2.img
    └── ...
```

## Partition Layout

| Partition | Mount Point      | Size    | Description |
|-----------|------------------|---------|-------------|
| 1         | /boot/efi        | 1.5GB   | EFI System Partition |
| 2         | /                | 30GB    | Root filesystem |
| 3         | /var             | 10GB    | Variable data |
| 4         | /home            | 5GB     | User home directories |
| 5         | /var/log         | 5GB     | System logs |
| 6         | /var/tmp         | 2GB     | Temporary files |
| 7         | /var/log/audit   | 5GB     | Audit logs |
| 8         | /embedd_d        | 2GB     | Embedded data |
| 9         | /app             | 10GB    | Applications |
| 10        | /tmp             | 3GB     | Temporary files |
| 11        | /extra           | Remaining | Extra storage |

**Total Fixed Space**: ~73.5GB (plus remaining space for /extra)

## Installation Process

### Screen 1: Welcome
- Introduction and overview

### Screen 2: Input Collection
- **Basic Information Form**:
  - Target disk selection (sdb, sdc, nvme*)
  - Customer name
  - Customer ID  
  - Terminal ID
  - Terminal location
  - VPN filename

- **App Image Selection** (separate dialog):
  - Alphabetically sorted list
  - Search functionality
  - File size display
  - Skip option available

### Screen 3: Summary & Installation
- Review all settings
- Modification options:
  - Modify basic information
  - Change app image selection
  - Go back to inputs
- **Real installation process**:
  1. Disk preparation and partitioning
  2. Restore EFI, Root, Var, Home images
  3. Format additional partitions
  4. Install selected app image
  5. Configure VPN settings
  6. Finalize installation

## Files

- `installer.sh` - Main installer with dialog interface
- `restoration-script.sh` - Standalone restoration script
- `vpn-restoration.sh` - VPN configuration script
- `run-installer.sh` - Installer runner and setup
- `install-utils.sh` - Utility functions and system checks
- `installer.conf` - Configuration documentation

## Requirements

### System Requirements
- Ubuntu 24.04 or compatible Linux distribution
- Root privileges
- Minimum 80GB target disk space

### Required Packages
- `dialog` - Dialog interface
- `parted` - Disk partitioning
- `pv` - Progress viewer (optional)
- `pigz` - Parallel gzip (optional, falls back to gzip)
- `bc` - Calculator for disk size calculations

### Required Files
- `/extra/os/base-images/efi.img.gz`
- `/extra/os/base-images/root.img.gz`
- `/extra/os/base-images/var.img.gz`
- `/extra/os/base-images/home.img.gz`

## Utility Commands

```bash
# Check system requirements
sudo ./install-utils.sh check

# Create directory structure
sudo ./install-utils.sh setup

# Show installer status
./install-utils.sh status

# Install dependencies
sudo ./install-utils.sh deps
```

## Safety Features

- **sda Exclusion**: Prevents accidental installation on primary system disk
- **Confirmation Dialogs**: Multiple confirmation steps before installation
- **Input Validation**: Validates all user inputs before proceeding
- **Error Handling**: Graceful error handling with user feedback
- **Installation Logs**: Creates detailed logs in `/tmp/etap_install_*.log`

## VPN Configuration

The installer integrates with VPN restoration:
- Downloads VPN configurations from ETAP servers
- Primary: `https://vpnfile.etapinc.com:4443/ovpn-certs`
- Backup: `https://vpnfile-ecpay.etapinc.com:4443/ovpn-certs`
- Automatic fallback between servers
- Configures OpenVPN on target system

## App Image Support

- Supports `.img` and `.img.gz` formats
- Installs to `/app` partition (partition 9)
- Search functionality for large image collections
- Alphabetical sorting for easy navigation
- Optional installation (can skip)

## Troubleshooting

### Common Issues

1. **"No suitable disks found"**
   - Only sdb, sdc, and nvme* disks are supported
   - sda is excluded for safety

2. **"Missing required backup files"**
   - Ensure all .img.gz files are in `/extra/os/base-images/`
   - Check file permissions and accessibility

3. **"Installation failed"**
   - Check installation logs in `/tmp/etap_install_*.log`
   - Verify disk has sufficient space (80GB+ recommended)
   - Ensure target disk is not in use

### Debug Mode

For detailed debugging, check the installation log:
```bash
tail -f /tmp/etap_install_*.log
```

## Development

### Architecture
- **Modular Design**: Separate scripts for different functions
- **Dialog Interface**: Professional multi-screen workflow
- **Error Handling**: Comprehensive error checking and user feedback
- **Integration**: Seamless integration between restoration and VPN scripts

### Customization
- Modify partition sizes in `run_installation()` function
- Update VPN URLs in `vpn-restoration.sh`
- Customize dialog colors in the DIALOGRC configuration
- Add additional validation in input functions

## License

Copyright 2024, Electronic Transfer and Advance Payment Inc.

---

**Version**: 1.0  
**Author**: SRE-JERIC
**Last Updated**: January 2025  
**Compatibility**: Ubuntu 24.04, ETAP Systems
