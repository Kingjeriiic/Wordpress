#!/bin/bash

# Backup Script for 4 Main Partitions (EFI, Root, Var, Home)
# Saves compressed images to /extra/os with UUID and size information
# Also records UUID and size of ALL partitions for later recreation
# Backs up /etc/fstab for restoration

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
BACKUP_DIR="/extra/os/base-images"
DATE=$(date +"%Y%m%d_%H%M%S")

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Banner
clear
print_header "4-Partition Backup System"
echo ""
echo "This will backup EFI, Root, Var, and Home partitions as images"
echo "All partition UUIDs and sizes will be recorded for restoration"
echo "Backup location: $BACKUP_DIR"
echo "Compression: pigz -9 (or gzip -9 if pigz not available)"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Show available disks
print_header "Available Disks and Partitions"
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT,LABEL
echo ""

# Ask user which disk to backup
read -rp "Enter the disk to backup (e.g., sda, sdb, nvme0n1): " disk_input
TARGET_DISK="/dev/$disk_input"

if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

print_info "Selected disk: $TARGET_DISK"
echo ""

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Define the 4 main partitions to backup as images
P1=$(get_partition_name 1)  # EFI
P2=$(get_partition_name 2)  # Root
P3=$(get_partition_name 3)  # Var
P4=$(get_partition_name 4)  # Home

# Display partition information
print_header "Partitions Overview"
echo ""
print_info "Partitions that will be BACKED UP as images:"
printf "  %-8s %-15s %-10s %-10s %-38s\n" "Label" "Partition" "Size" "FS Type" "UUID"
printf "  %-8s %-15s %-10s %-10s %-38s\n" "-----" "---------" "----" "-------" "------------------------------------"

for part_num in 1 2 3 4; do
    part=$(get_partition_name $part_num)
    if [ -b "$part" ]; then
        uuid=$(blkid -s UUID -o value "$part" 2>/dev/null || echo "N/A")
        fstype=$(blkid -s TYPE -o value "$part" 2>/dev/null || echo "N/A")
        size=$(blockdev --getsize64 "$part" 2>/dev/null || echo "0")
        size_gb=$(echo "scale=2; $size/1024/1024/1024" | bc 2>/dev/null || echo "?")
        
        case $part_num in
            1) label="EFI" ;;
            2) label="ROOT" ;;
            3) label="VAR" ;;
            4) label="HOME" ;;
        esac
        
        printf "  %-8s %-15s %-10s %-10s %-38s\n" "$label" "$part" "${size_gb}GB" "$fstype" "$uuid"
    else
        print_warn "Partition $part not found"
    fi
done
echo ""

# Detect and display additional partitions (5+)
print_info "Additional partitions (UUID and size will be recorded):"
printf "  %-15s %-10s %-15s %-38s %-20s\n" "Partition" "Size" "FS Type" "UUID" "Mount Point"
printf "  %-15s %-10s %-15s %-38s %-20s\n" "---------" "----" "-------" "------------------------------------" "-----------"

additional_parts_found=0
for part_num in {5..20}; do
    part=$(get_partition_name $part_num)
    if [ -b "$part" ]; then
        additional_parts_found=1
        uuid=$(blkid -s UUID -o value "$part" 2>/dev/null || echo "N/A")
        fstype=$(blkid -s TYPE -o value "$part" 2>/dev/null || echo "N/A")
        size=$(blockdev --getsize64 "$part" 2>/dev/null || echo "0")
        size_gb=$(echo "scale=2; $size/1024/1024/1024" | bc 2>/dev/null || echo "?")
        mountpoint=$(findmnt -n -o TARGET "$part" 2>/dev/null || echo "not mounted")
        
        printf "  %-15s %-10s %-15s %-38s %-20s\n" "$part" "${size_gb}GB" "$fstype" "$uuid" "$mountpoint"
    fi
done

if [ $additional_parts_found -eq 0 ]; then
    echo "  No additional partitions found"
fi
echo ""

# Confirm backup
print_warn "Images will be created for: EFI, Root, Var, Home"
print_warn "UUID and size will be recorded for ALL partitions"
echo "Backup will be saved to: $BACKUP_DIR"
echo ""
read -rp "Continue with backup? (yes/no): " confirm

if [ "$confirm" != "yes" ]; then
    print_info "Backup cancelled"
    exit 0
fi

# UUID file
UUID_FILE="$BACKUP_DIR/uuids.txt"
> "$UUID_FILE"

# Partition sizes file
SIZES_FILE="$BACKUP_DIR/partition_sizes.txt"
> "$SIZES_FILE"

# All partitions info file (detailed)
ALL_PARTS_FILE="$BACKUP_DIR/all_partitions_info.txt"
> "$ALL_PARTS_FILE"

# UUID mapping file (machine-readable format for restoration)
UUID_MAP_FILE="$BACKUP_DIR/uuid_mapping.txt"
> "$UUID_MAP_FILE"

# Detect if we need to mount the root partition to get its fstab
FSTAB_SOURCE=""
ROOT_MOUNT_TEMP=""

# Try to get fstab from the target disk's root partition
if [ -b "$P2" ]; then
    # Check if P2 (root partition) is already mounted
    P2_MOUNT=$(findmnt -n -o TARGET "$P2" 2>/dev/null || echo "")
    
    if [ -n "$P2_MOUNT" ] && [ -f "$P2_MOUNT/etc/fstab" ]; then
        FSTAB_SOURCE="$P2_MOUNT/etc/fstab"
        print_info "Found fstab on already-mounted root partition: $P2_MOUNT"
    else
        # Try to mount it temporarily
        ROOT_MOUNT_TEMP="/tmp/backup_root_$"
        mkdir -p "$ROOT_MOUNT_TEMP"
        
        if mount -o ro "$P2" "$ROOT_MOUNT_TEMP" 2>/dev/null; then
            if [ -f "$ROOT_MOUNT_TEMP/etc/fstab" ]; then
                FSTAB_SOURCE="$ROOT_MOUNT_TEMP/etc/fstab"
                print_info "Temporarily mounted $P2 to read fstab"
            fi
        else
            print_warn "Could not mount root partition to read fstab"
        fi
    fi
fi

# Backup the target disk's fstab if found
FSTAB_BACKUP="$BACKUP_DIR/fstab.backup"
if [ -n "$FSTAB_SOURCE" ] && [ -f "$FSTAB_SOURCE" ]; then
    cp "$FSTAB_SOURCE" "$FSTAB_BACKUP"
    print_success "Backed up fstab from target disk: $FSTAB_BACKUP"
else
    print_warn "Could not find fstab on target disk"
    # Fallback to current system's fstab
    if [ -f "/etc/fstab" ]; then
        cp /etc/fstab "$FSTAB_BACKUP"
        print_info "Using current system's fstab as backup"
    fi
fi

# Unmount temporary mount if we created it
if [ -n "$ROOT_MOUNT_TEMP" ] && mountpoint -q "$ROOT_MOUNT_TEMP" 2>/dev/null; then
    umount "$ROOT_MOUNT_TEMP" 2>/dev/null || true
    rmdir "$ROOT_MOUNT_TEMP" 2>/dev/null || true
fi

# Generate fstab template based on discovered partitions
FSTAB_TEMPLATE="$BACKUP_DIR/fstab.template"
print_info "Generating fstab template based on partition layout..."

cat > "$FSTAB_TEMPLATE" << 'FSTAB_HEADER'
# /etc/fstab: static file system information.
#
# Use 'blkid' to print the universally unique identifier for a
# device; this may be used with UUID= as a more robust way to name devices
# that works even if disks are added and removed. See fstab(5).
#
# <file system> <mount point>   <type>  <options>       <dump>  <pass>

FSTAB_HEADER

# Function to generate fstab entry with proper formatting
generate_fstab_entry() {
    local part_num=$1
    local part_dev=$2
    local uuid=$3
    local fstype=$4
    local mountpoint=$5
    
    # Skip if no UUID or unknown filesystem
    if [ "$uuid" = "unknown" ] || [ "$fstype" = "unknown" ]; then
        return
    fi
    
    # Determine mount point and options based on partition and current mount
    local mount_pt=""
    local options="defaults"
    local dump="0"
    local pass="0"
    
    case $part_num in
        1)  # EFI
            if [ "$fstype" = "vfat" ]; then
                mount_pt="/boot/efi"
                options="defaults"
                dump="0"
                pass="1"
            fi
            ;;
        2)  # Root
            if [ "$fstype" = "ext4" ] || [ "$fstype" = "btrfs" ] || [ "$fstype" = "xfs" ]; then
                mount_pt="/"
                options="defaults"
                dump="0"
                pass="1"
            fi
            ;;
        3)  # Var
            if [ "$fstype" = "ext4" ] || [ "$fstype" = "btrfs" ] || [ "$fstype" = "xfs" ]; then
                mount_pt="/var"
                options="defaults,nodev,nosuid"
                dump="0"
                pass="0"
            fi
            ;;
        4)  # Home
            if [ "$fstype" = "ext4" ] || [ "$fstype" = "btrfs" ] || [ "$fstype" = "xfs" ]; then
                mount_pt="/home"
                options="defaults,nodev,nosuid"
                dump="0"
                pass="0"
            fi
            ;;
        *)  # Additional partitions - use actual mount point or comment out
            if [ "$mountpoint" != "not_mounted" ] && [ "$mountpoint" != "" ] && [ "$mountpoint" != "/" ]; then
                mount_pt="$mountpoint"
                # Determine security options based on mount point
                case "$mountpoint" in
                    /var/log|/var/tmp|/tmp|/var/log/audit)
                        options="defaults,nodev,nosuid,noexec"
                        ;;
                    /app|/embedd_d|/extra)
                        options="defaults"
                        pass="1"
                        ;;
                    *)
                        options="defaults"
                        ;;
                esac
            else
                # Commented out entry for unmounted partitions
                echo "# /dev/disk/by-uuid/${uuid} /mnt/partition${part_num} ${fstype} defaults 0 0" >> "$FSTAB_TEMPLATE"
                return
            fi
            ;;
    esac
    
    if [ -n "$mount_pt" ]; then
        echo "/dev/disk/by-uuid/${uuid} ${mount_pt} ${fstype} ${options} ${dump} ${pass}" >> "$FSTAB_TEMPLATE"
    fi
}

echo ""

print_header "Recording All Partition Information"

# Save information for ALL partitions
echo "# All Partitions Information - Generated on $(date)" > "$ALL_PARTS_FILE"
echo "# Format: partition_number|device|uuid|fstype|size_bytes|size_mb|mountpoint" >> "$ALL_PARTS_FILE"
echo "" >> "$ALL_PARTS_FILE"

echo "# UUID Mapping File - Generated on $(date)" > "$UUID_MAP_FILE"
echo "# Format: partition_number:uuid:fstype:size_mb" >> "$UUID_MAP_FILE"
echo "# This file is used by restoration script to recreate partitions with exact UUIDs" >> "$UUID_MAP_FILE"
echo "" >> "$UUID_MAP_FILE"

for part_num in {1..20}; do
    part=$(get_partition_name $part_num)
    if [ -b "$part" ]; then
        uuid=$(blkid -s UUID -o value "$part" 2>/dev/null || echo "unknown")
        fstype=$(blkid -s TYPE -o value "$part" 2>/dev/null || echo "unknown")
        size_bytes=$(blockdev --getsize64 "$part" 2>/dev/null || echo "0")
        size_mb=$((size_bytes / 1024 / 1024))
        mountpoint=$(findmnt -n -o TARGET "$part" 2>/dev/null || echo "not_mounted")
        
        # Get PARTUUID as well (useful for GPT partitions)
        partuuid=$(blkid -s PARTUUID -o value "$part" 2>/dev/null || echo "unknown")
        
        # Determine label for main partitions
        case $part_num in
            1) label="efi" ;;
            2) label="root" ;;
            3) label="var" ;;
            4) label="home" ;;
            *) label="partition${part_num}" ;;
        esac
        
        # Save to all partitions info file
        echo "${part_num}|${part}|${uuid}|${fstype}|${size_bytes}|${size_mb}|${mountpoint}|${partuuid}" >> "$ALL_PARTS_FILE"
        
        # Save to partition sizes file (partition_number:size_in_MB)
        echo "${part_num}:${size_mb}" >> "$SIZES_FILE"
        
        # Save to UUID mapping file (machine-readable)
        echo "${part_num}:${uuid}:${fstype}:${size_mb}:${partuuid}" >> "$UUID_MAP_FILE"
        
        # Save to UUID file with labels for main partitions (human-readable)
        if [ $part_num -le 4 ]; then
            echo "${label}: $part, UUID=$uuid, PARTUUID=$partuuid, FS=$fstype, SIZE=${size_mb}MB, MOUNT=$mountpoint" >> "$UUID_FILE"
        else
            echo "partition${part_num}: $part, UUID=$uuid, PARTUUID=$partuuid, FS=$fstype, SIZE=${size_mb}MB, MOUNT=$mountpoint" >> "$UUID_FILE"
        fi
        
        # Generate fstab entry
        if [ "$uuid" != "unknown" ] && [ "$fstype" != "unknown" ]; then
            generate_fstab_entry "$part_num" "$part" "$uuid" "$fstype" "$mountpoint"
        fi
        
        print_info "Recorded: $part (${size_mb}MB, UUID=$uuid, FS=$fstype)"
    fi
done

print_success "All partition information recorded"

# Add swap and proc entries to fstab template
cat >> "$FSTAB_TEMPLATE" << 'FSTAB_FOOTER'

# Swap file (if applicable - uncomment and adjust path)
# /swap.img       none    swap    sw      0       0

# Proc filesystem with hidepid for security
proc /proc proc defaults,hidepid=2 0 0

FSTAB_FOOTER

print_success "fstab template generated: $FSTAB_TEMPLATE"
echo ""

# Create a restoration instructions file
RESTORE_INSTRUCTIONS="$BACKUP_DIR/RESTORE_INSTRUCTIONS.txt"
cat > "$RESTORE_INSTRUCTIONS" << 'EOF'
===========================================
PARTITION RESTORATION INSTRUCTIONS
===========================================

This backup contains the following files:

1. efi.img.gz, root.img.gz, var.img.gz, home.img.gz
   - Compressed partition images for the 4 main partitions

2. uuids.txt
   - Human-readable UUID information for all partitions

3. uuid_mapping.txt
   - Machine-readable UUID mapping (partition:uuid:fstype:size:partuuid)
   - Used by restoration script to recreate exact UUIDs

4. partition_sizes.txt
   - Exact partition sizes in MB (partition:size_mb)

5. all_partitions_info.txt
   - Detailed information about all partitions

6. fstab.backup
   - Exact copy of /etc/fstab from the target disk
   - This is your original fstab with all custom mount points and options

7. fstab.template
   - Auto-generated fstab based on discovered partitions
   - Good starting point if fstab.backup is not available

RESTORATION PROCESS:
====================

1. Boot from a live USB/CD
2. Run the restoration script
3. The script will:
   - Recreate ALL partitions with exact sizes from partition_sizes.txt
   - Restore images for EFI, Root, Var, Home partitions
   - Set UUIDs for all partitions from uuid_mapping.txt
   - Format additional partitions (5+) with correct filesystem
   - Restore UUIDs for additional partitions

4. After restoration, you may need to:
   - Copy fstab.backup to /etc/fstab on the restored system (recommended)
   - Or use fstab.template if fstab.backup is not available
   - Verify all mount points match your partition layout
   - Update bootloader if needed (grub-install, update-grub)
   - Verify UUID references in bootloader config
   - Create swap file if using /swap.img: dd if=/dev/zero of=/swap.img bs=1M count=SIZE

IMPORTANT NOTES:
================

- All partition UUIDs will be preserved exactly as they were
- fstab.backup contains your EXACT original fstab - use this first
- fstab.template is auto-generated as a fallback option
- Security mount options (nodev, nosuid, noexec) are preserved
- If UUIDs don't match after restoration, check uuid_mapping.txt
- You can manually set UUIDs using tune2fs (ext4) or other filesystem tools
- Don't forget to create /swap.img if your system uses a swap file

EOF

print_success "Restoration instructions created: $RESTORE_INSTRUCTIONS"
echo ""

# Backup function (only for main 4 partitions)
backup_partition() {
    local label="$1"
    local partition="$2"
    local backup_file="$BACKUP_DIR/${label}.img.gz"
    
    if [ ! -b "$partition" ]; then
        print_warn "Partition $partition not found, skipping."
        return
    fi
    
    # Check if backup already exists
    if [ -f "$backup_file" ]; then
        print_warn "Backup file $backup_file already exists"
        read -rp "Overwrite? (yes/no): " overwrite
        if [ "$overwrite" != "yes" ]; then
            print_info "Skipping $label"
            return
        fi
        rm -f "$backup_file"
    fi
    
    # Get partition info
    uuid=$(blkid -s UUID -o value "$partition" 2>/dev/null || echo "unknown")
    partuuid=$(blkid -s PARTUUID -o value "$partition" 2>/dev/null || echo "unknown")
    fstype=$(blkid -s TYPE -o value "$partition" 2>/dev/null || echo "unknown")
    
    # Get partition size in MB
    part_size_bytes=$(blockdev --getsize64 "$partition")
    part_size_mb=$((part_size_bytes / 1024 / 1024))
    
    print_header "Backing Up: $label"
    print_info "Partition: $partition"
    print_info "UUID: $uuid"
    print_info "PARTUUID: $partuuid"
    print_info "FS Type: $fstype"
    print_info "Size: ${part_size_mb}MB ($(echo "scale=2; $part_size_mb/1024" | bc)GB)"
    print_info "Output: $backup_file"
    echo ""
    
    # Check if partition is mounted
    if mountpoint -q "$(findmnt -n -o TARGET "$partition" 2>/dev/null)" 2>/dev/null; then
        print_warn "Partition $partition is currently mounted"
        print_warn "For best results, backup should be done on unmounted partitions"
        read -rp "Continue anyway? (yes/no): " continue_mounted
        if [ "$continue_mounted" != "yes" ]; then
            print_info "Skipping $label"
            return
        fi
    fi
    
    # Perform backup with compression
    print_info "Creating compressed image (this may take a while)..."
    
    # Use pigz (parallel gzip) if available, otherwise use gzip
    if command -v pigz &> /dev/null; then
        print_info "Using pigz (parallel compression) for faster backup"
        COMPRESS_CMD="pigz -9"
    else
        print_info "Using gzip (consider installing pigz for faster compression)"
        COMPRESS_CMD="gzip -9"
    fi
    
    # Use pv for progress if available
    if command -v pv &> /dev/null; then
        local part_size=$(blockdev --getsize64 "$partition")
        dd if="$partition" bs=16M status=none conv=sync,noerror iflag=fullblock | \
            pv -s "$part_size" -N "$label" -pterb | \
            $COMPRESS_CMD > "$backup_file"
    else
        dd if="$partition" bs=16M status=progress conv=sync,noerror iflag=fullblock | \
            $COMPRESS_CMD > "$backup_file"
    fi
    
    # Verify backup was created
    if [ -f "$backup_file" ]; then
        local compressed_size=$(du -h "$backup_file" | cut -f1)
        print_success "Backup completed: $backup_file"
        print_info "Compressed size: $compressed_size"
        
        # Show compression info
        print_info "Compression details:"
        gzip -l "$backup_file" 2>/dev/null || echo "  (compression info not available)"
    else
        print_error "Backup failed for $label"
    fi
    
    echo ""
}

# Backup only the 4 main partitions
print_header "Starting Image Backup Process"
echo ""

backup_partition "efi" "$P1"
backup_partition "root" "$P2"
backup_partition "var" "$P3"
backup_partition "home" "$P4"

# Final summary
print_header "Backup Complete"
print_success "All partition images backed up successfully!"
echo ""
print_info "Backup location: $BACKUP_DIR"
print_info "Image backup files:"

if [ -f "$BACKUP_DIR/efi.img.gz" ]; then
    echo "  ✓ efi.img.gz  - $(du -h "$BACKUP_DIR/efi.img.gz" | cut -f1)"
fi
if [ -f "$BACKUP_DIR/root.img.gz" ]; then
    echo "  ✓ root.img.gz - $(du -h "$BACKUP_DIR/root.img.gz" | cut -f1)"
fi
if [ -f "$BACKUP_DIR/var.img.gz" ]; then
    echo "  ✓ var.img.gz  - $(du -h "$BACKUP_DIR/var.img.gz" | cut -f1)"
fi
if [ -f "$BACKUP_DIR/home.img.gz" ]; then
    echo "  ✓ home.img.gz - $(du -h "$BACKUP_DIR/home.img.gz" | cut -f1)"
fi

echo ""
print_info "Configuration files:"
echo "  ✓ $UUID_FILE (human-readable UUID info)"
echo "  ✓ $UUID_MAP_FILE (machine-readable UUID mapping)"
echo "  ✓ $SIZES_FILE (partition sizes)"
echo "  ✓ $ALL_PARTS_FILE (detailed partition info)"
if [ -f "$FSTAB_BACKUP" ]; then
    echo "  ✓ $FSTAB_BACKUP (original fstab from target disk)"
fi
echo "  ✓ $FSTAB_TEMPLATE (generated fstab template)"
echo "  ✓ $RESTORE_INSTRUCTIONS (restoration guide)"
echo ""

print_info "UUID mapping file contents (for restoration):"
cat "$UUID_MAP_FILE"
echo ""

if [ -f "$FSTAB_BACKUP" ]; then
    print_info "Original fstab backup (use this in your installer):"
    echo "---"
    cat "$FSTAB_BACKUP"
    echo "---"
    echo ""
fi

print_info "Generated fstab template (fallback option):"
echo "---"
cat "$FSTAB_TEMPLATE"
echo "---"
echo ""

print_success "Backup completed successfully!"
print_info "Total backup size: $(du -sh "$BACKUP_DIR" | cut -f1)"
echo ""
print_info "To restore these backups, use the restoration script"
print_info "The restoration script will:"
echo "  - Recreate ALL partitions with exact sizes from $SIZES_FILE"
echo "  - Restore UUIDs for all partitions from $UUID_MAP_FILE"
echo "  - Restore images only for: EFI, Root, Var, Home"
echo "  - Format additional partitions (5+) with correct filesystem and UUID"
echo "  - Copy fstab.backup to /etc/fstab (or use fstab.template as fallback)"
echo ""
print_info "Read $RESTORE_INSTRUCTIONS for detailed restoration steps"
