#!/bin/bash
# ================================================================
# Kiosk Hardening: Disable background services & install tools
# Author: Jeric
# Purpose: Speed boot, reduce disk I/O, prevent auto-updates
# Target: Ubuntu 24.04
# ================================================================
set -euo pipefail

# Color codes for interactive display
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Progress spinner
spinner() {
    local pid=$1
    local delay=0.1
    local spinstr='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    while ps -p $pid > /dev/null 2>&1; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

# Progress bar function
show_progress() {
    local current=$1
    local total=$2
    local width=40
    local percentage=$((current * 100 / total))
    local completed=$((width * current / total))
    
    printf "\r${CYAN}Progress: [${NC}"
    for ((i=0; i<completed; i++)); do printf "█"; done
    for ((i=completed; i<width; i++)); do printf "░"; done
    printf "${CYAN}] ${BOLD}%3d%%${NC}" $percentage
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}${BOLD}ERROR:${NC} This script must be run as root (use sudo)"
   exit 1
fi

# Clear screen and show banner
clear
echo -e "${MAGENTA}${BOLD}"
cat << "EOF"
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║        KIOSK MODE SYSTEM HARDENING & OPTIMIZATION          ║
║                     Ubuntu 24.04 LTS                       ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"
echo -e "${CYAN}Author:${NC} Jeric"
echo -e "${CYAN}Purpose:${NC} Speed boot, reduce disk I/O, prevent auto-updates"
echo
echo -e "${YELLOW}⚠ WARNING:${NC} This will disable several system services"
echo -e "           Make sure you understand the implications"
echo
read -p "$(echo -e ${GREEN}"Press ENTER to continue or CTRL+C to cancel..."${NC})"
echo

TOTAL_STEPS=5
CURRENT_STEP=0

# ------------------------------------------------
# Step 0: System Check
# ------------------------------------------------
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}[STEP 0/5]${NC} ${BOLD}System Verification${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo

# Check Ubuntu version
if [[ -f /etc/os-release ]]; then
    source /etc/os-release
    echo -e "  ${BLUE}→${NC} OS: ${BOLD}$PRETTY_NAME${NC}"
    if [[ "$VERSION_ID" != "24.04" ]]; then
        echo -e "  ${YELLOW}⚠${NC} Warning: Optimized for Ubuntu 24.04, you're running $VERSION_ID"
    fi
fi

# Check disk space
AVAILABLE_SPACE=$(df -h / | awk 'NR==2 {print $4}')
echo -e "  ${BLUE}→${NC} Available disk space: ${BOLD}$AVAILABLE_SPACE${NC}"

# Check internet connectivity
echo -ne "  ${BLUE}→${NC} Checking internet connectivity... "
if ping -c 1 8.8.8.8 &>/dev/null; then
    echo -e "${GREEN}✓ Connected${NC}"
else
    echo -e "${RED}✗ No connection${NC}"
    echo -e "${YELLOW}⚠${NC} Internet required for package installation"
    exit 1
fi

echo
sleep 1

# ------------------------------------------------
# Step 1: Install required tools
# ------------------------------------------------
CURRENT_STEP=1
show_progress $CURRENT_STEP $TOTAL_STEPS
echo
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}[STEP 1/5]${NC} ${BOLD}Installing Required Tools${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo

export DEBIAN_FRONTEND=noninteractive

echo -ne "  ${BLUE}→${NC} Updating package lists... "
apt-get update -y > /tmp/apt-update.log 2>&1 &
spinner $!
wait $!
echo -e "${GREEN}✓${NC}"

echo -ne "  ${BLUE}→${NC} Installing pigz (parallel gzip)... "
apt-get install -y pigz > /tmp/pigz-install.log 2>&1 &
spinner $!
wait $!
echo -e "${GREEN}✓${NC}"

echo -ne "  ${BLUE}→${NC} Installing pv (pipe viewer)... "
apt-get install -y pv > /tmp/pv-install.log 2>&1 &
spinner $!
wait $!
echo -e "${GREEN}✓${NC}"

echo
echo -e "  ${GREEN}✔${NC} All tools installed successfully"
sleep 1

# ------------------------------------------------
# Step 2: Disable network wait-online
# ------------------------------------------------
CURRENT_STEP=2
show_progress $CURRENT_STEP $TOTAL_STEPS
echo
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}[STEP 2/5]${NC} ${BOLD}Disabling Network Wait Service${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo

echo -ne "  ${BLUE}→${NC} Stopping systemd-networkd-wait-online... "
systemctl disable --now systemd-networkd-wait-online.service > /dev/null 2>&1 || true
echo -e "${GREEN}✓${NC}"

echo -ne "  ${BLUE}→${NC} Masking service to prevent re-enable... "
systemctl mask systemd-networkd-wait-online.service > /dev/null 2>&1
echo -e "${GREEN}✓${NC}"

echo
echo -e "  ${GREEN}✔${NC} Network wait-online disabled (faster boot)"
sleep 1

# ------------------------------------------------
# Step 3: Disable journal upload
# ------------------------------------------------
CURRENT_STEP=3
show_progress $CURRENT_STEP $TOTAL_STEPS
echo
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}[STEP 3/5]${NC} ${BOLD}Disabling Journal Upload Service${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo

echo -ne "  ${BLUE}→${NC} Stopping systemd-journal-upload... "
systemctl disable --now systemd-journal-upload.service > /dev/null 2>&1 || true
echo -e "${GREEN}✓${NC}"

echo -ne "  ${BLUE}→${NC} Masking service... "
systemctl mask systemd-journal-upload.service > /dev/null 2>&1
echo -e "${GREEN}✓${NC}"

echo
echo -e "  ${GREEN}✔${NC} Journal upload disabled (reduced I/O)"
sleep 1

# ------------------------------------------------
# Step 4: Freeze Snap updates
# ------------------------------------------------
CURRENT_STEP=4
show_progress $CURRENT_STEP $TOTAL_STEPS
echo
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}[STEP 4/5]${NC} ${BOLD}Freezing Snap Auto-Updates${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo

if command -v snap >/dev/null 2>&1; then
    echo -ne "  ${BLUE}→${NC} Setting Snap refresh hold indefinitely... "
    snap set system refresh.hold="$(date --utc --date='9999-12-31 00:00:00' +%Y-%m-%dT%H:%M:%SZ)" > /dev/null 2>&1
    echo -e "${GREEN}✓${NC}"
    
    HOLD_DATE=$(snap get system refresh.hold 2>/dev/null || echo "Not set")
    echo -e "  ${BLUE}→${NC} Hold until: ${BOLD}$HOLD_DATE${NC}"
    
    echo
    echo -e "  ${GREEN}✔${NC} Snap auto-refresh frozen permanently"
else
    echo -e "  ${YELLOW}⚠${NC} Snap not installed — skipping this step"
fi
sleep 1

# ------------------------------------------------
# Step 5: Disable AIDE checks
# ------------------------------------------------
CURRENT_STEP=5
show_progress $CURRENT_STEP $TOTAL_STEPS
echo
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}[STEP 5/5]${NC} ${BOLD}Disabling AIDE Integrity Checks${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo

echo -ne "  ${BLUE}→${NC} Disabling AIDE daily check service... "
systemctl disable --now dailyaidecheck.service > /dev/null 2>&1 || true
echo -e "${GREEN}✓${NC}"

echo -ne "  ${BLUE}→${NC} Disabling AIDE daily check timer... "
systemctl disable --now dailyaidecheck.timer > /dev/null 2>&1 || true
echo -e "${GREEN}✓${NC}"

echo -ne "  ${BLUE}→${NC} Masking AIDE services... "
systemctl mask dailyaidecheck.service dailyaidecheck.timer > /dev/null 2>&1
echo -e "${GREEN}✓${NC}"

echo
echo -e "  ${GREEN}✔${NC} AIDE integrity checks disabled"
sleep 1

# ------------------------------------------------
# Final Summary
# ------------------------------------------------
echo
show_progress $TOTAL_STEPS $TOTAL_STEPS
echo
echo
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}${BOLD}           ✓ KIOSK HARDENING COMPLETE ✓${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo
echo -e "${CYAN}${BOLD}📦 Installed Tools:${NC}"
echo -e "  ${GREEN}✓${NC} pigz (parallel gzip)"
echo -e "  ${GREEN}✓${NC} pv (pipe viewer)"
echo
echo -e "${CYAN}${BOLD}🛡️  Disabled Services:${NC}"
echo -e "  ${GREEN}✓${NC} systemd-networkd-wait-online (faster boot)"
echo -e "  ${GREEN}✓${NC} systemd-journal-upload (reduced I/O)"
echo -e "  ${GREEN}✓${NC} Snap auto-refresh (no background updates)"
echo -e "  ${GREEN}✓${NC} AIDE daily integrity checks (reduced CPU)"
echo
echo -e "${CYAN}${BOLD}💡 Performance Benefits:${NC}"
echo -e "  ${BLUE}→${NC} Faster boot time"
echo -e "  ${BLUE}→${NC} Reduced disk I/O"
echo -e "  ${BLUE}→${NC} Lower CPU usage"
echo -e "  ${BLUE}→${NC} No unexpected updates"
echo
echo -e "${YELLOW}${BOLD}⚡ Next Steps:${NC}"
echo -e "  1. Review changes with: ${CYAN}systemctl list-unit-files | grep masked${NC}"
echo -e "  2. ${BOLD}Reboot system${NC} to apply all optimizations"
echo -e "  3. Monitor boot time with: ${CYAN}systemd-analyze${NC}"
echo
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo
read -p "$(echo -e ${GREEN}${BOLD}"Reboot now? (y/N): "${NC})" -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}Rebooting in 3 seconds...${NC}"
    sleep 3
    reboot
else
    echo -e "${CYAN}Remember to reboot later to apply all changes!${NC}"
fi
echo
