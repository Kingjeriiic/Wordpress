#!/bin/bash
# ETAP VPN Restoration Script
# Copyright 2021, Electronic Transfer and Advance Payment Inc.

DATE_START=$(date)
VPN_URL="https://vpnfile.etapinc.com:4443/ovpn-certs"
VPN_ECPAY_URL="https://vpnfile-ecpay.etapinc.com:4443/ovpn-certs"

echo ""
echo "ETAP VPN Restoration Tool"
echo "Copyright 2021, Electronic Transfer and Advance Payment Inc."
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
	echo "ERROR: Please run as root"
	exit 1
fi

# Cleanup function to ensure proper unmounting
cleanup() {
	if [ -n "$MOUNTED_PARTITION" ] && [ -d "$MOUNTED_PARTITION" ]; then
		echo "[$(date)] Cleaning up - unmounting $MOUNTED_PARTITION..."
		umount "$MOUNTED_PARTITION" 2>/dev/null
		rmdir "$MOUNTED_PARTITION" 2>/dev/null
	fi
}

# Set trap to cleanup on exit
trap cleanup EXIT

# Get the device of the current root /
DEV_ROOT=$(df -hT / | tail -1 | awk -F " " {'print $1'} | rev | cut -c 2- | rev)

# Get the device of the current folder pwd
DEV_PWD=$(df -hT . | tail -1 | awk -F " " {'print $1'} | rev | cut -c 2- | rev)

DEV_AVAILABLE=()

for i in `parted -l 2>/dev/null | grep dev | awk -F " " {'print $2'} | rev | cut -c 2- | rev`; do
	if [[ $DEV_ROOT = $i ]]; then
		continue
	elif [[ $DEV_PWD = $i ]]; then
		continue
	else
		DEV_AVAILABLE+=($i)
	fi
done

echo "Detected devices (excluding current system):"
ctr=0
for i in ${!DEV_AVAILABLE[@]}; do
	((ctr=$i+1))
	SIZE=$(lsblk -b -d -o SIZE ${DEV_AVAILABLE[$i]} 2>/dev/null | tail -1 | numfmt --to=iec 2>/dev/null || echo "Unknown")
	echo "[$ctr] ${DEV_AVAILABLE[$i]} - Size: $SIZE"
done

if [ ${#DEV_AVAILABLE[@]} -eq 0 ]; then
	echo ""
	echo "No additional devices found."
	echo "The system will restore VPN to the current running system"
	echo ""
	TARGET_DEVICE=$DEV_ROOT
	TARGET_ROOT=$(df -hT / | tail -1 | awk -F " " {'print $1'})
	VPN_CONFIG_PATH="/etc/openvpn"
	MOUNTED_PARTITION=""
else
	echo ""
	echo "[0] Restore to current running system"
	echo ""
	unset number
	until [[ $number == +([0-9]) ]] && [ $number -ge 0 ] && [ $number -le ${#DEV_AVAILABLE[@]} ]; do
		read -r -p "Select the device to restore VPN (or 0 for current system): " number
	done

	if [ $number -eq 0 ]; then
		echo "Selected: Current running system"
		TARGET_ROOT=$(df -hT / | tail -1 | awk -F " " {'print $1'})
		VPN_CONFIG_PATH="/etc/openvpn"
		MOUNTED_PARTITION=""
	else
		DEV_SELECTED=${DEV_AVAILABLE[(($number-1))]}
		echo "Selected device: $DEV_SELECTED"
		echo ""

		# List available partitions on the selected device
		echo "Available partitions on $DEV_SELECTED:"
		PARTITIONS=()
		for part in /dev/$(basename $DEV_SELECTED)*; do
			if [ -b "$part" ] && [ "$part" != "$DEV_SELECTED" ]; then
				PARTITIONS+=("$part")
				PART_SIZE=$(lsblk -b -o SIZE "$part" 2>/dev/null | tail -1 | numfmt --to=iec 2>/dev/null || echo "Unknown")
				PART_FS=$(lsblk -n -o FSTYPE "$part" 2>/dev/null || echo "Unknown")
				PART_LABEL=$(lsblk -n -o LABEL "$part" 2>/dev/null || echo "")
				echo "  [${#PARTITIONS[@]}] $part - Size: $PART_SIZE, FS: $PART_FS, Label: $PART_LABEL"
			fi
		done

		if [ ${#PARTITIONS[@]} -eq 0 ]; then
			echo "ERROR: No partitions found on $DEV_SELECTED"
			exit 1
		fi

		echo ""
		unset part_number
		until [[ $part_number == +([0-9]) ]] && [ $part_number -ge 1 ] && [ $part_number -le ${#PARTITIONS[@]} ]; do
			read -r -p "Select the partition number: " part_number
		done

		TARGET_PARTITION=${PARTITIONS[(($part_number-1))]}
		echo "Selected partition: $TARGET_PARTITION"
		echo ""

		# Check if partition exists
		if [ ! -b "$TARGET_PARTITION" ]; then
			echo "ERROR: Partition $TARGET_PARTITION does not exist"
			exit 1
		fi

		# Create mount point
		MOUNT_NAME=$(basename $TARGET_PARTITION)
		MOUNTED_PARTITION="/mnt/$MOUNT_NAME"

		# Mount the target partition
		echo "[$(date)] Mounting target partition..."
		mkdir -p "$MOUNTED_PARTITION"
		mount -t auto "$TARGET_PARTITION" "$MOUNTED_PARTITION"

		if [ $? != 0 ]; then
			echo "ERROR: Failed to mount $TARGET_PARTITION"
			rmdir "$MOUNTED_PARTITION" 2>/dev/null
			exit 1
		fi

		echo "[$(date)] Successfully mounted $TARGET_PARTITION at $MOUNTED_PARTITION"
		echo ""
		echo "Contents of mounted partition:"
		ls -la "$MOUNTED_PARTITION" | head -20
		echo ""

		# Try to find OpenVPN directory
		VPN_CONFIG_PATH="$MOUNTED_PARTITION/etc/openvpn"
		
		if [ ! -d "$VPN_CONFIG_PATH" ]; then
			echo "WARNING: Standard VPN path not found: $VPN_CONFIG_PATH"
			echo ""
			echo "Searching for OpenVPN configuration..."
			
			# Search for openvpn directories
			FOUND_PATHS=$(find "$MOUNTED_PARTITION" -type d -name "openvpn" 2>/dev/null)
			
			if [ -n "$FOUND_PATHS" ]; then
				echo "Found potential OpenVPN directories:"
				select vpn_path in $FOUND_PATHS "Enter custom path" "Cancel"; do
					case $vpn_path in
						"Enter custom path")
							read -r -p "Enter full path to OpenVPN config directory: " custom_path
							VPN_CONFIG_PATH="$custom_path"
							break
							;;
						"Cancel")
							echo "Operation cancelled."
							exit 0
							;;
						*)
							if [ -n "$vpn_path" ]; then
								VPN_CONFIG_PATH="$vpn_path"
								break
							fi
							;;
					esac
				done
			else
				echo "No OpenVPN directories found."
				read -r -p "Enter full path to OpenVPN config directory (or press Enter to cancel): " custom_path
				if [ -z "$custom_path" ]; then
					echo "Operation cancelled."
					exit 0
				fi
				VPN_CONFIG_PATH="$custom_path"
			fi
		fi
	fi
fi

# Final check if VPN directory exists
if [ ! -d "$VPN_CONFIG_PATH" ]; then
	echo "ERROR: VPN configuration directory not found: $VPN_CONFIG_PATH"
	exit 1
fi

# Create VPN directory if it doesn't exist
mkdir -p "$VPN_CONFIG_PATH"

echo ""
echo "VPN will be restored to: $VPN_CONFIG_PATH"
echo "Current VPN configuration files:"
ls -lh $VPN_CONFIG_PATH/*.conf 2>/dev/null || echo "No .conf files found"
echo ""

echo -n "Please enter VPN filename (ex: kiosk00001): "
read VPN_FILENAME

if [ -z "$VPN_FILENAME" ]; then
	echo "ERROR: VPN filename cannot be empty"
	exit 1
fi

echo ""
echo "This will replace existing VPN configuration with: $VPN_FILENAME"
echo -n "Are you sure you want to continue? (Y/n): "
read continue

if [[ $continue != "Y" ]]; then
	echo "VPN restoration canceled."
	exit 0
fi

echo ""
echo "[$(date)] Backing up existing VPN configuration..."
if ls $VPN_CONFIG_PATH/*.conf 1> /dev/null 2>&1; then
	mkdir -p $VPN_CONFIG_PATH/backup
	cp $VPN_CONFIG_PATH/*.conf $VPN_CONFIG_PATH/backup/ 2>/dev/null
	echo "[$(date)] Backup created in $VPN_CONFIG_PATH/backup/"
fi

echo "[$(date)] Removing old VPN configuration..."
rm -f $VPN_CONFIG_PATH/*.conf

echo "[$(date)] Downloading new VPN configuration..."
wget --no-check-certificate $VPN_URL/$VPN_FILENAME".ovpn" -O $VPN_CONFIG_PATH/$VPN_FILENAME".conf"

if [ $? != 0 ]; then
	echo "[$(date)] Primary VPN server failed, trying backup server..."
	wget --no-check-certificate $VPN_ECPAY_URL/$VPN_FILENAME".ovpn" -O $VPN_CONFIG_PATH/$VPN_FILENAME".conf"

	if [ $? != 0 ]; then
		echo "[$(date)] ERROR: Unable to download VPN file from both servers!"
		echo "[$(date)] Restoring from backup..."
		cp $VPN_CONFIG_PATH/backup/*.conf $VPN_CONFIG_PATH/ 2>/dev/null
		exit 1
	fi
fi

echo "[$(date)] VPN configuration downloaded successfully!"
echo ""
echo "New VPN configuration:"
ls -lh $VPN_CONFIG_PATH/*.conf
echo ""

# Check if OpenVPN service exists and offer to restart
if [ -z "$MOUNTED_PARTITION" ]; then
	# Only restart service if working on current system
	if systemctl list-unit-files | grep -q openvpn; then
		echo -n "Do you want to restart OpenVPN service now? (Y/n): "
		read restart_service

		if [[ $restart_service == "Y" ]]; then
			echo "[$(date)] Restarting OpenVPN service..."
			systemctl restart openvpn
			sleep 2
			systemctl status openvpn --no-pager
		fi
	fi
else
	echo ""
	echo "NOTE: VPN restored to external device."
	echo "OpenVPN service will start automatically on next boot of the target device."
fi

echo ""
echo "[$(date)] VPN restoration completed successfully!"
echo ""

# Cleanup happens automatically via trap
