#!/bin/bash
# Script to reverse USB storage blocking (reverses rule 1.1.1.9)
# This re-enables the usb-storage kernel module

set -e

echo "Starting USB storage re-enablement process..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root"
    exit 1
fi

# Function to safely remove lines from config files
remove_usb_storage_block() {
    local file=$1
    local pattern=$2

    if [ -f "$file" ]; then
        echo "Checking $file..."
        if grep -q "$pattern" "$file"; then
            sed -i "/$pattern/d" "$file"
            echo "  ✓ Removed USB storage block from $file"
        else
            echo "  - No USB storage block found in $file"
        fi
    else
        echo "  - File $file does not exist"
    fi
}

# Remove usb-storage install block from /etc/modprobe.d/CIS.conf
remove_usb_storage_block "/etc/modprobe.d/CIS.conf" "^install usb-storage"

# Remove usb-storage blacklist from /etc/modprobe.d/blacklist.conf
remove_usb_storage_block "/etc/modprobe.d/blacklist.conf" "^blacklist usb-storage"

# Clean up empty files
for conf_file in "/etc/modprobe.d/CIS.conf" "/etc/modprobe.d/blacklist.conf"; do
    if [ -f "$conf_file" ] && [ ! -s "$conf_file" ]; then
        echo "Removing empty file: $conf_file"
        rm -f "$conf_file"
    fi
done

# Re-enable the usb-storage module if it's currently blocked
echo "Attempting to load usb-storage module..."
if ! lsmod | grep -q usb_storage; then
    if modprobe usb-storage 2>/dev/null; then
        echo "  ✓ usb-storage module loaded successfully"
    else
        echo "  ! usb-storage module could not be loaded (may require reboot)"
    fi
else
    echo "  - usb-storage module already loaded"
fi

# Verify the module is available
if lsmod | grep -q usb_storage; then
    echo ""
    echo "SUCCESS: USB storage has been re-enabled"
    echo "USB storage devices should now be functional"
else
    echo ""
    echo "WARNING: Changes applied but module not currently loaded"
    echo "A system reboot may be required for changes to take full effect"
fi

echo ""
echo "Reversal complete!"
