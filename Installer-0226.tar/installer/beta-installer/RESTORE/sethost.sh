#!/bin/bash
# Hostname Setup Script for ETAP Installer
# Sets hostname based on user input (TERMINAL_ID)
# Usage: ./set-hostname.sh <target_disk> [terminal_id]

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check if target disk is provided
if [ $# -lt 1 ]; then
    echo "Usage: $0 <target_disk> [terminal_id]"
    echo "Example: $0 /dev/sdb KIOSK001"
    echo "Example: $0 /dev/sdb (will prompt for terminal ID)"
    exit 1
fi

TARGET_DISK="$1"

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Validate target disk
if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

# Safety check: Exclude sda disk
if [[ "$TARGET_DISK" == "/dev/sda"* ]]; then
    print_error "SAFETY ERROR: sda disk is excluded for safety!"
    print_error "sda is typically the installer/system disk."
    print_error "Supported disks: sdb, sdc, nvme*"
    exit 1
fi

# Get root partition (partition 2)
ROOT_PART=$(get_partition_name 2)

if [ ! -b "$ROOT_PART" ]; then
    print_error "Root partition $ROOT_PART not found."
    print_error "Make sure the disk has been properly partitioned and restored."
    exit 1
fi

# Banner
print_header "ETAP Hostname Setup"
echo ""
echo "Target disk: $TARGET_DISK"
echo "Root partition: $ROOT_PART"
echo ""

# Get terminal ID from command line or prompt user
if [ $# -ge 2 ]; then
    TERMINAL_ID="$2"
    print_info "Using provided terminal ID: $TERMINAL_ID"
else
    echo "Enter the terminal ID for this system:"
    echo "Examples: KIOSK001, TERMINAL-A1, ETAP-BRANCH-01"
    echo ""
    read -rp "Terminal ID: " TERMINAL_ID
fi

# Validate terminal ID
if [ -z "$TERMINAL_ID" ]; then
    print_error "Terminal ID cannot be empty"
    exit 1
fi

# Clean terminal ID (remove spaces, convert to uppercase for consistency)
KIOSK_HOSTNAME=$(echo "$TERMINAL_ID" | tr '[:lower:]' '[:upper:]' | tr -d ' ')

print_info "Setting hostname to: $KIOSK_HOSTNAME"
echo ""

# Mount root partition
MOUNT_POINT="/mnt/hostname_setup"
mkdir -p "$MOUNT_POINT"

print_info "Mounting root partition..."
if mount "$ROOT_PART" "$MOUNT_POINT" 2>/dev/null; then
    print_success "Mounted root partition at $MOUNT_POINT"
else
    print_error "Failed to mount root partition $ROOT_PART"
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

# Set hostname
print_header "Setting Hostname"
print_info "[$(date)] Setting Hostname to: $KIOSK_HOSTNAME"

# Update /etc/hostname
if echo "$KIOSK_HOSTNAME" > "$MOUNT_POINT/etc/hostname"; then
    print_success "Updated /etc/hostname"
else
    print_error "Failed to update /etc/hostname"
    umount "$MOUNT_POINT" 2>/dev/null || true
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

# Update /etc/hosts
print_info "Updating /etc/hosts..."

# Backup original hosts file
if [ -f "$MOUNT_POINT/etc/hosts" ]; then
    cp "$MOUNT_POINT/etc/hosts" "$MOUNT_POINT/etc/hosts.backup" 2>/dev/null || true
fi

# Update the second line (127.0.1.1) with the new hostname
if sed -e "2s/.*/127.0.1.1 $KIOSK_HOSTNAME/" -i "$MOUNT_POINT/etc/hosts" 2>/dev/null; then
    print_success "Updated /etc/hosts"
else
    print_warn "Could not update /etc/hosts automatically"
    print_info "You may need to manually edit /etc/hosts after first boot"
fi

# Show the updated files
print_info "Hostname configuration:"
echo "----------------------------------------"
echo "/etc/hostname:"
cat "$MOUNT_POINT/etc/hostname" 2>/dev/null || echo "Could not read hostname file"
echo ""
echo "/etc/hosts:"
head -5 "$MOUNT_POINT/etc/hosts" 2>/dev/null || echo "Could not read hosts file"
echo "----------------------------------------"

# Unmount
print_info "Unmounting root partition..."
if umount "$MOUNT_POINT" 2>/dev/null; then
    print_success "Unmounted root partition"
else
    print_warn "Could not unmount cleanly, but changes were saved"
fi

rmdir "$MOUNT_POINT" 2>/dev/null || true

# Summary
print_header "Hostname Setup Complete"
print_success "Hostname has been set to: $KIOSK_HOSTNAME"
echo ""
print_info "The system will use this hostname after the next boot."
print_info "You can verify the hostname after boot with: hostname"
echo ""
print_warn "Note: If you need to change the hostname later:"
echo "  1. Edit /etc/hostname"
echo "  2. Edit /etc/hosts (update the 127.0.1.1 line)"
echo "  3. Reboot or run: sudo hostnamectl set-hostname NEW_HOSTNAME"
echo ""
print_success "Hostname setup completed successfully!"
