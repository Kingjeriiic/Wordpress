#!/bin/bash

# Restoration Script for 4 Main Partitions (EFI, Root, Var, Home)
# Restores raw images from /extra/os with UUID preservation
# Recreates ALL partitions with exact sizes and UUIDs

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
BACKUP_DIR="/extra/os/base-images"

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Banner
clear
print_header "4-Partition Restoration System (Raw Images)"
echo ""
echo "This will restore EFI, Root, Var, and Home partitions from raw images"
echo "All partitions will be recreated with exact sizes and UUIDs"
echo "Backup location: $BACKUP_DIR"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check if backup directory exists
if [ ! -d "$BACKUP_DIR" ]; then
    print_error "Backup directory $BACKUP_DIR not found"
    exit 1
fi

# Check for required backup files (now .img instead of .img.gz)
REQUIRED_FILES=("partition_sizes.txt" "uuid_mapping.txt" "efi.img" "root.img" "var.img" "home.img")
MISSING_FILES=()

for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$BACKUP_DIR/$file" ]; then
        MISSING_FILES+=("$file")
    fi
done

if [ ${#MISSING_FILES[@]} -gt 0 ]; then
    print_error "Missing required backup files:"
    for file in "${MISSING_FILES[@]}"; do
        echo "  - $file"
    done
    exit 1
fi

print_success "All required backup files found"
echo ""

# Show available disks
print_header "Available Disks"
lsblk -o NAME,SIZE,TYPE,MOUNTPOINT
echo ""

# Ask user which disk to restore to
print_warn "WARNING: This will DESTROY all data on the target disk!"
echo ""
read -rp "Enter the target disk for restoration (e.g., sda, sdb, nvme0n1): " disk_input
TARGET_DISK="/dev/$disk_input"

if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

print_info "Selected disk: $TARGET_DISK"
echo ""

# Show current partitions on target disk
print_info "Current partitions on $TARGET_DISK:"
lsblk "$TARGET_DISK"
echo ""

# Final confirmation
print_warn "ALL DATA ON $TARGET_DISK WILL BE DESTROYED!"
print_warn "This action CANNOT be undone!"
echo ""
read -rp "Type 'YES' (in capitals) to confirm: " final_confirm

if [ "$final_confirm" != "YES" ]; then
    print_info "Restoration cancelled"
    exit 0
fi

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Unmount any mounted partitions from target disk
print_header "Unmounting Target Disk Partitions"
umount ${TARGET_DISK}* 2>/dev/null || true
swapoff ${TARGET_DISK}* 2>/dev/null || true
print_success "Target disk unmounted"
echo ""

# Wipe disk and create fresh partition table
print_header "Wiping Disk and Creating Partition Table"
print_info "Wiping partition table..."
wipefs -af "$TARGET_DISK" 2>/dev/null || true
dd if=/dev/zero of="$TARGET_DISK" bs=1M count=100 conv=fsync 2>/dev/null || true

print_info "Creating GPT partition table..."
parted -s "$TARGET_DISK" mklabel gpt
print_success "GPT partition table created"
echo ""

# Define fixed partition sizes (in MiB)
print_header "Partition Layout Configuration"
EFI_SIZE=1536        # 1.5GB for EFI (unchanged)
ROOT_SIZE=30720      # 30GB for Root (increased from 20GB)
VAR_SIZE=15360       # 15GB for Var (increased from 10GB)
HOME_SIZE=5120       # 5GB for Home (matches request)
VARLOG_SIZE=5120     # 5GB for /var/log
VARTMP_SIZE=2048     # 2GB for /var/tmp
VARAUDIT_SIZE=5120   # 5GB for /var/log/audit
EMBEDD_SIZE=2048     # 2GB for /embedd_d
APP_SIZE=10240       # 10GB for /app
TMP_SIZE=3072        # 3GB for /tmp
# EXTRA will use remaining space

print_info "Partition 1 (EFI): ${EFI_SIZE}MB (1.5GB)"
print_info "Partition 2 (Root /): ${ROOT_SIZE}MB (30GB) - Image ~20GB, will be expanded"
print_info "Partition 3 (Var): ${VAR_SIZE}MB (15GB) - Image ~10GB, will be expanded"
print_info "Partition 4 (Home): ${HOME_SIZE}MB (5GB)"
print_info "Partition 5 (/var/log): ${VARLOG_SIZE}MB (5GB)"
print_info "Partition 6 (/var/tmp): ${VARTMP_SIZE}MB (2GB)"
print_info "Partition 7 (/var/log/audit): ${VARAUDIT_SIZE}MB (5GB)"
print_info "Partition 8 (/embedd_d): ${EMBEDD_SIZE}MB (2GB)"
print_info "Partition 9 (/app): ${APP_SIZE}MB (10GB)"
print_info "Partition 10 (/tmp): ${TMP_SIZE}MB (3GB)"
print_info "Partition 11 (/extra): Remaining space"
echo ""

# Calculate total disk size needed
TOTAL_FIXED=$((EFI_SIZE + ROOT_SIZE + VAR_SIZE + HOME_SIZE + VARLOG_SIZE + VARTMP_SIZE + VARAUDIT_SIZE + EMBEDD_SIZE + APP_SIZE + TMP_SIZE))
TOTAL_FIXED_GB=$(echo "scale=2; $TOTAL_FIXED/1024" | bc)
print_info "Total fixed partitions: ${TOTAL_FIXED}MB (${TOTAL_FIXED_GB}GB)"

# Get target disk size
disk_size_bytes=$(blockdev --getsize64 "$TARGET_DISK")
disk_size_mb=$((disk_size_bytes / 1024 / 1024))
disk_size_gb=$(echo "scale=2; $disk_size_mb/1024" | bc)
print_info "Target disk size: ${disk_size_mb}MB (${disk_size_gb}GB)"

# Check if disk is large enough
if [ $disk_size_mb -lt $TOTAL_FIXED ]; then
    print_error "Disk is too small! Need at least ${TOTAL_FIXED_GB}GB but disk is ${disk_size_gb}GB"
    exit 1
fi

remaining=$((disk_size_mb - TOTAL_FIXED - 2))  # Leave 2MB margin
remaining_gb=$(echo "scale=2; $remaining/1024" | bc)
print_info "Space for /extra partition: ${remaining}MB (${remaining_gb}GB)"
echo ""

# Read UUID mappings
print_header "Reading UUID Mappings"
declare -A PARTITION_UUIDS
declare -A PARTITION_FSTYPES
declare -A PARTITION_PARTUUIDS

while IFS=':' read -r part_num uuid fstype size_mb partuuid; do
    # Skip empty lines and comments
    [[ -z "$part_num" || "$part_num" =~ ^# ]] && continue
    PARTITION_UUIDS[$part_num]=$uuid
    PARTITION_FSTYPES[$part_num]=$fstype
    PARTITION_PARTUUIDS[$part_num]=$partuuid
    print_info "Partition $part_num: UUID=$uuid, FS=$fstype"
done < "$BACKUP_DIR/uuid_mapping.txt"
echo ""

# Create partitions with fixed sizes
print_header "Creating Partitions"
start=1  # Start at 1MiB

# Partition 1: EFI (1.5GB)
end=$((start + EFI_SIZE))
print_info "Creating partition 1 (EFI): ${start}MiB - ${end}MiB (1.5GB)"
parted -s "$TARGET_DISK" mkpart primary fat32 ${start}MiB ${end}MiB
parted -s "$TARGET_DISK" set 1 esp on
start=$end

# Partition 2: Root (30GB)
end=$((start + ROOT_SIZE))
print_info "Creating partition 2 (Root /): ${start}MiB - ${end}MiB (30GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 ${start}MiB ${end}MiB
start=$end

# Partition 3: Var (10GB)
end=$((start + VAR_SIZE))
print_info "Creating partition 3 (Var): ${start}MiB - ${end}MiB (10GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 ${start}MiB ${end}MiB
start=$end

# Partition 4: Home (5GB)
end=$((start + HOME_SIZE))
print_info "Creating partition 4 (Home): ${start}MiB - ${end}MiB (5GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 ${start}MiB ${end}MiB
start=$end

# Partition 5: /var/log (5GB)
end=$((start + VARLOG_SIZE))
print_info "Creating partition 5 (/var/log): ${start}MiB - ${end}MiB (5GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 ${start}MiB ${end}MiB
start=$end

# Partition 6: /var/tmp (2GB)
end=$((start + VARTMP_SIZE))
print_info "Creating partition 6 (/var/tmp): ${start}MiB - ${end}MiB (2GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 ${start}MiB ${end}MiB
start=$end

# Partition 7: /var/log/audit (5GB)
end=$((start + VARAUDIT_SIZE))
print_info "Creating partition 7 (/var/log/audit): ${start}MiB - ${end}MiB (5GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 ${start}MiB ${end}MiB
start=$end

# Partition 8: /embedd_d (2GB)
end=$((start + EMBEDD_SIZE))
print_info "Creating partition 8 (/embedd_d): ${start}MiB - ${end}MiB (2GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 ${start}MiB ${end}MiB
start=$end

# Partition 9: /app (10GB)
end=$((start + APP_SIZE))
print_info "Creating partition 9 (/app): ${start}MiB - ${end}MiB (10GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 ${start}MiB ${end}MiB
start=$end

# Partition 10: /tmp (3GB)
end=$((start + TMP_SIZE))
print_info "Creating partition 10 (/tmp): ${start}MiB - ${end}MiB (3GB)"
parted -s "$TARGET_DISK" mkpart primary ext4 ${start}MiB ${end}MiB
start=$end

# Partition 11: /extra (remaining space)
end=$((disk_size_mb - 1))  # Leave 1MB at end
remaining_size=$((end - start))
remaining_gb=$(echo "scale=2; $remaining_size/1024" | bc)
print_info "Creating partition 11 (/extra): ${start}MiB - ${end}MiB (${remaining_size}MB = ${remaining_gb}GB remaining)"
parted -s "$TARGET_DISK" mkpart primary ext4 ${start}MiB ${end}MiB

print_success "All partitions created"
echo ""

# Wait for kernel to update partition table
print_info "Waiting for partition table to update..."
sleep 2
partprobe "$TARGET_DISK" 2>/dev/null || true
sleep 2
echo ""

# Restore images for main 4 partitions
restore_partition_image() {
    local part_num=$1
    local label=$2
    local partition=$(get_partition_name $part_num)
    local image_file="$BACKUP_DIR/${label}.img"

    if [ ! -f "$image_file" ]; then
        print_warn "Image file $image_file not found, skipping"
        return
    fi

    if [ ! -b "$partition" ]; then
        print_error "Partition $partition not found"
        return 1
    fi

    print_header "Restoring: $label (Partition $part_num)"
    print_info "Image: $image_file"
    print_info "Target: $partition"
    print_info "Image size: $(du -h "$image_file" | cut -f1)"

    # Get partition size
    local part_size=$(blockdev --getsize64 "$partition" 2>/dev/null || echo "0")
    local part_size_mb=$((part_size / 1024 / 1024))
    print_info "Partition size: ${part_size_mb}MB"

    # Get image size
    local image_size=$(stat -c%s "$image_file")
    local image_mb=$((image_size / 1024 / 1024))
    print_info "Image file size: ${image_mb}MB"

    # Check if partition is large enough
    if [ "$image_size" -gt "$part_size" ]; then
        print_error "Partition too small! Need ${image_mb}MB but partition is ${part_size_mb}MB"
        print_error "The backup image is larger than the partition size."
        read -rp "Continue anyway? Data may be truncated! (yes/no): " continue_anyway
        if [ "$continue_anyway" != "yes" ]; then
            print_info "Skipping $label restoration"
            return
        fi
    fi

    echo ""

    # Write raw image directly to partition
    print_info "Writing raw image to partition (this may take a while)..."

    # Use pv for progress if available
    if command -v pv &> /dev/null; then
        pv -N "$label" -pterb "$image_file" | \
            dd of="$partition" bs=16M conv=sync,noerror oflag=sync status=none iflag=fullblock
    else
        dd if="$image_file" of="$partition" bs=16M conv=sync,noerror oflag=sync status=progress iflag=fullblock
    fi

    local dd_exit=$?
    sync

    if [ $dd_exit -eq 0 ]; then
        print_success "Image restored: $label"
    else
        print_warn "Image restoration completed with warnings for: $label"
    fi
    echo ""
}

# Restore main 4 partitions
print_header "Restoring Partition Images"
echo ""

restore_partition_image 1 "efi"
if [ -f "$BACKUP_DIR/efi.img" ]; then
    partition=$(get_partition_name 1)
    fstype=${PARTITION_FSTYPES[1]:-vfat}
    print_info "Formatting partition 1 ($partition) as $fstype"
    print_success "Formatted $partition as $fstype"
fi

restore_partition_image 2 "root"
if [ -f "$BACKUP_DIR/root.img" ]; then
    partition=$(get_partition_name 2)
    fstype=${PARTITION_FSTYPES[2]:-ext4}
    print_info "Formatting partition 2 ($partition) as $fstype"
    print_success "Formatted $partition as $fstype"
fi

restore_partition_image 3 "var"
if [ -f "$BACKUP_DIR/var.img" ]; then
    partition=$(get_partition_name 3)
    fstype=${PARTITION_FSTYPES[3]:-ext4}
    print_info "Formatting partition 3 ($partition) as $fstype"
    print_success "Formatted $partition as $fstype"
fi

restore_partition_image 4 "home"
if [ -f "$BACKUP_DIR/home.img" ]; then
    partition=$(get_partition_name 4)
    fstype=${PARTITION_FSTYPES[4]:-ext4}
    print_info "Formatting partition 4 ($partition) as $fstype"
    print_success "Formatted $partition as $fstype"
fi

# Expand filesystems to fill larger partitions
print_header "Expanding Filesystems to Fill Partitions"
echo ""

expand_filesystem() {
    local part_num=$1
    local label=$2
    local partition=$(get_partition_name $part_num)
    local fstype=${PARTITION_FSTYPES[$part_num]}

    if [ ! -b "$partition" ]; then
        print_warn "Partition $partition not found, skipping expansion"
        return
    fi

    print_info "Expanding $label ($partition, $fstype)..."

    case $fstype in
        ext4|ext3|ext2)
            # First check and repair filesystem if needed
            e2fsck -fy "$partition" > /dev/null 2>&1 || true
            # Resize filesystem to fill partition
            resize2fs "$partition" > /dev/null 2>&1
            if [ $? -eq 0 ]; then
                print_success "Expanded $label filesystem to fill partition"
            else
                print_warn "Could not expand $label filesystem (may already be correct size)"
            fi
            ;;
        xfs)
            # XFS needs to be mounted to expand
            TEMP_MOUNT="/mnt/temp_xfs_${part_num}"
            mkdir -p "$TEMP_MOUNT"
            if mount "$partition" "$TEMP_MOUNT" 2>/dev/null; then
                xfs_growfs "$TEMP_MOUNT" > /dev/null 2>&1
                if [ $? -eq 0 ]; then
                    print_success "Expanded $label filesystem to fill partition"
                else
                    print_warn "Could not expand $label filesystem"
                fi
                umount "$TEMP_MOUNT"
            else
                print_warn "Could not mount $partition for XFS expansion"
            fi
            rmdir "$TEMP_MOUNT" 2>/dev/null || true
            ;;
        vfat|fat32)
            # FAT filesystems don't need expansion in the same way
            print_info "$label (FAT) doesn't need expansion"
            ;;
        btrfs)
            # Btrfs needs to be mounted to expand
            TEMP_MOUNT="/mnt/temp_btrfs_${part_num}"
            mkdir -p "$TEMP_MOUNT"
            if mount "$partition" "$TEMP_MOUNT" 2>/dev/null; then
                btrfs filesystem resize max "$TEMP_MOUNT" > /dev/null 2>&1
                if [ $? -eq 0 ]; then
                    print_success "Expanded $label filesystem to fill partition"
                else
                    print_warn "Could not expand $label filesystem"
                fi
                umount "$TEMP_MOUNT"
            else
                print_warn "Could not mount $partition for btrfs expansion"
            fi
            rmdir "$TEMP_MOUNT" 2>/dev/null || true
            ;;
        *)
            print_warn "Unknown filesystem type for expansion: $fstype"
            ;;
    esac
}

# Expand Root (20GB image -> 30GB partition)
if [ -f "$BACKUP_DIR/root.img" ]; then
    expand_filesystem 2 "Root"
fi

# Expand Var (10GB image -> 15GB partition)
if [ -f "$BACKUP_DIR/var.img" ]; then
    expand_filesystem 3 "Var"
fi

# Home should already match (5GB)
# EFI doesn't need expansion (FAT filesystem)

print_success "Filesystem expansion complete"
echo ""

# Format additional partitions (5-11)
print_header "Formatting Additional Partitions"

# Map partition numbers to their filesystems (from your fstab)
declare -A PART_FS_MAP
PART_FS_MAP[5]="ext4"   # /var/log
PART_FS_MAP[6]="ext4"   # /var/tmp
PART_FS_MAP[7]="ext4"   # /var/log/audit
PART_FS_MAP[8]="ext4"   # /embedd_d
PART_FS_MAP[9]="ext4"   # /app
PART_FS_MAP[10]="ext4"  # /tmp
PART_FS_MAP[11]="ext4"  # /extra

for part_num in {5..11}; do
    partition=$(get_partition_name $part_num)
    fstype=${PART_FS_MAP[$part_num]}

    if [ ! -b "$partition" ]; then
        print_warn "Partition $partition not found, skipping"
        continue
    fi

    print_info "Formatting partition $part_num ($partition) as $fstype"

    case $fstype in
        ext4)
            mkfs.ext4 -F "$partition" > /dev/null 2>&1
            ;;
        ext3)
            mkfs.ext3 -F "$partition" > /dev/null 2>&1
            ;;
        xfs)
            mkfs.xfs -f "$partition" > /dev/null 2>&1
            ;;
        btrfs)
            mkfs.btrfs -f "$partition" > /dev/null 2>&1
            ;;
        vfat|fat32)
            mkfs.vfat -F 32 "$partition" > /dev/null 2>&1
            ;;
        *)
            print_warn "Unknown filesystem type: $fstype, using ext4"
            mkfs.ext4 -F "$partition" > /dev/null 2>&1
            ;;
    esac

    print_success "Formatted $partition as $fstype"
done
echo ""

# Set UUIDs for all partitions (read from backup)
print_header "Setting UUIDs from Backup"

# First, check if we have UUID mapping file
if [ ! -f "$BACKUP_DIR/uuid_mapping.txt" ]; then
    print_warn "uuid_mapping.txt not found, UUIDs will be auto-generated"
else
    # Read UUID mappings
    declare -A PARTITION_UUIDS
    declare -A PARTITION_FSTYPES

    while IFS=':' read -r part_num uuid fstype size_mb partuuid; do
        # Skip empty lines and comments
        [[ -z "$part_num" || "$part_num" =~ ^# ]] && continue
        PARTITION_UUIDS[$part_num]=$uuid
        PARTITION_FSTYPES[$part_num]=$fstype
    done < "$BACKUP_DIR/uuid_mapping.txt"

    # Set UUIDs for all partitions
    for part_num in {1..11}; do
        partition=$(get_partition_name $part_num)
        uuid=${PARTITION_UUIDS[$part_num]}
        fstype=${PARTITION_FSTYPES[$part_num]}

        if [ ! -b "$partition" ]; then
            continue
        fi

        if [ -z "$uuid" ] || [ "$uuid" = "unknown" ]; then
            print_warn "No UUID for partition $part_num, will use auto-generated UUID"
            continue
        fi

        print_info "Setting UUID for partition $part_num ($partition): $uuid"

        case $fstype in
            ext4|ext3|ext2)
                tune2fs -U "$uuid" "$partition" > /dev/null 2>&1 || print_warn "Failed to set UUID for $partition"
                ;;
            xfs)
                xfs_admin -U "$uuid" "$partition" > /dev/null 2>&1 || print_warn "Failed to set UUID for $partition"
                ;;
            vfat|fat32)
                # Convert UUID format for FAT (remove dashes, use only first 8 chars)
                fat_uuid=$(echo "$uuid" | tr -d '-' | cut -c1-8 | tr '[:lower:]' '[:upper:]')
                mlabel -i "$partition" -N "${fat_uuid}" > /dev/null 2>&1 || print_warn "Failed to set UUID for $partition"
                ;;
            btrfs)
                btrfstune -U "$uuid" "$partition" > /dev/null 2>&1 || print_warn "Failed to set UUID for $partition"
                ;;
            *)
                print_warn "Cannot set UUID for filesystem type: $fstype"
                ;;
        esac
    done
fi

print_success "UUIDs configured"
echo ""

# Verify restoration
print_header "Verification"
print_info "Current partition layout:"
lsblk "$TARGET_DISK" -o NAME,SIZE,FSTYPE,UUID
echo ""

# Mount root partition and setup system
print_header "Setting Up Root Partition"
MOUNT_POINT="/mnt/restore_root"
mkdir -p "$MOUNT_POINT"

ROOT_PART=$(get_partition_name 2)
if mount "$ROOT_PART" "$MOUNT_POINT" 2>/dev/null; then
    print_success "Mounted root partition at $MOUNT_POINT"

    # Create mount point directories in root partition based on fstab
    print_info "Creating mount point directories..."

    # Standard mount points from your fstab
    MOUNT_DIRS=(
        "boot/efi"
        "home"
        "var"
        "var/log"
        "var/tmp"
        "var/log/audit"
        "embedd_d"
        "app"
        "tmp"
        "extra"
    )

    for dir in "${MOUNT_DIRS[@]}"; do
        mkdir -p "$MOUNT_POINT/$dir"
        print_info "Created: /$dir"
    done

    # Set proper permissions for sensitive directories
    chmod 1777 "$MOUNT_POINT/tmp" 2>/dev/null || true
    chmod 1777 "$MOUNT_POINT/var/tmp" 2>/dev/null || true
    chmod 755 "$MOUNT_POINT/var/log" 2>/dev/null || true
    chmod 700 "$MOUNT_POINT/var/log/audit" 2>/dev/null || true

    print_success "Mount point directories created"
    echo ""

    # Copy fstab if available
    if [ -f "$BACKUP_DIR/fstab.backup" ]; then
        mkdir -p "$MOUNT_POINT/etc"
        cp "$BACKUP_DIR/fstab.backup" "$MOUNT_POINT/etc/fstab"
        print_success "Installed fstab from backup"

        print_info "fstab contents:"
        cat "$MOUNT_POINT/etc/fstab"
    else
        print_warn "fstab.backup not found, skipping fstab installation"
    fi
    echo ""

    umount "$MOUNT_POINT"
    print_success "Unmounted root partition"
else
    print_warn "Could not mount root partition to setup directories"
fi

rmdir "$MOUNT_POINT" 2>/dev/null || true
echo ""

# Create lost+found directories in additional partitions
print_header "Initializing Additional Partitions"
for part_num in {5..11}; do
    partition=$(get_partition_name $part_num)

    if [ ! -b "$partition" ]; then
        continue
    fi

    # Create lost+found for ext filesystems (usually auto-created)
    TEMP_MOUNT="/mnt/temp_part_${part_num}"
    mkdir -p "$TEMP_MOUNT"

    if mount "$partition" "$TEMP_MOUNT" 2>/dev/null; then
        # lost+found is usually auto-created by mkfs, just verify
        if [ -d "$TEMP_MOUNT/lost+found" ]; then
            print_info "Partition $part_num: initialized successfully"
        fi
        umount "$TEMP_MOUNT"
    fi

    rmdir "$TEMP_MOUNT" 2>/dev/null || true
done

print_success "Additional partitions initialized"
echo ""

# Final summary
print_header "Restoration Complete"
print_success "All partitions have been restored successfully!"
echo ""
print_info "Restored partitions:"
lsblk "$TARGET_DISK" -o NAME,SIZE,FSTYPE,UUID,MOUNTPOINT
echo ""

print_warn "IMPORTANT: Next steps to complete the restoration:"
echo "  1. Boot from the restored disk or mount all partitions"
echo ""
echo "  2. Mount all partitions (if not booted from restored disk):"
echo "     mount $(get_partition_name 2) /mnt"
echo "     mount $(get_partition_name 1) /mnt/boot/efi"
echo "     mount $(get_partition_name 3) /mnt/var"
echo "     mount $(get_partition_name 4) /mnt/home"
echo "     # Mount partition 5+ based on your fstab"
echo ""
echo "  3. Verify all mount points work: df -h"
echo ""
echo "  4. Reinstall/update bootloader:"
echo "     - For GRUB: grub-install $TARGET_DISK && update-grub"
echo "     - For systemd-boot: bootctl install"
echo ""
echo "  5. Verify /etc/fstab is correct"
echo ""
echo "  6. Create swap file if needed:"
echo "     dd if=/dev/zero of=/swap.img bs=1M count=SIZE"
echo "     chmod 600 /swap.img"
echo "     mkswap /swap.img"
echo "     swapon /swap.img"
echo ""
echo "  7. Reboot and test all mount points"
echo ""
print_info "Summary of created mount points:"
echo "  - /boot/efi (partition 1)"
echo "  - / (partition 2)"
echo "  - /var (partition 3)"
echo "  - /home (partition 4)"
echo "  - /var/log (partition 5)"
echo "  - /var/tmp (partition 6)"
echo "  - /var/log/audit (partition 7)"
echo "  - /embedd_d (partition 8)"
echo "  - /app (partition 9)"
echo "  - /tmp (partition 10)"
echo "  - /extra (partition 11)"
echo ""
print_success "All mount point directories created and ready!"
echo ""
print_info "Restoration log saved to: /var/log/restoration_$(date +%Y%m%d_%H%M%S).log"
print_success "Restoration completed successfully!"
