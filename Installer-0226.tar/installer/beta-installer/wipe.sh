#!/bin/bash

# Secure Disk Wiper Script
# Completely wipes a disk with multiple methods

set -euo pipefail

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
NC='\033[0m'

print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

clear
print_header "Secure Disk Wiper"
echo ""
echo -e "${MAGENTA}This script will COMPLETELY ERASE a disk${NC}"
echo -e "${MAGENTA}All data will be PERMANENTLY DESTROYED${NC}"
echo ""

# Show available disks (excluding sda)
print_header "Available Disks"
print_warn "Note: sda is excluded (assumed to be installer/live USB)"
echo ""
lsblk -d -o NAME,SIZE,TYPE,MODEL,SERIAL | grep -v "sda" | head -1
lsblk -d -o NAME,SIZE,TYPE,MODEL,SERIAL | grep -v "^sda" | grep -v loop | tail -n +2
echo ""

# Select target disk
read -rp "Enter the disk to WIPE (e.g., sdb, sdc, nvme0n1): " disk_input

# Prevent sda
if [ "$disk_input" == "sda" ]; then
    print_error "Cannot select sda - this is your installer/live USB!"
    exit 1
fi

TARGET_DISK="/dev/$disk_input"

if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found"
    exit 1
fi

# Get disk information
DISK_SIZE=$(blockdev --getsize64 "$TARGET_DISK")
DISK_SIZE_GB=$((DISK_SIZE / 1024 / 1024 / 1024))
DISK_MODEL=$(lsblk -d -n -o MODEL "$TARGET_DISK" 2>/dev/null || echo "Unknown")
DISK_SERIAL=$(lsblk -d -n -o SERIAL "$TARGET_DISK" 2>/dev/null || echo "Unknown")

print_info "Selected disk: $TARGET_DISK"
print_info "Model: $DISK_MODEL"
print_info "Serial: $DISK_SERIAL"
print_info "Size: ${DISK_SIZE_GB}GB (${DISK_SIZE} bytes)"
echo ""

lsblk "$TARGET_DISK"
echo ""

# Show wipe methods
print_header "Wipe Methods Available"
echo ""
echo "1) Quick Wipe    - Wipe partition table and first/last 100MB (Fast)"
echo "2) Zero Fill     - Fill entire disk with zeros (Medium, ~1GB/min)"
echo "3) Random Fill   - Fill entire disk with random data (Slow, secure)"
echo "4) DoD 3-Pass    - DoD 5220.22-M standard (Very slow, very secure)"
echo "5) Gutmann 35    - Gutmann method, 35 passes (Extremely slow, overkill)"
echo "6) Custom        - Choose your own method"
echo ""

read -rp "Select wipe method (1-6): " method

# Confirm
print_header "FINAL WARNING"
echo -e "${RED}═══════════════════════════════════════${NC}"
echo -e "${RED}  YOU ARE ABOUT TO PERMANENTLY ERASE  ${NC}"
echo -e "${RED}  $TARGET_DISK${NC}"
echo -e "${RED}  Model: $DISK_MODEL${NC}"
echo -e "${RED}  Serial: $DISK_SERIAL${NC}"
echo -e "${RED}  Size: ${DISK_SIZE_GB}GB${NC}"
echo -e "${RED}═══════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}ALL DATA WILL BE PERMANENTLY LOST!${NC}"
echo -e "${YELLOW}THIS CANNOT BE UNDONE!${NC}"
echo ""

read -rp "Type the disk name '$disk_input' to confirm: " confirm_disk
if [ "$confirm_disk" != "$disk_input" ]; then
    print_error "Disk name does not match. Aborting."
    exit 1
fi

read -rp "Type 'DESTROY' in capital letters to proceed: " confirm_destroy
if [ "$confirm_destroy" != "DESTROY" ]; then
    print_error "Confirmation failed. Aborting."
    exit 1
fi

echo ""
print_warn "Starting wipe operation in 5 seconds... Press Ctrl+C to cancel!"
sleep 5

# Unmount any mounted partitions
print_info "Unmounting any mounted partitions..."
for part in ${TARGET_DISK}*; do
    if mountpoint -q "$part" 2>/dev/null; then
        print_info "Unmounting $part"
        umount "$part" || true
    fi
done

# Execute wipe based on method
case $method in
    1)
        print_header "Quick Wipe"

        print_info "Wiping partition table signatures..."
        wipefs -a "$TARGET_DISK" 2>/dev/null || true

        print_info "Zeroing first 100MB..."
        dd if=/dev/zero of="$TARGET_DISK" bs=1M count=100 status=progress 2>/dev/null || true

        print_info "Zeroing last 100MB..."
        SKIP_BLOCKS=$(( (DISK_SIZE / 1048576) - 100 ))
        if [ $SKIP_BLOCKS -gt 0 ]; then
            dd if=/dev/zero of="$TARGET_DISK" bs=1M seek=$SKIP_BLOCKS count=100 status=progress 2>/dev/null || true
        fi

        print_info "Wiping GPT backup table..."
        sgdisk -Z "$TARGET_DISK" 2>/dev/null || true

        sync
        ;;

    2)
        print_header "Zero Fill Wipe"

        print_info "Wiping partition table..."
        wipefs -a "$TARGET_DISK" 2>/dev/null || true

        print_info "Filling disk with zeros..."
        print_warn "This will take approximately $((DISK_SIZE_GB / 60)) minutes for ${DISK_SIZE_GB}GB"

        if command -v pv &> /dev/null; then
            dd if=/dev/zero | pv -s "$DISK_SIZE" -N "Zeroing disk" | dd of="$TARGET_DISK" bs=16M oflag=direct status=none
        else
            dd if=/dev/zero of="$TARGET_DISK" bs=16M status=progress oflag=direct
        fi

        sync
        ;;

    3)
        print_header "Random Fill Wipe"

        print_info "Wiping partition table..."
        wipefs -a "$TARGET_DISK" 2>/dev/null || true

        print_info "Filling disk with random data..."
        print_warn "This will take approximately $((DISK_SIZE_GB / 30)) minutes for ${DISK_SIZE_GB}GB"

        if command -v pv &> /dev/null; then
            dd if=/dev/urandom | pv -s "$DISK_SIZE" -N "Random fill" | dd of="$TARGET_DISK" bs=16M oflag=direct status=none
        else
            dd if=/dev/urandom of="$TARGET_DISK" bs=16M status=progress oflag=direct
        fi

        sync
        ;;

    4)
        print_header "DoD 5220.22-M 3-Pass Wipe"

        print_info "Wiping partition table..."
        wipefs -a "$TARGET_DISK" 2>/dev/null || true

        print_warn "This will take approximately $((DISK_SIZE_GB * 3 / 60)) minutes for ${DISK_SIZE_GB}GB"

        # Pass 1: Zeros
        print_info "Pass 1/3: Writing zeros..."
        if command -v pv &> /dev/null; then
            dd if=/dev/zero | pv -s "$DISK_SIZE" -N "Pass 1/3" | dd of="$TARGET_DISK" bs=16M oflag=direct status=none
        else
            dd if=/dev/zero of="$TARGET_DISK" bs=16M status=progress oflag=direct
        fi
        sync

        # Pass 2: Ones (0xFF)
        print_info "Pass 2/3: Writing ones (0xFF)..."
        if command -v pv &> /dev/null; then
            tr '\0' '\377' < /dev/zero | pv -s "$DISK_SIZE" -N "Pass 2/3" | dd of="$TARGET_DISK" bs=16M oflag=direct status=none
        else
            tr '\0' '\377' < /dev/zero | dd of="$TARGET_DISK" bs=16M status=progress oflag=direct
        fi
        sync

        # Pass 3: Random
        print_info "Pass 3/3: Writing random data..."
        if command -v pv &> /dev/null; then
            dd if=/dev/urandom | pv -s "$DISK_SIZE" -N "Pass 3/3" | dd of="$TARGET_DISK" bs=16M oflag=direct status=none
        else
            dd if=/dev/urandom of="$TARGET_DISK" bs=16M status=progress oflag=direct
        fi
        sync
        ;;

    5)
        print_header "Gutmann 35-Pass Wipe"

        print_warn "This is EXTREMELY slow and generally unnecessary!"
        print_warn "Estimated time: $((DISK_SIZE_GB * 35 / 60)) minutes for ${DISK_SIZE_GB}GB"

        read -rp "Are you sure you want to proceed? (yes/no): " confirm_gutmann
        if [ "$confirm_gutmann" != "yes" ]; then
            print_info "Aborting Gutmann wipe"
            exit 0
        fi

        # Check if shred is available
        if command -v shred &> /dev/null; then
            print_info "Using shred for Gutmann method..."
            shred -vfz -n 35 "$TARGET_DISK"
        else
            print_error "shred command not found. Install coreutils package."
            print_info "Falling back to 7-pass random wipe..."

            for pass in {1..7}; do
                print_info "Pass $pass/7: Writing random data..."
                if command -v pv &> /dev/null; then
                    dd if=/dev/urandom | pv -s "$DISK_SIZE" -N "Pass $pass/7" | dd of="$TARGET_DISK" bs=16M oflag=direct status=none
                else
                    dd if=/dev/urandom of="$TARGET_DISK" bs=16M status=progress oflag=direct
                fi
                sync
            done
        fi
        ;;

    6)
        print_header "Custom Wipe"
        echo ""
        echo "Available custom options:"
        echo "  1) Single zero pass"
        echo "  2) Single random pass"
        echo "  3) Multiple random passes (specify count)"
        echo "  4) Pattern fill (specify byte value)"
        echo ""

        read -rp "Select custom option (1-4): " custom_option

        case $custom_option in
            1)
                print_info "Single zero pass..."
                dd if=/dev/zero of="$TARGET_DISK" bs=16M status=progress oflag=direct
                ;;
            2)
                print_info "Single random pass..."
                dd if=/dev/urandom of="$TARGET_DISK" bs=16M status=progress oflag=direct
                ;;
            3)
                read -rp "Enter number of random passes: " passes
                for ((i=1; i<=passes; i++)); do
                    print_info "Random pass $i/$passes..."
                    dd if=/dev/urandom of="$TARGET_DISK" bs=16M status=progress oflag=direct
                    sync
                done
                ;;
            4)
                read -rp "Enter byte value (0-255, or hex like 0xFF): " byte_val
                print_info "Filling with pattern $byte_val..."
                tr '\0' "\\$(printf '%03o' "$byte_val")" < /dev/zero | dd of="$TARGET_DISK" bs=16M status=progress oflag=direct
                ;;
            *)
                print_error "Invalid option"
                exit 1
                ;;
        esac
        ;;

    *)
        print_error "Invalid wipe method selected"
        exit 1
        ;;
esac

# Final cleanup
print_header "Final Cleanup"

print_info "Wiping any remaining signatures..."
wipefs -a "$TARGET_DISK" 2>/dev/null || true

print_info "Zeroing partition table area..."
dd if=/dev/zero of="$TARGET_DISK" bs=1M count=10 status=none 2>/dev/null || true

print_info "Flushing disk cache..."
sync
blockdev --flushbufs "$TARGET_DISK" 2>/dev/null || true

# Verification
print_header "Verification"

print_info "Checking first 512 bytes..."
FIRST_BYTES=$(dd if="$TARGET_DISK" bs=512 count=1 2>/dev/null | od -An -tx1 | tr -d ' \n')
if [ "$FIRST_BYTES" == "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000" ]; then
    print_success "Disk appears to be wiped (zeros detected)"
else
    print_warn "Disk may contain non-zero data (this is normal for random wipes)"
fi

print_info "Checking for partition table..."
if parted -s "$TARGET_DISK" print 2>&1 | grep -q "unrecognised disk label"; then
    print_success "No partition table found - disk is clean"
else
    print_warn "Partition table may still exist"
fi

# Final summary
print_header "Wipe Complete"
print_success "Disk $TARGET_DISK has been securely wiped!"
echo ""

print_info "Disk information:"
echo "  Device: $TARGET_DISK"
echo "  Model: $DISK_MODEL"
echo "  Serial: $DISK_SERIAL"
echo "  Size: ${DISK_SIZE_GB}GB"
echo ""

print_info "The disk is now clean and ready for:"
echo "  - Partitioning"
echo "  - OS installation"
echo "  - Data storage"
echo "  - Disposal or resale (if secure wipe was used)"
echo ""

print_success "Operation completed successfully!"
