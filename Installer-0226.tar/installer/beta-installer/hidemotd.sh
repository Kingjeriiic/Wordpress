echo "=== Removing TTY1/MOTD Messages ==="

# Disable MOTD scripts
chmod -x /etc/update-motd.d/* 2>/dev/null || true

# Disable landscape-client
systemctl disable --now landscape-client 2>/dev/null || true

# Disable Ubuntu Pro / apt news
pro config set apt_news=false 2>/dev/null || true

# Clear login banners
> /etc/issue
> /etc/issue.net

# Comment out PAM motd modules
sed -i 's/^\(session.*pam_motd\.so\)/# \1/' /etc/pam.d/sshd 2>/dev/null || true
sed -i 's/^\(session.*pam_motd\.so\)/# \1/' /etc/pam.d/login 2>/dev/null || true

# Clear MOTD cache
rm -f /run/motd.dynamic /run/motd.dynamic.new
