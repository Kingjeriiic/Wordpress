#!/bin/bash
# Install App SQL Script for ETAP Installer
# Processes and copies app.sql to target SSD partition 9 (/app/db/)
# Usage: ./install-app-sql.sh <target_disk> <terminal_id> <terminal_name> <customer_id>

set -euo pipefail

# Create log file
LOG_FILE="/tmp/install_app_sql_$(date +%Y%m%d_%H%M%S).log"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check if target disk and variables are provided
if [ $# -ne 4 ]; then
    echo "Usage: $0 <target_disk> <terminal_id> <terminal_name> <customer_id>"
    echo "Example: $0 /dev/sdb KIOSK001 'Main Terminal' CUST123"
    echo "Example: $0 /dev/nvme0n1 TERMINAL-A1 'Branch Office' ETAP456"
    echo ""
    echo "This will process app.sql with variables and copy to /app/db/ on partition 9"
    exit 1
fi

TARGET_DISK="$1"
TERMINAL_ID="$2"
TERMINAL_NAME="$3"
CUSTOMER_ID="$4"

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Validate target disk
if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

# Safety check: Exclude sda disk
if [[ "$TARGET_DISK" == "/dev/sda"* ]]; then
    print_error "SAFETY ERROR: sda disk is excluded for safety!"
    print_error "sda is typically the installer/system disk."
    print_error "Supported disks: sdb, sdc, nvme*"
    exit 1
fi

# Get app partition (partition 9)
APP_PARTITION=$(get_partition_name 9)

if [ ! -b "$APP_PARTITION" ]; then
    print_error "App partition $APP_PARTITION not found."
    print_error "Make sure the disk has been properly partitioned and app image restored."
    exit 1
fi

# Banner
print_header "ETAP App SQL Installation"
echo ""
echo "Target disk: $TARGET_DISK"
echo "App partition: $APP_PARTITION"
echo "Terminal ID: $TERMINAL_ID"
echo "Terminal Name: $TERMINAL_NAME"
echo "Customer ID: $CUSTOMER_ID"
echo ""

# Check for SQL file in multiple possible locations
SQL_SOURCE=""
POSSIBLE_LOCATIONS=(
    "/extra/os/db/app.sql"
    "./app.sql"
    "/app-images/app.sql"
    "/extra/os/app-images/app.sql"
    "/tmp/app.sql"
    "$(pwd)/app.sql"
)

print_info "Searching for app.sql file..."
for location in "${POSSIBLE_LOCATIONS[@]}"; do
    if [[ -f "$location" ]]; then
        SQL_SOURCE="$location"
        print_success "Found app.sql at: $location"
        break
    else
        print_info "Checked: $location (not found)"
    fi
done

if [[ -z "$SQL_SOURCE" ]]; then
    print_error "app.sql file not found in any of these locations:"
    for location in "${POSSIBLE_LOCATIONS[@]}"; do
        echo "  - $location"
    done
    echo ""
    print_error "Please ensure app.sql is available in one of the above locations"
    exit 1
fi

# Get SQL file information
SQL_SIZE=$(du -h "$SQL_SOURCE" | cut -f1)
print_info "Original SQL file size: $SQL_SIZE"

# Process SQL file with variable substitution
print_header "Processing SQL File with Variables"
TEMP_SQL="/tmp/app_$(date +%Y%m%d_%H%M%S).sql"

print_info "Creating customized SQL file..."
print_info "Processing variables:"
echo "  - {TERMINAL_ID} → $TERMINAL_ID"
echo "  - {TERMINAL_NAME} → $TERMINAL_NAME"
echo "  - {CUSTOMER_ID} → $CUSTOMER_ID"

# Remove comments and process variables
print_info "Removing comments and processing variables..."
if grep -v '#' "$SQL_SOURCE" > "$TEMP_SQL"; then
    print_success "Comments removed"
else
    print_error "Failed to process SQL file"
    exit 1
fi

# Replace variables using sed
print_info "Substituting TERMINAL_ID..."
if sed -e "s/{TERMINAL_ID}/$TERMINAL_ID/g" -i "$TEMP_SQL"; then
    print_success "TERMINAL_ID substituted"
else
    print_error "Failed to substitute TERMINAL_ID"
    exit 1
fi

print_info "Substituting TERMINAL_NAME..."
if sed -e "s/{TERMINAL_NAME}/$TERMINAL_NAME/g" -i "$TEMP_SQL"; then
    print_success "TERMINAL_NAME substituted"
else
    print_error "Failed to substitute TERMINAL_NAME"
    exit 1
fi

print_info "Substituting CUSTOMER_ID..."
if sed -e "s/{CUSTOMER_ID}/$CUSTOMER_ID/g" -i "$TEMP_SQL"; then
    print_success "CUSTOMER_ID substituted"
else
    print_error "Failed to substitute CUSTOMER_ID"
    exit 1
fi

# Verify processed file
if [[ -f "$TEMP_SQL" ]]; then
    PROCESSED_SIZE=$(du -h "$TEMP_SQL" | cut -f1)
    print_success "Processed SQL file created: $TEMP_SQL"
    print_info "Processed SQL file size: $PROCESSED_SIZE"
    
    # Show a preview of the processed file
    print_info "Preview of processed SQL (first 5 lines):"
    echo "----------------------------------------"
    head -5 "$TEMP_SQL" 2>/dev/null || echo "Could not preview file"
    echo "----------------------------------------"
else
    print_error "Failed to create processed SQL file"
    exit 1
fi

# Update SQL_SOURCE to point to processed file
SQL_SOURCE="$TEMP_SQL"
SQL_SIZE="$PROCESSED_SIZE"

# Mount app partition
MOUNT_POINT="/mnt/app_sql_install"
mkdir -p "$MOUNT_POINT"

print_info "Mounting app partition..."
if mount "$APP_PARTITION" "$MOUNT_POINT" 2>/dev/null; then
    print_success "Mounted app partition at $MOUNT_POINT"
else
    print_error "Failed to mount app partition $APP_PARTITION"
    print_error "Make sure the app partition is properly formatted and the app image was restored successfully."
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

# Create /app/db directory if it doesn't exist
DB_DIR="$MOUNT_POINT/db"
print_info "Creating /app/db directory..."
mkdir -p "$DB_DIR"

if [[ -d "$DB_DIR" ]]; then
    print_success "Directory /app/db is ready"
else
    print_error "Failed to create /app/db directory"
    umount "$MOUNT_POINT" 2>/dev/null || true
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

# Check if app.sql already exists in target
TARGET_SQL="$DB_DIR/app.sql"
if [[ -f "$TARGET_SQL" ]]; then
    print_warn "app.sql already exists in /app/db/"
    
    # Compare file sizes
    EXISTING_SIZE=$(du -h "$TARGET_SQL" | cut -f1)
    print_info "Existing file size: $EXISTING_SIZE"
    print_info "New file size: $SQL_SIZE"
    
    # Backup existing file
    BACKUP_FILE="$DB_DIR/app.sql.backup.$(date +%Y%m%d_%H%M%S)"
    print_info "Creating backup: $(basename "$BACKUP_FILE")"
    cp "$TARGET_SQL" "$BACKUP_FILE" 2>/dev/null || true
fi

# Copy SQL file
print_header "Installing App SQL File"
print_info "[$(date)] Copying app.sql to /app/db/..."

# Record start time
START_TIME=$(date '+%Y-%m-%d %H:%M:%S')
START_SECONDS=$(date +%s)
print_info "Start time: $START_TIME"

# Copy the SQL file
if cp "$SQL_SOURCE" "$TARGET_SQL" 2>/dev/null; then
    # Record finish time
    FINISH_TIME=$(date '+%Y-%m-%d %H:%M:%S')
    FINISH_SECONDS=$(date +%s)
    DURATION=$((FINISH_SECONDS - START_SECONDS))
    
    print_info "Finish time: $FINISH_TIME"
    print_info "Duration: ${DURATION} seconds"
    print_success "app.sql copied successfully"
else
    print_error "Failed to copy app.sql"
    umount "$MOUNT_POINT" 2>/dev/null || true
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

# Set proper permissions
print_info "Setting file permissions..."
chmod 644 "$TARGET_SQL" 2>/dev/null || true
chown root:root "$TARGET_SQL" 2>/dev/null || true

# Verify the copy
if [[ -f "$TARGET_SQL" ]]; then
    INSTALLED_SIZE=$(du -h "$TARGET_SQL" | cut -f1)
    print_success "Verification: app.sql installed successfully"
    print_info "Installed file size: $INSTALLED_SIZE"
    
    # Show directory contents
    print_info "Contents of /app/db/:"
    echo "----------------------------------------"
    ls -la "$DB_DIR" 2>/dev/null || echo "Could not list directory contents"
    echo "----------------------------------------"
else
    print_error "Verification failed: app.sql not found after copy"
fi

# Sync to ensure data is written
sync

# Unmount app partition
print_info "Unmounting app partition..."
if umount "$MOUNT_POINT" 2>/dev/null; then
    print_success "Unmounted app partition"
else
    print_warn "Could not unmount cleanly, but SQL file was installed"
fi

rmdir "$MOUNT_POINT" 2>/dev/null || true

# Summary
print_header "App SQL Installation Complete"
print_success "Customized app.sql has been installed successfully!"
echo ""
print_info "Installation Summary:"
echo "  ✅ Target: $APP_PARTITION:/app/db/app.sql"
echo "  ✅ Size: $SQL_SIZE"
echo "  ✅ Variables processed:"
echo "     - TERMINAL_ID: $TERMINAL_ID"
echo "     - TERMINAL_NAME: $TERMINAL_NAME"
echo "     - CUSTOMER_ID: $CUSTOMER_ID"
echo "  ✅ Permissions: 644 (rw-r--r--)"
echo "  ✅ Owner: root:root"
if [[ -n "${BACKUP_FILE:-}" ]]; then
    echo "  ✅ Backup: $(basename "$BACKUP_FILE")"
fi
echo ""

# Execute SQL using temporary Docker container
print_header "Executing SQL on MySQL Database"

# MySQL configuration
MYSQL_USER="root"
MYSQL_PASS="#!cmai2013root"
MYSQL_DB="etap_kiosk"

# Copy processed SQL to /tmp for Docker access (use TEMP_SQL which still exists)
print_info "Copying SQL file to /tmp/app.sql..."
if cp "$TEMP_SQL" "/tmp/app.sql" 2>/dev/null; then
    print_success "SQL file copied to /tmp/app.sql"
else
    print_error "Failed to copy SQL to /tmp"
    # Clean up temp file before exit
    rm -f "$TEMP_SQL" 2>/dev/null || true
    exit 1
fi

# Check if Docker is available
if ! command -v docker &> /dev/null; then
    print_error "Docker is not installed or not available"
    print_info "Please install Docker first"
    exit 1
fi

print_info "Docker is available, starting temporary MySQL container..."

# Mount the app partition to access MySQL data
MOUNT_POINT_MYSQL="/mnt/appcustom"
mkdir -p "$MOUNT_POINT_MYSQL"

if ! mount "$APP_PARTITION" "$MOUNT_POINT_MYSQL" 2>/dev/null; then
    print_error "Failed to mount app partition for MySQL access"
    rmdir "$MOUNT_POINT_MYSQL" 2>/dev/null || true
    exit 1
fi

print_success "Mounted app partition at $MOUNT_POINT_MYSQL"

# Check if MySQL data directory exists
if [[ ! -d "$MOUNT_POINT_MYSQL/db/mysql" ]]; then
    print_error "MySQL data directory not found at $MOUNT_POINT_MYSQL/db/mysql"
    umount "$MOUNT_POINT_MYSQL" 2>/dev/null || true
    rmdir "$MOUNT_POINT_MYSQL" 2>/dev/null || true
    exit 1
fi

print_info "Found MySQL data directory"

# Start temporary MySQL container with network disabled
print_info "Starting temporary MySQL container (network disabled)..."
if docker run --name mysql-temp --net none -d --rm \
    -v "$MOUNT_POINT_MYSQL/db/mysql:/var/lib/mysql" \
    mysql:8.0 >> "$LOG_FILE" 2>&1; then
    print_success "MySQL container started"
else
    print_error "Failed to start MySQL container"
    print_info "Check log: $LOG_FILE"
    umount "$MOUNT_POINT_MYSQL" 2>/dev/null || true
    rmdir "$MOUNT_POINT_MYSQL" 2>/dev/null || true
    exit 1
fi

# Wait for MySQL to be ready
print_info "Waiting for MySQL to be ready..."
WAIT_COUNT=0
MAX_WAIT=60
while [ $WAIT_COUNT -lt $MAX_WAIT ]; do
    if docker exec mysql-temp mysqladmin ping -u"$MYSQL_USER" -p"$MYSQL_PASS" &>/dev/null; then
        print_success "MySQL is ready"
        break
    fi
    sleep 2
    ((WAIT_COUNT+=2))
done

if [ $WAIT_COUNT -ge $MAX_WAIT ]; then
    print_error "MySQL failed to start within timeout"
    docker stop mysql-temp &>/dev/null || true
    umount "$MOUNT_POINT_MYSQL" 2>/dev/null || true
    rmdir "$MOUNT_POINT_MYSQL" 2>/dev/null || true
    exit 1
fi

# Copy SQL file into container
print_info "Copying SQL file into container..."
if docker cp /tmp/app.sql mysql-temp:/tmp/app.sql >> "$LOG_FILE" 2>&1; then
    print_success "SQL file copied into container"
else
    print_error "Failed to copy SQL file into container"
    docker stop mysql-temp &>/dev/null || true
    umount "$MOUNT_POINT_MYSQL" 2>/dev/null || true
    rmdir "$MOUNT_POINT_MYSQL" 2>/dev/null || true
    exit 1
fi

# Execute SQL file
print_info "Executing SQL file on database '$MYSQL_DB'..."
if docker exec -i mysql-temp mysql -u"$MYSQL_USER" -p"$MYSQL_PASS" "$MYSQL_DB" < /tmp/app.sql 2>/dev/null; then
    print_success "SQL file executed successfully on MySQL database!"
    echo "  ✅ Database: $MYSQL_DB"
    echo "  ✅ Container: mysql-temp"
    echo "  ✅ SQL file: /tmp/app.sql"
else
    print_warn "SQL execution completed with warnings (this may be normal)"
    print_info "Check container logs if needed"
fi

# Stop and remove container
print_info "Stopping MySQL container..."
if docker stop mysql-temp >> "$LOG_FILE" 2>&1; then
    print_success "MySQL container stopped"
else
    print_warn "Container may have already stopped"
fi

# Cleanup
print_info "Cleaning up..."
umount "$MOUNT_POINT_MYSQL" 2>/dev/null || true
rmdir "$MOUNT_POINT_MYSQL" 2>/dev/null || true
rm -f /tmp/app.sql 2>/dev/null || true
rm -f "$TEMP_SQL" 2>/dev/null || true
print_success "Cleanup completed"

echo ""
print_success "App SQL installation and execution completed successfully!"

# Output specific message for installer detection
echo "App SQL installation completed successfully"
