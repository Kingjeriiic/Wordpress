#!/bin/bash
# Setup Docker Systemd Service for ETAP Installer
# Creates systemd service for Docker Compose auto-start on boot
# Usage: ./setup-docker-systemd.sh <target_disk>

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check if target disk is provided
if [ $# -ne 1 ]; then
    echo "Usage: $0 <target_disk>"
    echo "Example: $0 /dev/sdb"
    exit 1
fi

TARGET_DISK="$1"

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Validate target disk
if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

# Get root partition (partition 2)
ROOT_PARTITION=$(get_partition_name 2)

if [ ! -b "$ROOT_PARTITION" ]; then
    print_error "Root partition $ROOT_PARTITION not found."
    exit 1
fi

print_info "Setting up Docker systemd service on $TARGET_DISK..."

# Mount root partition
ROOT_MOUNT="/mnt/root_docker_systemd"
mkdir -p "$ROOT_MOUNT"

if ! mount "$ROOT_PARTITION" "$ROOT_MOUNT" 2>/dev/null; then
    print_error "Failed to mount root partition"
    rmdir "$ROOT_MOUNT" 2>/dev/null || true
    exit 1
fi

print_success "Mounted root partition"

# Create systemd service directory
mkdir -p "$ROOT_MOUNT/etc/systemd/system"

# Create systemd service file
print_info "Creating etap-docker.service..."
cat > "$ROOT_MOUNT/etc/systemd/system/etap-docker.service" << 'EOF'
[Unit]
Description=ETAP Docker Compose Application
Requires=docker.service
After=docker.service
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/app/docker
ExecStart=/usr/bin/docker-compose up -d
ExecStop=/usr/bin/docker-compose down
TimeoutStartSec=300
User=root

[Install]
WantedBy=multi-user.target
EOF

print_success "Created etap-docker.service"

# Enable the service
print_info "Enabling service for auto-start..."
mkdir -p "$ROOT_MOUNT/etc/systemd/system/multi-user.target.wants"
ln -sf /etc/systemd/system/etap-docker.service "$ROOT_MOUNT/etc/systemd/system/multi-user.target.wants/etap-docker.service" 2>/dev/null || true

print_success "Enabled etap-docker.service for auto-start"

# Unmount
umount "$ROOT_MOUNT" 2>/dev/null || true
rmdir "$ROOT_MOUNT" 2>/dev/null || true

print_success "Docker systemd service setup completed!"
echo ""
echo "On boot, the system will automatically:"
echo "  1. Start Docker service"
echo "  2. Run docker-compose up -d in /app/docker/"
echo "  3. Launch the ETAP application"
echo ""

# Output specific message for installer detection
echo "Docker systemd service setup completed successfully"

