#!/bin/bash
# Create App Image Script for ETAP Installer (Non-Interactive)
# Creates raw .img file from /app partition (partition 9)
# Usage: ./create-app-image.sh <source_disk> <app_name>
# Note: This script runs automatically without user prompts

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check parameters
if [ $# -ne 2 ]; then
    echo "Usage: $0 <source_disk> <app_name>"
    echo "Example: $0 /dev/sdb etap-inc"
    echo "Example: $0 /dev/sdc ecpay"
    echo ""
    echo "This will create: /app-images/<app_name>.img"
    echo "Raw partition image from /app partition (partition 9)"
    exit 1
fi

SOURCE_DISK="$1"
APP_NAME="$2"
OUTPUT_DIR="/extra/os/app-images"

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$SOURCE_DISK" == *"nvme"* ]] || [[ "$SOURCE_DISK" == *"mmcblk"* ]]; then
        echo "${SOURCE_DISK}p${part_num}"
    else
        echo "${SOURCE_DISK}${part_num}"
    fi
}

# Validate source disk
if [ ! -b "$SOURCE_DISK" ]; then
    print_error "Source disk $SOURCE_DISK not found."
    exit 1
fi

# Safety check: Exclude sda disk
if [[ "$SOURCE_DISK" == "/dev/sda"* ]]; then
    print_error "SAFETY ERROR: sda disk is excluded for safety!"
    print_error "sda is typically the installer/system disk."
    print_error "Supported disks: sdb, sdc, nvme*"
    exit 1
fi

# Get app partition (partition 9)
APP_PARTITION=$(get_partition_name 9)

if [ ! -b "$APP_PARTITION" ]; then
    print_error "App partition $APP_PARTITION not found."
    print_error "Make sure the source disk has the proper partition layout."
    exit 1
fi

# Validate app name
if [[ ! "$APP_NAME" =~ ^[a-zA-Z0-9_-]+$ ]]; then
    print_error "Invalid app name. Use only letters, numbers, hyphens, and underscores."
    exit 1
fi

# Create output directory
mkdir -p "$OUTPUT_DIR"

# Output file path
OUTPUT_FILE="$OUTPUT_DIR/${APP_NAME}.img"

# Banner
print_header "ETAP App Image Creator (Raw Partition)"
echo ""
echo "Source disk: $SOURCE_DISK"
echo "App partition: $APP_PARTITION"
echo "App name: $APP_NAME"
echo "Output file: $OUTPUT_FILE"
echo "Method: Raw partition copy (dd)"
echo ""

# Check if output file already exists
if [ -f "$OUTPUT_FILE" ]; then
    print_warn "Output file already exists: $OUTPUT_FILE"
    print_info "Automatically overwriting existing file..."
    rm -f "$OUTPUT_FILE"
fi

# Get partition information
print_info "Analyzing app partition..."
PARTITION_SIZE_BYTES=$(blockdev --getsize64 "$APP_PARTITION")
PARTITION_SIZE_MB=$((PARTITION_SIZE_BYTES / 1024 / 1024))
PARTITION_SIZE_GB=$((PARTITION_SIZE_MB / 1024))

print_info "Partition size: ${PARTITION_SIZE_MB}MB (${PARTITION_SIZE_GB}GB)"

# Check filesystem and usage
FSTYPE=$(blkid -o value -s TYPE "$APP_PARTITION" 2>/dev/null || echo "unknown")
print_info "Filesystem type: $FSTYPE"

# Try to get used space if filesystem is mounted or can be mounted
USED_SPACE="unknown"
TEMP_MOUNT="/mnt/app_check_$$"
mkdir -p "$TEMP_MOUNT"

if mount -o ro "$APP_PARTITION" "$TEMP_MOUNT" 2>/dev/null; then
    USED_SPACE=$(df -h "$TEMP_MOUNT" | tail -1 | awk '{print $3}')
    FILE_COUNT=$(find "$TEMP_MOUNT" -type f 2>/dev/null | wc -l)
    print_info "Used space: $USED_SPACE"
    print_info "File count: $FILE_COUNT"
    
    # Show some content
    print_info "App partition content (top level):"
    echo "----------------------------------------"
    ls -la "$TEMP_MOUNT" 2>/dev/null | head -5 || echo "No files found"
    echo "----------------------------------------"
    
    umount "$TEMP_MOUNT" 2>/dev/null || true
else
    print_warn "Could not mount partition to check usage"
fi

rmdir "$TEMP_MOUNT" 2>/dev/null || true

# Auto-proceed with creation (non-interactive)
print_info "Creating raw partition image of the entire /app partition"
print_info "Image size will be: ${PARTITION_SIZE_MB}MB (${PARTITION_SIZE_GB}GB)"
print_info "Starting image creation automatically..."

# Create raw partition image
print_header "Creating Raw Partition Image"

# Record start time
START_TIME=$(date '+%Y-%m-%d %H:%M:%S')
START_SECONDS=$(date +%s)
print_info "Start time: $START_TIME"

print_info "Creating raw image from $APP_PARTITION..."
print_info "This will copy the entire partition including filesystem and data"

# Use dd with progress if pv is available
if command -v pv &> /dev/null; then
    print_info "Creating image with progress indicator..."
    dd if="$APP_PARTITION" bs=16M iflag=fullblock | pv -N "Copying partition" -s "$PARTITION_SIZE_BYTES" > "$OUTPUT_FILE"
else
    print_info "Creating image (this may take a while)..."
    dd if="$APP_PARTITION" of="$OUTPUT_FILE" bs=16M conv=sync,noerror iflag=fullblock status=progress
fi

# Sync to ensure all data is written
sync

# Record finish time
FINISH_TIME=$(date '+%Y-%m-%d %H:%M:%S')
FINISH_SECONDS=$(date +%s)
DURATION=$((FINISH_SECONDS - START_SECONDS))
DURATION_FORMATTED=$(printf '%02d:%02d:%02d' $((DURATION/3600)) $((DURATION%3600/60)) $((DURATION%60)))

print_info "Finish time: $FINISH_TIME"
print_info "Duration: $DURATION_FORMATTED (${DURATION} seconds)"

# Check if image was created successfully
if [ -f "$OUTPUT_FILE" ]; then
    print_success "Raw app image created successfully"
else
    print_error "Failed to create app image"
    exit 1
fi

# Verify image file
IMAGE_SIZE_BYTES=$(stat -c%s "$OUTPUT_FILE")
IMAGE_SIZE_MB=$((IMAGE_SIZE_BYTES / 1024 / 1024))
IMAGE_SIZE_GB=$((IMAGE_SIZE_MB / 1024))

print_header "App Image Creation Complete"
print_success "Raw app image '$APP_NAME.img' created successfully!"
echo ""
print_info "Image Details:"
echo "  ✅ File: $OUTPUT_FILE"
echo "  ✅ Size: ${IMAGE_SIZE_MB}MB (${IMAGE_SIZE_GB}GB)"
echo "  ✅ Source: $APP_PARTITION"
echo "  ✅ Type: Raw partition image"
echo "  ✅ Creation time: $DURATION_FORMATTED"
echo ""

# Verify image integrity by checking if it has the same size as source
if [ "$IMAGE_SIZE_BYTES" -eq "$PARTITION_SIZE_BYTES" ]; then
    print_success "Image size matches source partition - integrity verified"
else
    print_warn "Image size differs from source partition"
    print_warn "Source: ${PARTITION_SIZE_BYTES} bytes"
    print_warn "Image:  ${IMAGE_SIZE_BYTES} bytes"
fi

echo ""
print_info "Usage in installer:"
echo "  1. The raw image is ready at: $OUTPUT_FILE"
echo "  2. It will appear in the installer's app selection menu"
echo "  3. When selected, it will be written directly to the /app partition"
echo "  4. This preserves the exact filesystem structure and data"
echo ""
print_success "Raw app image creation completed successfully!"

# Show final file listing
print_info "Available app images:"
ls -lh "$OUTPUT_DIR"/*.img 2>/dev/null || echo "No other app images found"
