#!/bin/bash

# Backup Script for 4 Main Partitions (EFI, Root, Home, Var)
# Saves raw images to /extra/os with UUID and size information
# Also records UUID and size of ALL partitions for later recreation
# Backs up /etc/fstab for restoration

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
BACKUP_DIR="/extra/os/base-images"
DATE=$(date +"%Y%m%d_%H%M%S")

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Banner
clear
print_header "4-Partition Backup System (Raw Images)"
echo ""
echo "This will backup EFI, Root, Home, and Var partitions as raw images"
echo "All partition UUIDs and sizes will be recorded for restoration"
echo "Backup location: $BACKUP_DIR"
echo "Format: Raw .img files (no compression)"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Show available disks
print_header "Available Disks and Partitions"
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT,LABEL
echo ""

# Ask user which disk to backup
read -rp "Enter the disk to backup (e.g., sda, sdb, nvme0n1): " disk_input
TARGET_DISK="/dev/$disk_input"

if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

print_info "Selected disk: $TARGET_DISK"
echo ""

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Define the 4 main partitions to backup as images
P1=$(get_partition_name 1)  # EFI
P2=$(get_partition_name 2)  # Root
P3=$(get_partition_name 3)  # Home
P4=$(get_partition_name 4)  # Var

# Display partition information
print_header "Partitions Overview"
echo ""
print_info "Partitions that will be BACKED UP as raw images:"
printf "  %-8s %-15s %-10s %-10s %-38s\n" "Label" "Partition" "Size" "FS Type" "UUID"
printf "  %-8s %-15s %-10s %-10s %-38s\n" "-----" "---------" "----" "-------" "------------------------------------"

for part_num in 1 2 3 4; do
    part=$(get_partition_name $part_num)
    if [ -b "$part" ]; then
        uuid=$(blkid -s UUID -o value "$part" 2>/dev/null || echo "N/A")
        fstype=$(blkid -s TYPE -o value "$part" 2>/dev/null || echo "N/A")
        size=$(blockdev --getsize64 "$part" 2>/dev/null || echo "0")
        size_gb=$(echo "scale=2; $size/1024/1024/1024" | bc 2>/dev/null || echo "?")
        
        case $part_num in
            1) label="EFI" ;;
            2) label="ROOT" ;;
            3) label="HOME" ;;
            4) label="VAR" ;;
        esac
        
        printf "  %-8s %-15s %-10s %-10s %-38s\n" "$label" "$part" "${size_gb}GB" "$fstype" "$uuid"
    else
        print_warn "Partition $part not found"
    fi
done
echo ""

# Detect and display additional partitions (5+)
print_info "Additional partitions (UUID and size will be recorded):"
printf "  %-15s %-10s %-15s %-38s %-20s\n" "Partition" "Size" "FS Type" "UUID" "Mount Point"
printf "  %-15s %-10s %-15s %-38s %-20s\n" "---------" "----" "-------" "------------------------------------" "-----------"

additional_parts_found=0
for part_num in {5..20}; do
    part=$(get_partition_name $part_num)
    if [ -b "$part" ]; then
        additional_parts_found=1
        uuid=$(blkid -s UUID -o value "$part" 2>/dev/null || echo "N/A")
        fstype=$(blkid -s TYPE -o value "$part" 2>/dev/null || echo "N/A")
        size=$(blockdev --getsize64 "$part" 2>/dev/null || echo "0")
        size_gb=$(echo "scale=2; $size/1024/1024/1024" | bc 2>/dev/null || echo "?")
        mountpoint=$(findmnt -n -o TARGET "$part" 2>/dev/null || echo "not mounted")
        
        printf "  %-15s %-10s %-15s %-38s %-20s\n" "$part" "${size_gb}GB" "$fstype" "$uuid" "$mountpoint"
    fi
done

if [ $additional_parts_found -eq 0 ]; then
    echo "  No additional partitions found"
fi
echo ""

# Confirm backup
print_warn "Raw images will be created for: EFI, Root, Home, Var"
print_warn "UUID and size will be recorded for ALL partitions"
echo "Backup will be saved to: $BACKUP_DIR"
echo ""

# Check available space
print_info "Checking available disk space..."
available_space=$(df -BM "$BACKUP_DIR" | tail -n1 | awk '{print $4}' | sed 's/M//')
print_info "Available space in backup directory: ${available_space}MB"
echo ""

# Estimate space needed for backups
total_needed=0
for part_num in 1 2 3 4; do
    part=$(get_partition_name $part_num)
    if [ -b "$part" ]; then
        size=$(blockdev --getsize64 "$part" 2>/dev/null || echo "0")
        size_mb=$((size / 1024 / 1024))
        total_needed=$((total_needed + size_mb))
    fi
done

total_needed_gb=$(echo "scale=2; $total_needed/1024" | bc)
print_info "Estimated space needed: ${total_needed}MB (~${total_needed_gb}GB)"

if [ $total_needed -gt $available_space ]; then
    print_error "Not enough disk space!"
    print_error "Available: ${available_space}MB, Need: ${total_needed}MB"
    exit 1
fi

echo ""
read -rp "Continue with backup? (yes/no): " confirm

if [ "$confirm" != "yes" ]; then
    print_info "Backup cancelled"
    exit 0
fi

# UUID file
UUID_FILE="$BACKUP_DIR/uuids.txt"
> "$UUID_FILE"

# Partition sizes file
SIZES_FILE="$BACKUP_DIR/partition_sizes.txt"
> "$SIZES_FILE"

# All partitions info file (detailed)
ALL_PARTS_FILE="$BACKUP_DIR/all_partitions_info.txt"
> "$ALL_PARTS_FILE"

# UUID mapping file (machine-readable format for restoration)
UUID_MAP_FILE="$BACKUP_DIR/uuid_mapping.txt"
> "$UUID_MAP_FILE"

# Detect if we need to mount the root partition to get its fstab
FSTAB_SOURCE=""
ROOT_MOUNT_TEMP=""

# Try to get fstab from the target disk's root partition
if [ -b "$P2" ]; then
    # Check if P2 (root partition) is already mounted
    P2_MOUNT=$(findmnt -n -o TARGET "$P2" 2>/dev/null || echo "")
    
    if [ -n "$P2_MOUNT" ] && [ -f "$P2_MOUNT/etc/fstab" ]; then
        FSTAB_SOURCE="$P2_MOUNT/etc/fstab"
        print_info "Found fstab on already-mounted root partition: $P2_MOUNT"
    else
        # Try to mount it temporarily
        ROOT_MOUNT_TEMP="/tmp/backup_root_$$"
        mkdir -p "$ROOT_MOUNT_TEMP"
        
        if mount -o ro "$P2" "$ROOT_MOUNT_TEMP" 2>/dev/null; then
            if [ -f "$ROOT_MOUNT_TEMP/etc/fstab" ]; then
                FSTAB_SOURCE="$ROOT_MOUNT_TEMP/etc/fstab"
                print_info "Temporarily mounted $P2 to read fstab"
            fi
        else
            print_warn "Could not mount root partition to read fstab"
        fi
    fi
fi

# Backup the target disk's fstab if found
FSTAB_BACKUP="$BACKUP_DIR/fstab.backup"
if [ -n "$FSTAB_SOURCE" ] && [ -f "$FSTAB_SOURCE" ]; then
    cp "$FSTAB_SOURCE" "$FSTAB_BACKUP"
    print_success "Backed up fstab from target disk: $FSTAB_BACKUP"
else
    print_warn "Could not find fstab on target disk"
    # Fallback to current system's fstab
    if [ -f "/etc/fstab" ]; then
        cp /etc/fstab "$FSTAB_BACKUP"
        print_info "Using current system's fstab as backup"
    fi
fi

# Unmount temporary mount if we created it
if [ -n "$ROOT_MOUNT_TEMP" ] && mountpoint -q "$ROOT_MOUNT_TEMP" 2>/dev/null; then
    umount "$ROOT_MOUNT_TEMP" 2>/dev/null || true
    rmdir "$ROOT_MOUNT_TEMP" 2>/dev/null || true
fi

echo ""
print_header "Recording All Partition Information"

# Save information for ALL partitions
echo "# All Partitions Information - Generated on $(date)" > "$ALL_PARTS_FILE"
echo "# Format: partition_number|device|uuid|fstype|size_bytes|size_mb|mountpoint|partuuid" >> "$ALL_PARTS_FILE"
echo "" >> "$ALL_PARTS_FILE"

echo "# UUID Mapping File - Generated on $(date)" > "$UUID_MAP_FILE"
echo "# Format: partition_number:uuid:fstype:size_mb:partuuid" >> "$UUID_MAP_FILE"
echo "# This file is used by restoration script to recreate partitions with exact UUIDs" >> "$UUID_MAP_FILE"
echo "" >> "$UUID_MAP_FILE"

for part_num in {1..20}; do
    part=$(get_partition_name $part_num)
    if [ -b "$part" ]; then
        uuid=$(blkid -s UUID -o value "$part" 2>/dev/null || echo "unknown")
        fstype=$(blkid -s TYPE -o value "$part" 2>/dev/null || echo "unknown")
        size_bytes=$(blockdev --getsize64 "$part" 2>/dev/null || echo "0")
        size_mb=$((size_bytes / 1024 / 1024))
        mountpoint=$(findmnt -n -o TARGET "$part" 2>/dev/null || echo "not_mounted")
        
        # Get PARTUUID as well (useful for GPT partitions)
        partuuid=$(blkid -s PARTUUID -o value "$part" 2>/dev/null || echo "unknown")
        
        # Determine label for main partitions
        case $part_num in
            1) label="efi" ;;
            2) label="root" ;;
            3) label="home" ;;
            4) label="var" ;;
            *) label="partition${part_num}" ;;
        esac
        
        # Save to all partitions info file
        echo "${part_num}|${part}|${uuid}|${fstype}|${size_bytes}|${size_mb}|${mountpoint}|${partuuid}" >> "$ALL_PARTS_FILE"
        
        # Save to partition sizes file (partition_number:size_in_MB)
        echo "${part_num}:${size_mb}" >> "$SIZES_FILE"
        
        # Save to UUID mapping file (machine-readable)
        echo "${part_num}:${uuid}:${fstype}:${size_mb}:${partuuid}" >> "$UUID_MAP_FILE"
        
        # Save to UUID file with labels for main partitions (human-readable)
        if [ $part_num -le 4 ]; then
            echo "${label}: $part, UUID=$uuid, PARTUUID=$partuuid, FS=$fstype, SIZE=${size_mb}MB, MOUNT=$mountpoint" >> "$UUID_FILE"
        else
            echo "partition${part_num}: $part, UUID=$uuid, PARTUUID=$partuuid, FS=$fstype, SIZE=${size_mb}MB, MOUNT=$mountpoint" >> "$UUID_FILE"
        fi
        
        print_info "Recorded: $part (${size_mb}MB, UUID=$uuid, FS=$fstype)"
    fi
done

print_success "All partition information recorded"
echo ""

# Backup function (only for main 4 partitions) - RAW IMAGE VERSION
backup_partition() {
    local label="$1"
    local partition="$2"
    local backup_file="$BACKUP_DIR/${label}.img"
    
    if [ ! -b "$partition" ]; then
        print_warn "Partition $partition not found, skipping."
        return
    fi
    
    # Check if backup already exists
    if [ -f "$backup_file" ]; then
        print_warn "Backup file $backup_file already exists"
        read -rp "Overwrite? (yes/no): " overwrite
        if [ "$overwrite" != "yes" ]; then
            print_info "Skipping $label"
            return
        fi
        rm -f "$backup_file"
    fi
    
    # Get partition info
    uuid=$(blkid -s UUID -o value "$partition" 2>/dev/null || echo "unknown")
    partuuid=$(blkid -s PARTUUID -o value "$partition" 2>/dev/null || echo "unknown")
    fstype=$(blkid -s TYPE -o value "$partition" 2>/dev/null || echo "unknown")
    
    # Get partition size in MB
    part_size_bytes=$(blockdev --getsize64 "$partition")
    part_size_mb=$((part_size_bytes / 1024 / 1024))
    
    print_header "Backing Up: $label"
    print_info "Partition: $partition"
    print_info "UUID: $uuid"
    print_info "PARTUUID: $partuuid"
    print_info "FS Type: $fstype"
    print_info "Size: ${part_size_mb}MB ($(echo "scale=2; $part_size_mb/1024" | bc)GB)"
    print_info "Output: $backup_file"
    echo ""
    
    # Check if partition is mounted
    if mountpoint -q "$(findmnt -n -o TARGET "$partition" 2>/dev/null)" 2>/dev/null; then
        print_warn "Partition $partition is currently mounted"
        print_warn "For best results, backup should be done on unmounted partitions"
        read -rp "Continue anyway? (yes/no): " continue_mounted
        if [ "$continue_mounted" != "yes" ]; then
            print_info "Skipping $label"
            return
        fi
    fi
    
    # Perform backup - RAW IMAGE (no compression)
    print_info "Creating raw image (this may take a while)..."
    
    # Use pv for progress if available
    if command -v pv &> /dev/null; then
        dd if="$partition" bs=16M status=none conv=sync,noerror iflag=fullblock | \
            pv -s "$part_size_bytes" -N "$label" -pterb > "$backup_file"
    else
        dd if="$partition" of="$backup_file" bs=16M status=progress conv=sync,noerror iflag=fullblock
    fi
    
    # Verify backup was created
    if [ -f "$backup_file" ]; then
        local file_size=$(du -h "$backup_file" | cut -f1)
        print_success "Backup completed: $backup_file"
        print_info "File size: $file_size"
    else
        print_error "Backup failed for $label"
    fi
    
    echo ""
}

# Backup only the 4 main partitions
print_header "Starting Raw Image Backup Process"
echo ""

backup_partition "efi" "$P1"
backup_partition "root" "$P2"
backup_partition "home" "$P3"
backup_partition "var" "$P4"

# Final summary
print_header "Backup Complete"
print_success "All partition images backed up successfully!"
echo ""
print_info "Backup location: $BACKUP_DIR"
print_info "Raw image backup files:"

if [ -f "$BACKUP_DIR/efi.img" ]; then
    echo "  ✓ efi.img  - $(du -h "$BACKUP_DIR/efi.img" | cut -f1)"
fi
if [ -f "$BACKUP_DIR/root.img" ]; then
    echo "  ✓ root.img - $(du -h "$BACKUP_DIR/root.img" | cut -f1)"
fi
if [ -f "$BACKUP_DIR/home.img" ]; then
    echo "  ✓ home.img - $(du -h "$BACKUP_DIR/home.img" | cut -f1)"
fi
if [ -f "$BACKUP_DIR/var.img" ]; then
    echo "  ✓ var.img  - $(du -h "$BACKUP_DIR/var.img" | cut -f1)"
fi

echo ""
print_info "Configuration files:"
echo "  ✓ $UUID_FILE (human-readable UUID info)"
echo "  ✓ $UUID_MAP_FILE (machine-readable UUID mapping)"
echo "  ✓ $SIZES_FILE (partition sizes)"
echo "  ✓ $ALL_PARTS_FILE (detailed partition info)"
if [ -f "$FSTAB_BACKUP" ]; then
    echo "  ✓ $FSTAB_BACKUP (original fstab from target disk)"
fi
echo ""

print_info "UUID mapping file contents (for restoration):"
cat "$UUID_MAP_FILE"
echo ""

if [ -f "$FSTAB_BACKUP" ]; then
    print_info "Original fstab backup:"
    echo "---"
    cat "$FSTAB_BACKUP"
    echo "---"
    echo ""
fi

print_success "Backup completed successfully!"
print_info "Total backup size: $(du -sh "$BACKUP_DIR" | cut -f1)"
echo ""
print_info "To restore these backups, use the restoration script"
print_info "The restoration script will:"
echo "  - Recreate ALL partitions with exact sizes from $SIZES_FILE"
echo "  - Restore UUIDs for all partitions from $UUID_MAP_FILE"
echo "  - Restore raw images for: EFI, Root, Home, Var"
echo "  - Format additional partitions (5+) with correct filesystem and UUID"
echo "  - Copy fstab.backup to /etc/fstab"
echo ""
print_success "Backup process completed!"
