#!/bin/bash
# Setup First Boot SQL Execution
# This creates a systemd service that runs SQL on first boot

set -e

echo "Creating first-boot SQL execution service..."

# Create the SQL execution script
sudo tee /usr/local/bin/etap-first-boot-sql.sh > /dev/null << 'EOF'
#!/bin/bash
# ETAP First Boot SQL Execution
# Runs once on first boot to execute app.sql

LOG_FILE="/var/log/etap-first-boot-sql.log"
SQL_FILE="/app/db/app.sql"
MYSQL_CONTAINER="etap-mysql"
MYSQL_USER="root"
MYSQL_PASS="#!cmai2013"
MYSQL_DB="etap_kiosk"
MAX_WAIT=300

echo "$(date): ETAP First Boot SQL Execution Started" >> "$LOG_FILE"

# Wait for Docker to be available
echo "$(date): Waiting for Docker..." >> "$LOG_FILE"
WAIT_COUNT=0
while ! command -v docker &> /dev/null && [ $WAIT_COUNT -lt 60 ]; do
    sleep 2
    ((WAIT_COUNT+=2))
done

if ! command -v docker &> /dev/null; then
    echo "$(date): Docker not available after 120s, exiting" >> "$LOG_FILE"
    exit 1
fi

echo "$(date): Docker is available" >> "$LOG_FILE"

# Wait for MySQL container
echo "$(date): Waiting for MySQL container..." >> "$LOG_FILE"
WAIT_COUNT=0
while [ $WAIT_COUNT -lt $MAX_WAIT ]; do
    if docker ps --format "{{.Names}}" | grep -q "^${MYSQL_CONTAINER}$"; then
        HEALTH_STATUS=$(docker inspect --format='{{.State.Health.Status}}' "$MYSQL_CONTAINER" 2>/dev/null || echo "none")
        
        if [[ "$HEALTH_STATUS" == "healthy" ]]; then
            echo "$(date): MySQL container is healthy" >> "$LOG_FILE"
            break
        elif [[ "$HEALTH_STATUS" == "none" ]]; then
            if docker exec "$MYSQL_CONTAINER" mysqladmin ping -u"$MYSQL_USER" -p"$MYSQL_PASS" &>/dev/null; then
                echo "$(date): MySQL is responding" >> "$LOG_FILE"
                break
            fi
        fi
    fi
    
    sleep 2
    ((WAIT_COUNT+=2))
done

if [ $WAIT_COUNT -ge $MAX_WAIT ]; then
    echo "$(date): Timeout waiting for MySQL, exiting" >> "$LOG_FILE"
    exit 1
fi

# Check if SQL file exists
if [ ! -f "$SQL_FILE" ]; then
    echo "$(date): SQL file not found: $SQL_FILE" >> "$LOG_FILE"
    exit 0
fi

# Execute SQL
echo "$(date): Executing SQL file..." >> "$LOG_FILE"
if docker exec -i "$MYSQL_CONTAINER" mysql -u"$MYSQL_USER" -p"$MYSQL_PASS" "$MYSQL_DB" < "$SQL_FILE" 2>>"$LOG_FILE"; then
    echo "$(date): SQL executed successfully" >> "$LOG_FILE"
else
    echo "$(date): SQL execution completed with warnings" >> "$LOG_FILE"
fi

# Disable this service so it doesn't run again
systemctl disable etap-first-boot-sql.service

echo "$(date): First boot SQL execution completed" >> "$LOG_FILE"
EOF

sudo chmod +x /usr/local/bin/etap-first-boot-sql.sh

# Create systemd service
sudo tee /etc/systemd/system/etap-first-boot-sql.service > /dev/null << 'EOF'
[Unit]
Description=ETAP First Boot SQL Execution
After=docker.service
Requires=docker.service
ConditionPathExists=/app/db/app.sql

[Service]
Type=oneshot
ExecStart=/usr/local/bin/etap-first-boot-sql.sh
RemainAfterExit=yes
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# Enable the service
sudo systemctl daemon-reload
sudo systemctl enable etap-first-boot-sql.service

echo "✅ First boot SQL service created and enabled"
echo ""
echo "This service will:"
echo "  1. Run once on first boot"
echo "  2. Wait for Docker and MySQL to be ready"
echo "  3. Execute /app/db/app.sql"
echo "  4. Disable itself after running"
echo ""
echo "Log file: /var/log/etap-first-boot-sql.log"

