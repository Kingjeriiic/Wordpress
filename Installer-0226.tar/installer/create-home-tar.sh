#!/bin/bash
# Create Home TAR Archive Script
# Creates a tar archive of /home partition contents (partition 3)
# Usage: ./create-home-tar.sh <source_disk> <home_name>

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check parameters
if [ $# -ne 2 ]; then
    echo "Usage: $0 <source_disk> <home_name>"
    echo ""
    echo "Examples:"
    echo "  $0 /dev/sdb default-home       # Creates default-home.tar"
    echo "  $0 /dev/sdb kiosk-home         # Creates kiosk-home.tar"
    echo "  $0 /dev/nvme0n1 custom-home    # Creates custom-home.tar"
    echo ""
    echo "This will:"
    echo "  1. Mount /home partition (partition 3)"
    echo "  2. Create tar archive of contents"
    echo "  3. Save to /extra/os/base-images/"
    echo ""
    echo "Output: /extra/os/base-images/<home_name>.tar"
    exit 1
fi

SOURCE_DISK="$1"
HOME_NAME="$2"
OUTPUT_DIR="/extra/os/base-images"
OUTPUT_FILE="${OUTPUT_DIR}/${HOME_NAME}.tar"

# Banner
print_header "Home TAR Archive Creator"
echo ""
echo "Source disk: $SOURCE_DISK"
echo "Home name: $HOME_NAME"
echo "Output file: $OUTPUT_FILE"
echo ""

# Validate source disk
if [ ! -b "$SOURCE_DISK" ]; then
    print_error "Disk $SOURCE_DISK not found."
    exit 1
fi

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$SOURCE_DISK" == *"nvme"* ]] || [[ "$SOURCE_DISK" == *"mmcblk"* ]]; then
        echo "${SOURCE_DISK}p${part_num}"
    else
        echo "${SOURCE_DISK}${part_num}"
    fi
}

# Get home partition (partition 3)
HOME_PARTITION=$(get_partition_name 3)

# Validate home partition exists
if [ ! -b "$HOME_PARTITION" ]; then
    print_error "Home partition $HOME_PARTITION not found."
    print_error "Make sure partition 3 exists on $SOURCE_DISK"
    exit 1
fi

print_success "Found home partition: $HOME_PARTITION"
echo ""

# Get partition information
print_header "Partition Information"
HOME_SIZE=$(lsblk -b -n -o SIZE "$HOME_PARTITION" 2>/dev/null || echo "0")
HOME_SIZE_GB=$((HOME_SIZE / 1024 / 1024 / 1024))
HOME_SIZE_MB=$((HOME_SIZE / 1024 / 1024))
HOME_FSTYPE=$(lsblk -n -o FSTYPE "$HOME_PARTITION" 2>/dev/null || echo "unknown")
HOME_UUID=$(blkid -s UUID -o value "$HOME_PARTITION" 2>/dev/null || echo "unknown")
HOME_LABEL=$(blkid -s LABEL -o value "$HOME_PARTITION" 2>/dev/null || echo "none")
HOME_MOUNTPOINT=$(lsblk -n -o MOUNTPOINT "$HOME_PARTITION" 2>/dev/null || echo "")

print_info "Partition: $HOME_PARTITION"
print_info "Size: ${HOME_SIZE_GB}GB (${HOME_SIZE_MB}MB)"
print_info "Filesystem: $HOME_FSTYPE"
print_info "UUID: $HOME_UUID"
print_info "Label: $HOME_LABEL"

if [ -n "$HOME_MOUNTPOINT" ]; then
    print_info "Currently mounted at: $HOME_MOUNTPOINT"
else
    print_info "Not currently mounted"
fi
echo ""

# Create output directory if it doesn't exist
if [ ! -d "$OUTPUT_DIR" ]; then
    print_info "Creating output directory: $OUTPUT_DIR"
    mkdir -p "$OUTPUT_DIR"
fi

# Check if file already exists
if [ -f "$OUTPUT_FILE" ]; then
    print_warn "Output file already exists: $OUTPUT_FILE"
    existing_size=$(du -h "$OUTPUT_FILE" | cut -f1)
    print_info "Existing file size: $existing_size"
    echo ""
    read -p "Overwrite existing file? (yes/no): " confirm
    if [[ "$confirm" != "yes" ]]; then
        print_info "Operation cancelled by user"
        exit 0
    fi
    print_info "Removing existing file..."
    rm -f "$OUTPUT_FILE"
fi

# Mount home partition if not already mounted
MOUNT_POINT=""
NEED_UNMOUNT=false

if [ -n "$HOME_MOUNTPOINT" ]; then
    # Already mounted, use existing mount point
    MOUNT_POINT="$HOME_MOUNTPOINT"
    print_info "Using existing mount point: $MOUNT_POINT"
else
    # Need to mount
    MOUNT_POINT="/mnt/home_tar_source"
    mkdir -p "$MOUNT_POINT"
    
    print_info "Mounting home partition..."
    if mount -o ro "$HOME_PARTITION" "$MOUNT_POINT" 2>/dev/null; then
        print_success "Mounted home partition at $MOUNT_POINT (read-only)"
        NEED_UNMOUNT=true
    else
        print_error "Failed to mount home partition $HOME_PARTITION"
        rmdir "$MOUNT_POINT" 2>/dev/null || true
        exit 1
    fi
fi

# Check contents of /home
print_header "Analyzing /home Contents"
print_info "Scanning directory structure..."

# Count files and directories
FILE_COUNT=$(find "$MOUNT_POINT" -type f 2>/dev/null | wc -l)
DIR_COUNT=$(find "$MOUNT_POINT" -type d 2>/dev/null | wc -l)
USED_SPACE=$(du -sh "$MOUNT_POINT" 2>/dev/null | cut -f1)

print_info "Files: $FILE_COUNT"
print_info "Directories: $DIR_COUNT"
print_info "Used space: $USED_SPACE"
echo ""

# Show top-level contents
print_info "Top-level contents of /home:"
echo "----------------------------------------"
ls -lah "$MOUNT_POINT" 2>/dev/null | tail -n +4 || echo "Could not list contents"
echo "----------------------------------------"
echo ""

# Show user directories
print_info "User directories found:"
for user_dir in "$MOUNT_POINT"/*; do
    if [ -d "$user_dir" ]; then
        username=$(basename "$user_dir")
        user_size=$(du -sh "$user_dir" 2>/dev/null | cut -f1)
        echo "  - $username ($user_size)"
    fi
done
echo ""

# Confirm creation
read -p "Create TAR archive with these contents? (yes/no): " confirm
if [[ "$confirm" != "yes" ]]; then
    print_info "Operation cancelled by user"
    if [ "$NEED_UNMOUNT" = true ]; then
        umount "$MOUNT_POINT" 2>/dev/null || true
        rmdir "$MOUNT_POINT" 2>/dev/null || true
    fi
    exit 0
fi

# Create tar archive
print_header "Creating TAR Archive"
echo ""
print_info "Creating tar archive..."
print_info "This may take several minutes depending on data size"
echo ""

# Record start time
START_TIME=$(date '+%Y-%m-%d %H:%M:%S')
START_SECONDS=$(date +%s)
print_info "Start time: $START_TIME"
echo ""

# Create tar archive with progress
# Use tar without compression for faster speed
if command -v pv &> /dev/null; then
    # With progress bar using pv
    print_info "Creating archive with progress indicator..."
    tar -cf - -C "$MOUNT_POINT" . 2>/dev/null | pv -N "TAR Archive" -s $(du -sb "$MOUNT_POINT" 2>/dev/null | cut -f1) > "$OUTPUT_FILE"
    TAR_SUCCESS=$?
else
    # Without progress bar
    print_info "Creating archive (this may take a while)..."
    if tar -cf "$OUTPUT_FILE" -C "$MOUNT_POINT" . 2>/dev/null; then
        TAR_SUCCESS=0
    else
        TAR_SUCCESS=1
    fi
fi

# Record finish time
FINISH_TIME=$(date '+%Y-%m-%d %H:%M:%S')
FINISH_SECONDS=$(date +%s)
DURATION=$((FINISH_SECONDS - START_SECONDS))
DURATION_FORMATTED=$(printf '%02d:%02d:%02d' $((DURATION/3600)) $((DURATION%3600/60)) $((DURATION%60)))

echo ""
print_info "Finish time: $FINISH_TIME"
print_info "Duration: $DURATION_FORMATTED ($DURATION seconds)"
echo ""

# Check if tar was created successfully
if [ ! -f "$OUTPUT_FILE" ] || [ $TAR_SUCCESS -ne 0 ]; then
    print_error "TAR archive creation failed!"
    if [ "$NEED_UNMOUNT" = true ]; then
        umount "$MOUNT_POINT" 2>/dev/null || true
        rmdir "$MOUNT_POINT" 2>/dev/null || true
    fi
    exit 1
fi

# Verify tar archive
print_header "Verifying TAR Archive"
ARCHIVE_SIZE=$(stat -c%s "$OUTPUT_FILE" 2>/dev/null || echo "0")
ARCHIVE_SIZE_MB=$((ARCHIVE_SIZE / 1024 / 1024))
ARCHIVE_SIZE_HUMAN=$(du -h "$OUTPUT_FILE" | cut -f1)

print_info "Archive file: $OUTPUT_FILE"
print_info "Archive size: $ARCHIVE_SIZE_HUMAN (${ARCHIVE_SIZE_MB}MB)"

# Calculate compression ratio
ORIGINAL_SIZE_BYTES=$(du -sb "$MOUNT_POINT" 2>/dev/null | cut -f1)
if [ "$ORIGINAL_SIZE_BYTES" -gt 0 ]; then
    COMPRESSION_RATIO=$((100 - (ARCHIVE_SIZE * 100 / ORIGINAL_SIZE_BYTES)))
    print_info "Overhead: ${COMPRESSION_RATIO}% (tar format overhead)"
fi

# Test tar integrity
print_info "Testing archive integrity..."
if tar -tf "$OUTPUT_FILE" > /dev/null 2>&1; then
    print_success "Archive integrity verified"
else
    print_error "Archive integrity check failed!"
    if [ "$NEED_UNMOUNT" = true ]; then
        umount "$MOUNT_POINT" 2>/dev/null || true
        rmdir "$MOUNT_POINT" 2>/dev/null || true
    fi
    exit 1
fi

echo ""

# Unmount if we mounted it
if [ "$NEED_UNMOUNT" = true ]; then
    print_info "Unmounting home partition..."
    if umount "$MOUNT_POINT" 2>/dev/null; then
        print_success "Unmounted home partition"
    else
        print_warn "Could not unmount cleanly, but tar archive was created"
    fi
    rmdir "$MOUNT_POINT" 2>/dev/null || true
fi

# Save metadata
METADATA_FILE="${OUTPUT_FILE}.info"
print_info "Saving metadata to: $METADATA_FILE"

cat > "$METADATA_FILE" << EOF
# Home TAR Archive Metadata
# Created: $(date '+%Y-%m-%d %H:%M:%S')

SOURCE_DISK=$SOURCE_DISK
SOURCE_PARTITION=$HOME_PARTITION
PARTITION_NUMBER=3
PARTITION_SIZE_BYTES=$HOME_SIZE
PARTITION_SIZE_MB=$HOME_SIZE_MB
PARTITION_SIZE_GB=$HOME_SIZE_GB
FILESYSTEM=$HOME_FSTYPE
UUID=$HOME_UUID
LABEL=$HOME_LABEL
ARCHIVE_FILE=$OUTPUT_FILE
ARCHIVE_SIZE_BYTES=$ARCHIVE_SIZE
ARCHIVE_SIZE_MB=$ARCHIVE_SIZE_MB
ARCHIVE_FORMAT=tar
COMPRESSION=none
FILE_COUNT=$FILE_COUNT
DIR_COUNT=$DIR_COUNT
CREATION_TIME=$START_TIME
CREATION_DURATION=$DURATION_FORMATTED
CREATION_DURATION_SECONDS=$DURATION
EOF

print_success "Metadata saved"
echo ""

# Summary
print_header "TAR Archive Creation Complete"
print_success "Home tar archive created successfully!"
echo ""
print_info "Archive Details:"
echo "  📁 File: $OUTPUT_FILE"
echo "  📊 Size: $ARCHIVE_SIZE_HUMAN (${ARCHIVE_SIZE_MB}MB)"
echo "  🗜️  Format: tar (uncompressed)"
echo "  📦 Contents: $FILE_COUNT files, $DIR_COUNT directories"
echo "  💾 Original size: $USED_SPACE"
if [ "$ORIGINAL_SIZE_BYTES" -gt 0 ]; then
    echo "  📉 Overhead: ${COMPRESSION_RATIO}% (tar format overhead)"
fi
echo "  ⏱️  Creation time: $DURATION_FORMATTED"
echo "  📝 Metadata: $METADATA_FILE"
echo ""
print_info "Usage:"
echo "  To restore this archive:"
echo "  1. Partition 3 will be created and formatted (5GB)"
echo "  2. Archive will be extracted to /home"
echo "  3. User permissions and ownership will be preserved"
echo ""
echo "  Manual restore:"
echo "  mount /dev/sdX3 /mnt/home"
echo "  tar -xf $OUTPUT_FILE -C /mnt/home"
echo "  umount /mnt/home"
echo ""
print_success "TAR archive creation completed successfully!"

