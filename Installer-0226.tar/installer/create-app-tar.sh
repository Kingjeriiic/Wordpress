#!/bin/bash
# Create App TAR Archive Script
# Creates a compressed tar archive of /app partition contents
# Usage: ./create-app-tar.sh <source_disk> <app_name>

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check parameters
if [ $# -ne 2 ]; then
    echo "Usage: $0 <source_disk> <app_name>"
    echo ""
    echo "Examples:"
    echo "  $0 /dev/sdb myapp           # Creates myapp.tar"
    echo "  $0 /dev/sdb etap-inc        # Creates etap-inc.tar"
    echo "  $0 /dev/nvme0n1 pos-system  # Creates pos-system.tar"
    echo ""
    echo "This will:"
    echo "  1. Mount /app partition (partition 9)"
    echo "  2. Create tar archive of contents"
    echo "  3. Save to /extra/os/app-images/"
    echo ""
    echo "Output: /extra/os/app-images/<app_name>.tar"
    exit 1
fi

SOURCE_DISK="$1"
APP_NAME="$2"
OUTPUT_DIR="/extra/os/app-images"
OUTPUT_FILE="${OUTPUT_DIR}/${APP_NAME}.tar"

# Banner
print_header "App TAR Archive Creator"
echo ""
echo "Source disk: $SOURCE_DISK"
echo "App name: $APP_NAME"
echo "Output file: $OUTPUT_FILE"
echo ""

# Validate source disk
if [ ! -b "$SOURCE_DISK" ]; then
    print_error "Disk $SOURCE_DISK not found."
    exit 1
fi

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$SOURCE_DISK" == *"nvme"* ]] || [[ "$SOURCE_DISK" == *"mmcblk"* ]]; then
        echo "${SOURCE_DISK}p${part_num}"
    else
        echo "${SOURCE_DISK}${part_num}"
    fi
}

# Get app partition (partition 9)
APP_PARTITION=$(get_partition_name 9)

# Validate app partition exists
if [ ! -b "$APP_PARTITION" ]; then
    print_error "App partition $APP_PARTITION not found."
    print_error "Make sure partition 9 exists on $SOURCE_DISK"
    exit 1
fi

print_success "Found app partition: $APP_PARTITION"
echo ""

# Get partition information
print_header "Partition Information"
APP_SIZE=$(lsblk -b -n -o SIZE "$APP_PARTITION" 2>/dev/null || echo "0")
APP_SIZE_GB=$((APP_SIZE / 1024 / 1024 / 1024))
APP_SIZE_MB=$((APP_SIZE / 1024 / 1024))
APP_FSTYPE=$(lsblk -n -o FSTYPE "$APP_PARTITION" 2>/dev/null || echo "unknown")
APP_UUID=$(blkid -s UUID -o value "$APP_PARTITION" 2>/dev/null || echo "unknown")
APP_LABEL=$(blkid -s LABEL -o value "$APP_PARTITION" 2>/dev/null || echo "none")
APP_MOUNTPOINT=$(lsblk -n -o MOUNTPOINT "$APP_PARTITION" 2>/dev/null || echo "")

print_info "Partition: $APP_PARTITION"
print_info "Size: ${APP_SIZE_GB}GB (${APP_SIZE_MB}MB)"
print_info "Filesystem: $APP_FSTYPE"
print_info "UUID: $APP_UUID"
print_info "Label: $APP_LABEL"

if [ -n "$APP_MOUNTPOINT" ]; then
    print_info "Currently mounted at: $APP_MOUNTPOINT"
else
    print_info "Not currently mounted"
fi
echo ""

# Create output directory if it doesn't exist
if [ ! -d "$OUTPUT_DIR" ]; then
    print_info "Creating output directory: $OUTPUT_DIR"
    mkdir -p "$OUTPUT_DIR"
fi

# Check if output file already exists
if [ -f "$OUTPUT_FILE" ]; then
    print_warn "Output file already exists: $OUTPUT_FILE"
    existing_size=$(du -h "$OUTPUT_FILE" | cut -f1)
    print_info "Existing file size: $existing_size"
    echo ""
    read -p "Overwrite existing file? (yes/no): " confirm
    if [[ "$confirm" != "yes" ]]; then
        print_info "Operation cancelled by user"
        exit 0
    fi
    print_info "Removing existing file..."
    rm -f "$OUTPUT_FILE"
fi

# Mount app partition if not already mounted
MOUNT_POINT=""
NEED_UNMOUNT=false

if [ -n "$APP_MOUNTPOINT" ]; then
    # Already mounted, use existing mount point
    MOUNT_POINT="$APP_MOUNTPOINT"
    print_info "Using existing mount point: $MOUNT_POINT"
else
    # Need to mount
    MOUNT_POINT="/mnt/app_tar_source"
    mkdir -p "$MOUNT_POINT"
    
    print_info "Mounting app partition..."
    if mount -o ro "$APP_PARTITION" "$MOUNT_POINT" 2>/dev/null; then
        print_success "Mounted app partition at $MOUNT_POINT (read-only)"
        NEED_UNMOUNT=true
    else
        print_error "Failed to mount app partition $APP_PARTITION"
        rmdir "$MOUNT_POINT" 2>/dev/null || true
        exit 1
    fi
fi

# Check contents of /app
print_header "Analyzing /app Contents"
print_info "Scanning directory structure..."

# Count files and directories
FILE_COUNT=$(find "$MOUNT_POINT" -type f 2>/dev/null | wc -l)
DIR_COUNT=$(find "$MOUNT_POINT" -type d 2>/dev/null | wc -l)
USED_SPACE=$(du -sh "$MOUNT_POINT" 2>/dev/null | cut -f1)

print_info "Files: $FILE_COUNT"
print_info "Directories: $DIR_COUNT"
print_info "Used space: $USED_SPACE"
echo ""

# Show top-level contents
print_info "Top-level contents of /app:"
echo "----------------------------------------"
ls -lah "$MOUNT_POINT" 2>/dev/null | tail -n +4 || echo "Could not list contents"
echo "----------------------------------------"
echo ""

# Confirm operation
print_header "Confirmation"
echo "Ready to create tar archive with these settings:"
echo ""
echo "  Source: $APP_PARTITION (/app)"
echo "  Contents: $FILE_COUNT files, $DIR_COUNT directories"
echo "  Data size: $USED_SPACE"
echo "  Output: $OUTPUT_FILE"
echo "  Compression: gzip"
echo "  Estimated time: 2-10 minutes (depends on data size)"
echo ""
read -p "Proceed with tar archive creation? (yes/no): " final_confirm

if [[ "$final_confirm" != "yes" ]]; then
    print_info "Operation cancelled by user"
    if [ "$NEED_UNMOUNT" = true ]; then
        umount "$MOUNT_POINT" 2>/dev/null || true
        rmdir "$MOUNT_POINT" 2>/dev/null || true
    fi
    exit 0
fi

# Create tar archive
print_header "Creating TAR Archive"
echo ""
print_info "Creating tar archive..."
print_info "This may take several minutes depending on data size"
echo ""

# Record start time
START_TIME=$(date '+%Y-%m-%d %H:%M:%S')
START_SECONDS=$(date +%s)
print_info "Start time: $START_TIME"
echo ""

# Create tar archive with progress
# Use tar without compression for faster speed
if command -v pv &> /dev/null; then
    # With progress bar using pv
    print_info "Creating archive with progress indicator..."
    tar -cf - -C "$MOUNT_POINT" . 2>/dev/null | pv -N "TAR Archive" -s $(du -sb "$MOUNT_POINT" 2>/dev/null | cut -f1) > "$OUTPUT_FILE"
    TAR_SUCCESS=$?
else
    # Without progress bar
    print_info "Creating archive (this may take a while)..."
    if tar -cf "$OUTPUT_FILE" -C "$MOUNT_POINT" . 2>/dev/null; then
        TAR_SUCCESS=0
    else
        TAR_SUCCESS=1
    fi
fi

# Record finish time
FINISH_TIME=$(date '+%Y-%m-%d %H:%M:%S')
FINISH_SECONDS=$(date +%s)
DURATION=$((FINISH_SECONDS - START_SECONDS))
DURATION_FORMATTED=$(printf '%02d:%02d:%02d' $((DURATION/3600)) $((DURATION%3600/60)) $((DURATION%60)))

echo ""
print_info "Finish time: $FINISH_TIME"
print_info "Duration: $DURATION_FORMATTED ($DURATION seconds)"
echo ""

# Check if tar was created successfully
if [ ! -f "$OUTPUT_FILE" ] || [ $TAR_SUCCESS -ne 0 ]; then
    print_error "TAR archive creation failed!"
    if [ "$NEED_UNMOUNT" = true ]; then
        umount "$MOUNT_POINT" 2>/dev/null || true
        rmdir "$MOUNT_POINT" 2>/dev/null || true
    fi
    exit 1
fi

# Verify tar archive
print_header "Verifying TAR Archive"
ARCHIVE_SIZE=$(stat -c%s "$OUTPUT_FILE" 2>/dev/null || echo "0")
ARCHIVE_SIZE_MB=$((ARCHIVE_SIZE / 1024 / 1024))
ARCHIVE_SIZE_HUMAN=$(du -h "$OUTPUT_FILE" | cut -f1)

print_info "Archive file: $OUTPUT_FILE"
print_info "Archive size: $ARCHIVE_SIZE_HUMAN (${ARCHIVE_SIZE_MB}MB)"

# Calculate compression ratio
ORIGINAL_SIZE_BYTES=$(du -sb "$MOUNT_POINT" 2>/dev/null | cut -f1)
if [ "$ORIGINAL_SIZE_BYTES" -gt 0 ]; then
    COMPRESSION_RATIO=$((100 - (ARCHIVE_SIZE * 100 / ORIGINAL_SIZE_BYTES)))
    print_info "Compression ratio: ${COMPRESSION_RATIO}% saved"
fi

# Test tar integrity
print_info "Testing archive integrity..."
if tar -tf "$OUTPUT_FILE" > /dev/null 2>&1; then
    print_success "Archive integrity verified"
else
    print_error "Archive integrity check failed!"
    if [ "$NEED_UNMOUNT" = true ]; then
        umount "$MOUNT_POINT" 2>/dev/null || true
        rmdir "$MOUNT_POINT" 2>/dev/null || true
    fi
    exit 1
fi

echo ""

# Unmount if we mounted it
if [ "$NEED_UNMOUNT" = true ]; then
    print_info "Unmounting app partition..."
    if umount "$MOUNT_POINT" 2>/dev/null; then
        print_success "Unmounted app partition"
    else
        print_warn "Could not unmount cleanly, but tar archive was created"
    fi
    rmdir "$MOUNT_POINT" 2>/dev/null || true
fi

# Save metadata
METADATA_FILE="${OUTPUT_FILE}.info"
print_info "Saving metadata to: $METADATA_FILE"

cat > "$METADATA_FILE" << EOF
# App TAR Archive Metadata
# Created: $(date '+%Y-%m-%d %H:%M:%S')

SOURCE_DISK=$SOURCE_DISK
SOURCE_PARTITION=$APP_PARTITION
PARTITION_NUMBER=9
PARTITION_SIZE_BYTES=$APP_SIZE
PARTITION_SIZE_MB=$APP_SIZE_MB
PARTITION_SIZE_GB=$APP_SIZE_GB
FILESYSTEM=$APP_FSTYPE
UUID=$APP_UUID
LABEL=$APP_LABEL
ARCHIVE_FILE=$OUTPUT_FILE
ARCHIVE_SIZE_BYTES=$ARCHIVE_SIZE
ARCHIVE_SIZE_MB=$ARCHIVE_SIZE_MB
ARCHIVE_FORMAT=tar
COMPRESSION=none
FILE_COUNT=$FILE_COUNT
DIR_COUNT=$DIR_COUNT
CREATION_TIME=$START_TIME
CREATION_DURATION=$DURATION_FORMATTED
CREATION_DURATION_SECONDS=$DURATION
EOF

print_success "Metadata saved"
echo ""

# Summary
print_header "TAR Archive Creation Complete"
print_success "App tar archive created successfully!"
echo ""
print_info "Archive Details:"
echo "  📁 File: $OUTPUT_FILE"
echo "  📊 Size: $ARCHIVE_SIZE_HUMAN (${ARCHIVE_SIZE_MB}MB)"
echo "  🗜️  Format: tar (uncompressed)"
echo "  📦 Contents: $FILE_COUNT files, $DIR_COUNT directories"
echo "  💾 Original size: $USED_SPACE"
if [ "$ORIGINAL_SIZE_BYTES" -gt 0 ]; then
    echo "  📉 Overhead: ${COMPRESSION_RATIO}% (tar format overhead)"
fi
echo "  ⏱️  Creation time: $DURATION_FORMATTED"
echo "  📝 Metadata: $METADATA_FILE"
echo ""
print_info "Usage:"
echo "  To restore this archive:"
echo "  1. Partition 9 will be created and formatted (20GB)"
echo "  2. Archive will be extracted to /app"
echo "  3. Use the installer and select: $APP_NAME.tar"
echo ""
echo "  Manual restore:"
echo "  mount /dev/sdX9 /mnt/app"
echo "  tar -xf $OUTPUT_FILE -C /mnt/app"
echo "  umount /mnt/app"
echo ""
print_success "TAR archive creation completed successfully!"

