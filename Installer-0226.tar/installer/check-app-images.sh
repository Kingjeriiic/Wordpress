#!/bin/bash
# Quick script to check what app images are available

echo "=== Checking App Images Directory ==="
echo ""

# Check if directory exists
if [[ -d "/extra/os/app-images" ]]; then
    echo "✅ Directory exists: /extra/os/app-images"
    echo ""
    
    echo "📁 All files in directory:"
    ls -la /extra/os/app-images/
    echo ""
    
    echo "🔍 Searching for .img files:"
    find /extra/os/app-images -name "*.img" -ls 2>/dev/null || echo "No .img files found"
    echo ""
    
    echo "🔍 Searching for .img.gz files:"
    find /extra/os/app-images -name "*.img.gz" -ls 2>/dev/null || echo "No .img.gz files found"
    echo ""
    
    echo "🔍 Searching for .tar.gz files:"
    find /extra/os/app-images -name "*.tar.gz" -ls 2>/dev/null || echo "No .tar.gz files found"
    echo ""
    
    echo "📊 Summary:"
    img_count=$(find /extra/os/app-images -name "*.img" 2>/dev/null | wc -l)
    imgz_count=$(find /extra/os/app-images -name "*.img.gz" 2>/dev/null | wc -l)
    targz_count=$(find /extra/os/app-images -name "*.tar.gz" 2>/dev/null | wc -l)
    
    echo "  .img files: $img_count"
    echo "  .img.gz files: $imgz_count"
    echo "  .tar.gz files: $targz_count"
    
else
    echo "❌ Directory does not exist: /extra/os/app-images"
    echo ""
    echo "Creating directory..."
    mkdir -p /extra/os/app-images
    echo "✅ Directory created"
fi

echo ""
echo "=== Test Complete ==="
