#!/bin/bash
# Restore App TAR Archive Script
# Extracts tar archive to /app partition (partition 9)
# Usage: ./restore-app-tar.sh <target_disk> <tar_file>

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check parameters
if [ $# -ne 2 ]; then
    echo "Usage: $0 <target_disk> <tar_file>"
    echo ""
    echo "Examples:"
    echo "  $0 /dev/sdb /extra/os/app-images/myapp.tar"
    echo "  $0 /dev/sdb myapp.tar"
    echo "  $0 /dev/nvme0n1 /extra/os/app-images/etap-inc.tar"
    echo ""
    echo "This will:"
    echo "  1. Mount /app partition (partition 9)"
    echo "  2. Extract tar archive contents to /app"
    echo "  3. Preserve permissions and ownership"
    exit 1
fi

TARGET_DISK="$1"
TAR_FILE="$2"

# If tar file doesn't have full path, assume it's in /extra/os/app-images
if [[ ! "$TAR_FILE" =~ ^/ ]]; then
    TAR_FILE="/extra/os/app-images/$TAR_FILE"
fi

# Banner
print_header "App TAR Archive Restore"
echo ""
echo "Target disk: $TARGET_DISK"
echo "TAR file: $TAR_FILE"
echo ""

# Validate target disk
if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

# Safety check: Exclude sda disk
if [[ "$TARGET_DISK" == "/dev/sda"* ]]; then
    print_error "SAFETY ERROR: sda disk is excluded for safety!"
    print_error "sda is typically the installer/system disk."
    print_error "Supported disks: sdb, sdc, nvme*"
    exit 1
fi

# Validate tar file exists
if [ ! -f "$TAR_FILE" ]; then
    print_error "TAR file not found: $TAR_FILE"
    exit 1
fi

print_success "Found TAR file: $TAR_FILE"

# Get tar file info
TAR_SIZE=$(stat -c%s "$TAR_FILE" 2>/dev/null || echo "0")
TAR_SIZE_MB=$((TAR_SIZE / 1024 / 1024))
TAR_SIZE_HUMAN=$(du -h "$TAR_FILE" | cut -f1)

print_info "TAR file size: $TAR_SIZE_HUMAN (${TAR_SIZE_MB}MB)"
echo ""

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Get app partition (partition 9)
APP_PARTITION=$(get_partition_name 9)

if [ ! -b "$APP_PARTITION" ]; then
    print_error "App partition $APP_PARTITION not found."
    print_error "Make sure the disk has been properly partitioned."
    exit 1
fi

print_success "Found app partition: $APP_PARTITION"
echo ""

# Get partition information
print_header "Partition Information"
APP_SIZE=$(lsblk -b -n -o SIZE "$APP_PARTITION" 2>/dev/null || echo "0")
APP_SIZE_GB=$((APP_SIZE / 1024 / 1024 / 1024))
APP_SIZE_MB=$((APP_SIZE / 1024 / 1024))
APP_FSTYPE=$(lsblk -n -o FSTYPE "$APP_PARTITION" 2>/dev/null || echo "unknown")
APP_UUID=$(blkid -s UUID -o value "$APP_PARTITION" 2>/dev/null || echo "unknown")

print_info "Partition: $APP_PARTITION"
print_info "Size: ${APP_SIZE_GB}GB (${APP_SIZE_MB}MB)"
print_info "Filesystem: $APP_FSTYPE"
print_info "UUID: $APP_UUID"
echo ""

# Check if partition has enough space
if [ $TAR_SIZE_MB -gt $APP_SIZE_MB ]; then
    print_error "TAR file is larger than partition!"
    print_error "TAR size: ${TAR_SIZE_MB}MB, Partition size: ${APP_SIZE_MB}MB"
    exit 1
fi

print_success "Partition has sufficient space"
echo ""

# Mount app partition
MOUNT_POINT="/mnt/app_tar_restore"
mkdir -p "$MOUNT_POINT"

print_info "Mounting app partition..."
if mount "$APP_PARTITION" "$MOUNT_POINT" 2>/dev/null; then
    print_success "Mounted app partition at $MOUNT_POINT"
else
    print_error "Failed to mount app partition $APP_PARTITION"
    print_error "Make sure the app partition is properly formatted (ext4)."
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

# Check if partition is empty or has existing data
EXISTING_FILES=$(find "$MOUNT_POINT" -mindepth 1 -maxdepth 1 2>/dev/null | wc -l)

if [ $EXISTING_FILES -gt 0 ]; then
    print_warn "App partition is not empty ($EXISTING_FILES items found)"
    print_info "Existing contents will be overwritten by tar extraction"
else
    print_info "App partition is empty (clean installation)"
fi
echo ""

# Extract tar archive
print_header "Extracting TAR Archive"
echo ""
print_info "Extracting tar archive to /app..."
print_info "This may take several minutes depending on archive size"
echo ""

# Record start time
START_TIME=$(date '+%Y-%m-%d %H:%M:%S')
START_SECONDS=$(date +%s)
print_info "Start time: $START_TIME"
echo ""

# Extract tar with progress
if command -v pv &> /dev/null; then
    # With progress bar using pv
    print_info "Extracting with progress indicator..."
    pv -N "Extracting" "$TAR_FILE" | tar -xf - -C "$MOUNT_POINT" 2>/dev/null
    TAR_SUCCESS=$?
else
    # Without progress bar
    print_info "Extracting (this may take a while)..."
    if tar -xf "$TAR_FILE" -C "$MOUNT_POINT" 2>/dev/null; then
        TAR_SUCCESS=0
    else
        TAR_SUCCESS=1
    fi
fi

# Record finish time
FINISH_TIME=$(date '+%Y-%m-%d %H:%M:%S')
FINISH_SECONDS=$(date +%s)
DURATION=$((FINISH_SECONDS - START_SECONDS))
DURATION_FORMATTED=$(printf '%02d:%02d:%02d' $((DURATION/3600)) $((DURATION%3600/60)) $((DURATION%60)))

echo ""
print_info "Finish time: $FINISH_TIME"
print_info "Duration: $DURATION_FORMATTED ($DURATION seconds)"
echo ""

# Check if extraction was successful
if [ $TAR_SUCCESS -ne 0 ]; then
    print_error "TAR extraction failed!"
    umount "$MOUNT_POINT" 2>/dev/null || true
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

print_success "TAR extraction completed"

# Verify extraction
print_header "Verifying Extraction"

# Count extracted files
EXTRACTED_FILES=$(find "$MOUNT_POINT" -type f 2>/dev/null | wc -l)
EXTRACTED_DIRS=$(find "$MOUNT_POINT" -type d 2>/dev/null | wc -l)
EXTRACTED_SIZE=$(du -sh "$MOUNT_POINT" 2>/dev/null | cut -f1)

print_info "Extracted files: $EXTRACTED_FILES"
print_info "Extracted directories: $EXTRACTED_DIRS"
print_info "Total size: $EXTRACTED_SIZE"
echo ""

# Show top-level contents
print_info "Top-level contents of /app:"
echo "----------------------------------------"
ls -lah "$MOUNT_POINT" 2>/dev/null | tail -n +4 || echo "Could not list contents"
echo "----------------------------------------"
echo ""

# Sync to ensure all data is written
print_info "Syncing data to disk..."
sync
print_success "Data synced"
echo ""

# Unmount app partition
print_info "Unmounting app partition..."
if umount "$MOUNT_POINT" 2>/dev/null; then
    print_success "Unmounted app partition"
else
    print_warn "Could not unmount cleanly, but extraction was completed"
fi

rmdir "$MOUNT_POINT" 2>/dev/null || true

# Summary
print_header "TAR Archive Restore Complete"
print_success "App tar archive restored successfully!"
echo ""
print_info "Restore Summary:"
echo "  ✅ Source: $TAR_FILE"
echo "  ✅ Target: $APP_PARTITION (/app partition)"
echo "  ✅ Files extracted: $EXTRACTED_FILES"
echo "  ✅ Directories extracted: $EXTRACTED_DIRS"
echo "  ✅ Total size: $EXTRACTED_SIZE"
echo "  ✅ Extraction time: $DURATION_FORMATTED"
echo ""
print_info "The /app partition is now ready with restored contents."
print_success "TAR archive restore completed successfully!"

# Output specific message for installer detection
echo "TAR archive restore completed successfully"

