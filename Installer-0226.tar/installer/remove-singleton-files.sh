#!/bin/bash
# Script to forcefully remove Chromium singleton files from target SSD

set -e

# Check if target disk is provided
if [ $# -ne 1 ]; then
    echo "Usage: $0 <target_disk>"
    echo "Example: $0 /dev/sdb"
    exit 1
fi

TARGET_DISK="$1"

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

ROOT_PART=$(get_partition_name 2)

if [ ! -b "$ROOT_PART" ]; then
    echo "ERROR: Root partition $ROOT_PART not found."
    exit 1
fi

echo "=== Removing Chromium Singleton Files ==="
echo "Target disk: $TARGET_DISK"
echo "Root partition: $ROOT_PART"
echo ""

# Mount root partition as read-write
MOUNT_POINT="/mnt/singleton_cleanup"
mkdir -p "$MOUNT_POINT"

echo "Mounting root partition as read-write..."
if mount -o rw "$ROOT_PART" "$MOUNT_POINT" 2>/dev/null; then
    echo "✓ Mounted successfully"
else
    echo "✗ Failed to mount $ROOT_PART"
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

# Remove singleton files
echo ""
echo "Removing singleton files..."

SINGLETON_LOCATIONS=(
    "$MOUNT_POINT/home/etkiosk/snap/chromium/common/chromium"
    "$MOUNT_POINT/home/etdev/snap/chromium/common/chromium"
    "$MOUNT_POINT/home/etkiosk/.config/chromium"
    "$MOUNT_POINT/home/etdev/.config/chromium"
    "$MOUNT_POINT/root/snap/chromium/common/chromium"
    "$MOUNT_POINT/root/.config/chromium"
)

SINGLETON_FILES=(
    "SingletonCookie"
    "SingletonLock"
    "SingletonSocket"
)

removed_count=0

for location in "${SINGLETON_LOCATIONS[@]}"; do
    if [ -d "$location" ]; then
        echo "Checking: $location"
        
        # Remove all Singleton* files
        for singleton_file in "$location"/Singleton*; do
            if [ -f "$singleton_file" ]; then
                rm -f "$singleton_file" 2>/dev/null || true
                echo "  ✓ Removed: $(basename "$singleton_file")"
                ((removed_count++))
            fi
        done
        
        # Remove specific singleton files
        for singleton_file in "${SINGLETON_FILES[@]}"; do
            if [ -f "$location/$singleton_file" ]; then
                rm -f "$location/$singleton_file" 2>/dev/null || true
                echo "  ✓ Removed: $singleton_file"
                ((removed_count++))
            fi
        done
    fi
done

echo ""
echo "Removed $removed_count singleton files"

# Verify removal
echo ""
echo "Verifying removal..."
found_files=0
for location in "${SINGLETON_LOCATIONS[@]}"; do
    if [ -d "$location" ]; then
        for singleton_file in "$location"/Singleton*; do
            if [ -f "$singleton_file" ]; then
                echo "  ✗ Still exists: $singleton_file"
                ((found_files++))
            fi
        done
    fi
done

if [ $found_files -eq 0 ]; then
    echo "✓ All singleton files removed successfully"
else
    echo "✗ $found_files singleton files still exist"
fi

# Unmount
echo ""
echo "Unmounting..."
if umount "$MOUNT_POINT" 2>/dev/null; then
    echo "✓ Unmounted successfully"
else
    echo "✗ Failed to unmount cleanly"
fi

rmdir "$MOUNT_POINT" 2>/dev/null || true

echo ""
echo "=== Cleanup Complete ==="
echo "Removed $removed_count singleton files"
echo "You can now boot the target system and Chromium should work properly"
