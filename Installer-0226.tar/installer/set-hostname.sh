#!/bin/bash
# Hostname Setup Script for ETAP Installer
# Sets hostname based on user input (TERMINAL_ID)
# Usage: ./set-hostname.sh <target_disk> [terminal_id]

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check if target disk is provided
if [ $# -lt 1 ]; then
    echo "Usage: $0 <target_disk> [terminal_id]"
    echo "Example: $0 /dev/sdb KIOSK001"
    echo "Example: $0 /dev/sdb (will prompt for terminal ID)"
    exit 1
fi

TARGET_DISK="$1"

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Validate target disk
if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

# Safety check: Exclude sda disk
if [[ "$TARGET_DISK" == "/dev/sda"* ]]; then
    print_error "SAFETY ERROR: sda disk is excluded for safety!"
    print_error "sda is typically the installer/system disk."
    print_error "Supported disks: sdb, sdc, nvme*"
    exit 1
fi

# Get root partition (partition 2)
ROOT_PART=$(get_partition_name 2)

if [ ! -b "$ROOT_PART" ]; then
    print_error "Root partition $ROOT_PART not found."
    print_error "Make sure the disk has been properly partitioned and restored."
    exit 1
fi

# Banner
print_header "ETAP Hostname Setup"
echo ""
echo "Target disk: $TARGET_DISK"
echo "Root partition: $ROOT_PART"
echo ""

# Get terminal ID from command line or prompt user
if [ $# -ge 2 ]; then
    TERMINAL_ID="$2"
    print_info "Using provided terminal ID: $TERMINAL_ID"
else
    echo "Enter the terminal ID for this system:"
    echo "Examples: KIOSK001, TERMINAL-A1, ETAP-BRANCH-01"
    echo ""
    read -rp "Terminal ID: " TERMINAL_ID
fi

# Validate terminal ID
if [ -z "$TERMINAL_ID" ]; then
    print_error "Terminal ID cannot be empty"
    exit 1
fi

# Clean terminal ID (remove spaces, convert to uppercase for consistency)
KIOSK_HOSTNAME=$(echo "$TERMINAL_ID" | tr '[:lower:]' '[:upper:]' | tr -d ' ')

print_info "Setting hostname to: $KIOSK_HOSTNAME"
echo ""

# Mount root partition
MOUNT_POINT="/mnt/hostname_setup"
mkdir -p "$MOUNT_POINT"

print_info "Mounting root partition..."
if mount "$ROOT_PART" "$MOUNT_POINT" 2>/dev/null; then
    print_success "Mounted root partition at $MOUNT_POINT"
else
    print_error "Failed to mount root partition $ROOT_PART"
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

# Set hostname
print_header "Setting Hostname"
print_info "[$(date)] Setting Hostname to: $KIOSK_HOSTNAME"

# Update /etc/hostname
if echo "$KIOSK_HOSTNAME" > "$MOUNT_POINT/etc/hostname"; then
    print_success "Updated /etc/hostname"
else
    print_error "Failed to update /etc/hostname"
    umount "$MOUNT_POINT" 2>/dev/null || true
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

# Update /etc/hosts
print_info "Updating /etc/hosts..."

# Backup original hosts file
if [ -f "$MOUNT_POINT/etc/hosts" ]; then
    cp "$MOUNT_POINT/etc/hosts" "$MOUNT_POINT/etc/hosts.backup" 2>/dev/null || true
fi

# Update the second line (127.0.1.1) with the new hostname
if sed -e "2s/.*/127.0.1.1 $KIOSK_HOSTNAME/" -i "$MOUNT_POINT/etc/hosts" 2>/dev/null; then
    print_success "Updated /etc/hosts"
else
    print_warn "Could not update /etc/hosts automatically"
    print_info "You may need to manually edit /etc/hosts after first boot"
fi

# Show the updated files
print_info "Hostname configuration:"
echo "----------------------------------------"
echo "/etc/hostname:"
cat "$MOUNT_POINT/etc/hostname" 2>/dev/null || echo "Could not read hostname file"
echo ""
echo "/etc/hosts:"
head -5 "$MOUNT_POINT/etc/hosts" 2>/dev/null || echo "Could not read hosts file"
echo "----------------------------------------"

# Fix X11 authentication issues that occur after hostname changes
print_info "Fixing X11 authentication for GUI applications..."

# Remove old X11 authentication files that reference the old hostname
if [ -d "$MOUNT_POINT/home/etkiosk" ]; then
    rm -f "$MOUNT_POINT/home/etkiosk/.Xauthority" 2>/dev/null || true
    rm -f "$MOUNT_POINT/home/etkiosk/.ICEauthority" 2>/dev/null || true
    print_info "Cleared X11 auth files for etkiosk user"
fi

# Fix Chromium singleton lock issue after hostname change
print_info "Fixing Chromium singleton locks after hostname change..."

# Remove Chromium singleton files for all users (these cause the lock error)
CHROMIUM_SINGLETON_PATHS=(
    "$MOUNT_POINT/home/etkiosk/.config/chromium/Singleton*"
    "$MOUNT_POINT/home/etdev/.config/chromium/Singleton*"
    "$MOUNT_POINT/root/.config/chromium/Singleton*"
    "$MOUNT_POINT/home/etkiosk/snap/chromium/common/chromium/Singleton*"
    "$MOUNT_POINT/home/etdev/snap/chromium/common/chromium/Singleton*"
    "$MOUNT_POINT/root/snap/chromium/common/chromium/Singleton*"
)

for chromium_path in "${CHROMIUM_SINGLETON_PATHS[@]}"; do
    if ls $chromium_path 1> /dev/null 2>&1; then
        rm -rf $chromium_path 2>/dev/null || true
        user_dir=$(echo "$chromium_path" | cut -d'/' -f4)
        if [[ "$chromium_path" == *"snap"* ]]; then
            print_info "Cleared Chromium snap singleton files for $user_dir"
        else
            print_info "Cleared Chromium singleton files for $user_dir"
        fi
    fi
done

# Also remove any Chromium lock files and cache that might reference old hostname
CHROMIUM_CLEANUP_PATHS=(
    "$MOUNT_POINT/home/etkiosk/.config/chromium/Local State"
    "$MOUNT_POINT/home/etkiosk/.config/chromium/Preferences"
    "$MOUNT_POINT/home/etdev/.config/chromium/Local State"
    "$MOUNT_POINT/home/etdev/.config/chromium/Preferences"
    "$MOUNT_POINT/root/.config/chromium/Local State"
    "$MOUNT_POINT/root/.config/chromium/Preferences"
    "$MOUNT_POINT/home/etkiosk/snap/chromium/common/chromium/Local State"
    "$MOUNT_POINT/home/etkiosk/snap/chromium/common/chromium/Preferences"
    "$MOUNT_POINT/home/etdev/snap/chromium/common/chromium/Local State"
    "$MOUNT_POINT/home/etdev/snap/chromium/common/chromium/Preferences"
    "$MOUNT_POINT/root/snap/chromium/common/chromium/Local State"
    "$MOUNT_POINT/root/snap/chromium/common/chromium/Preferences"
)

for cleanup_path in "${CHROMIUM_CLEANUP_PATHS[@]}"; do
    if [ -f "$cleanup_path" ]; then
        # Backup and remove files that might contain old hostname references
        cp "$cleanup_path" "$cleanup_path.backup" 2>/dev/null || true
        rm -f "$cleanup_path" 2>/dev/null || true
        user_dir=$(echo "$cleanup_path" | cut -d'/' -f4)
        if [[ "$cleanup_path" == *"snap"* ]]; then
            print_info "Reset Chromium snap config for $user_dir (backed up)"
        else
            print_info "Reset Chromium config for $user_dir (backed up)"
        fi
    fi
done

print_success "Fixed Chromium singleton lock issue"

# Clear any cached hostname references in systemd (but keep machine-id)
print_info "Refreshing systemd hostname cache..."
# Note: We don't remove machine-id files as they're needed for networking

# Create a script to fix X11 on first boot
mkdir -p "$MOUNT_POINT/usr/local/bin"
cat > "$MOUNT_POINT/usr/local/bin/fix-x11-after-hostname.sh" << 'EOF'
#!/bin/bash
# Fix X11 and Chromium issues after hostname change
# This script runs once on first boot after hostname change
# Special handling for ratpoison + auto-open Chromium setups

echo "$(date): Running post-hostname-change fixes for ratpoison/Chromium setup..."

# Kill any running Chromium processes first
pkill -f chromium 2>/dev/null || true
pkill -f chrome 2>/dev/null || true
echo "$(date): Killed any running Chromium processes"

# Wait a moment for processes to fully terminate
sleep 2

# Remove old X11 auth files for all users
find /home -name ".Xauthority" -delete 2>/dev/null || true
find /home -name ".ICEauthority" -delete 2>/dev/null || true
echo "$(date): Cleared X11 auth files"

# Remove Chromium singleton files that cause lock errors after hostname change
find /home -path "*/.config/chromium/Singleton*" -delete 2>/dev/null || true
find /root -path "*/.config/chromium/Singleton*" -delete 2>/dev/null || true
find /home -path "*/snap/chromium/common/chromium/Singleton*" -delete 2>/dev/null || true
find /root -path "*/snap/chromium/common/chromium/Singleton*" -delete 2>/dev/null || true
echo "$(date): Cleared Chromium singleton files (regular and snap)"

# Remove Chromium config files that might contain old hostname references
find /home -name ".config/chromium/Local State" -delete 2>/dev/null || true
find /home -name ".config/chromium/Preferences" -delete 2>/dev/null || true
find /root -name ".config/chromium/Local State" -delete 2>/dev/null || true
find /root -name ".config/chromium/Preferences" -delete 2>/dev/null || true
find /home -path "*/snap/chromium/common/chromium/Local State" -delete 2>/dev/null || true
find /home -path "*/snap/chromium/common/chromium/Preferences" -delete 2>/dev/null || true
find /root -path "*/snap/chromium/common/chromium/Local State" -delete 2>/dev/null || true
find /root -path "*/snap/chromium/common/chromium/Preferences" -delete 2>/dev/null || true
echo "$(date): Reset Chromium configuration files (regular and snap)"

# Clear any Chromium crash reports that might reference old hostname
find /home -path "*/.config/chromium/Crash Reports" -type f -delete 2>/dev/null || true
find /root -path "*/.config/chromium/Crash Reports" -type f -delete 2>/dev/null || true
echo "$(date): Cleared Chromium crash reports"

# For ratpoison setups, also clear any cached display/session info
find /home -name ".ratpoisonrc*" -type f -exec touch {} \; 2>/dev/null || true
echo "$(date): Refreshed ratpoison configuration"

# Restart display manager to regenerate X11 auth (this will restart ratpoison too)
systemctl restart gdm3 2>/dev/null || systemctl restart lightdm 2>/dev/null || systemctl restart sddm 2>/dev/null || true
echo "$(date): Restarted display manager (ratpoison will restart)"

echo "$(date): Post-hostname-change fixes completed for ratpoison/Chromium setup"

# Remove this script after running
rm -f /usr/local/bin/fix-x11-after-hostname.sh
rm -f /etc/systemd/system/fix-x11-hostname.service
systemctl daemon-reload

exit 0
EOF

chmod +x "$MOUNT_POINT/usr/local/bin/fix-x11-after-hostname.sh"

# Create systemd service to run the fix on first boot
mkdir -p "$MOUNT_POINT/etc/systemd/system"
cat > "$MOUNT_POINT/etc/systemd/system/fix-x11-hostname.service" << 'EOF'
[Unit]
Description=Fix X11 authentication after hostname change
After=graphical.target
Wants=graphical.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/fix-x11-after-hostname.sh
RemainAfterExit=yes

[Install]
WantedBy=graphical.target
EOF

# Enable the service to run on next boot
mkdir -p "$MOUNT_POINT/etc/systemd/system/graphical.target.wants"
ln -sf /etc/systemd/system/fix-x11-hostname.service "$MOUNT_POINT/etc/systemd/system/graphical.target.wants/fix-x11-hostname.service" 2>/dev/null || true

print_success "Created X11 fix service for first boot"

# Unmount
print_info "Unmounting root partition..."
if umount "$MOUNT_POINT" 2>/dev/null; then
    print_success "Unmounted root partition"
else
    print_warn "Could not unmount cleanly, but changes were saved"
fi

rmdir "$MOUNT_POINT" 2>/dev/null || true

# Summary
print_header "Hostname Setup Complete"
print_success "Hostname has been set to: $KIOSK_HOSTNAME"
echo ""
print_info "The system will use this hostname after the next boot."
print_info "You can verify the hostname after boot with: hostname"
echo ""
print_warn "IMPORTANT: Hostname change may affect running applications"
print_info "AUTOMATIC FIX: X11 authentication and Chromium locks will be fixed on next boot"
print_warn "If you experience issues with Chromium or other GUI applications:"
echo ""
echo "  1. RECOMMENDED: Reboot the system for clean hostname change"
echo "     sudo reboot"
echo "     (X11 authentication and Chromium singleton locks will be automatically fixed)"
echo ""
echo "  2. OR restart the display manager manually:"
echo "     sudo systemctl restart gdm3    # for GDM"
echo "     sudo systemctl restart lightdm # for LightDM"
echo ""
echo "  3. OR manually fix Chromium singleton lock issue:"
echo "     rm -rf ~/.config/chromium/Singleton*"
echo "     rm ~/.Xauthority ~/.ICEauthority"
echo "     logout and login again"
echo ""
print_warn "Note: If you need to change the hostname later:"
echo "  1. Edit /etc/hostname"
echo "  2. Edit /etc/hosts (update the 127.0.1.1 line)"
echo "  3. Reboot or run: sudo hostnamectl set-hostname NEW_HOSTNAME"
echo ""
print_success "Hostname setup completed successfully!"
print_info "RECOMMENDATION: Reboot now to ensure all services use the new hostname"
