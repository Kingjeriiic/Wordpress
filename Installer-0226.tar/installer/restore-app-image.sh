#!/bin/bash
# Restore App Image Script for ETAP
# Restores app.img to partition 9 (/app) on target disk
# Usage: ./restore-app-image.sh <target_disk> [app_image_name]

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check parameters
if [ $# -lt 1 ]; then
    echo "Usage: $0 <target_disk> [app_image_name]"
    echo ""
    echo "Examples:"
    echo "  $0 /dev/sdb                    # Interactive selection"
    echo "  $0 /dev/sdb etap-inc.img       # Direct restore"
    echo "  $0 /dev/nvme0n1 my-app.img     # NVMe disk"
    echo ""
    echo "This will restore an app image to partition 9 (/app) of the target disk"
    exit 1
fi

TARGET_DISK="$1"
APP_IMAGE="${2:-}"
APP_IMAGES_DIR="/extra/os/app-images"

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Validate target disk
if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

# Safety check: Exclude sda disk
if [[ "$TARGET_DISK" == "/dev/sda"* ]]; then
    print_error "SAFETY ERROR: sda disk is excluded for safety!"
    print_error "sda is typically the installer/system disk."
    print_error "Supported disks: sdb, sdc, nvme*"
    exit 1
fi

# Get app partition (partition 9)
APP_PARTITION=$(get_partition_name 9)

if [ ! -b "$APP_PARTITION" ]; then
    print_error "App partition $APP_PARTITION not found."
    print_error "Make sure the disk has been properly partitioned."
    print_error "Expected partition layout: partition 9 = /app"
    exit 1
fi

# Banner
print_header "ETAP App Image Restoration"
echo ""
echo "Target disk: $TARGET_DISK"
echo "App partition: $APP_PARTITION"
echo ""

# If no app image specified, show selection menu
if [[ -z "$APP_IMAGE" ]]; then
    print_info "Searching for available app images..."
    
    # Find all .img files in app-images directory
    if [[ ! -d "$APP_IMAGES_DIR" ]]; then
        print_error "App images directory not found: $APP_IMAGES_DIR"
        exit 1
    fi
    
    # Collect available images
    mapfile -t AVAILABLE_IMAGES < <(find "$APP_IMAGES_DIR" -maxdepth 1 -name "*.img" -type f -printf "%f\n" 2>/dev/null | sort)
    
    if [[ ${#AVAILABLE_IMAGES[@]} -eq 0 ]]; then
        print_error "No app images found in $APP_IMAGES_DIR"
        print_info "Please place .img files in $APP_IMAGES_DIR"
        exit 1
    fi
    
    print_success "Found ${#AVAILABLE_IMAGES[@]} app image(s)"
    echo ""
    
    # Display menu
    print_header "Available App Images"
    for i in "${!AVAILABLE_IMAGES[@]}"; do
        local img="${AVAILABLE_IMAGES[$i]}"
        local size=$(du -h "$APP_IMAGES_DIR/$img" 2>/dev/null | cut -f1)
        printf "%2d) %-30s %s\n" $((i+1)) "$img" "$size"
    done
    echo ""
    
    # Get user selection
    while true; do
        read -p "Select app image (1-${#AVAILABLE_IMAGES[@]}) or 'q' to quit: " selection
        
        if [[ "$selection" == "q" ]] || [[ "$selection" == "Q" ]]; then
            print_info "Restoration cancelled by user"
            exit 0
        fi
        
        if [[ "$selection" =~ ^[0-9]+$ ]] && [ "$selection" -ge 1 ] && [ "$selection" -le "${#AVAILABLE_IMAGES[@]}" ]; then
            APP_IMAGE="${AVAILABLE_IMAGES[$((selection-1))]}"
            break
        else
            print_error "Invalid selection. Please enter a number between 1 and ${#AVAILABLE_IMAGES[@]}"
        fi
    done
fi

# Validate app image file
APP_IMAGE_PATH="$APP_IMAGES_DIR/$APP_IMAGE"
if [ ! -f "$APP_IMAGE_PATH" ]; then
    print_error "App image not found: $APP_IMAGE_PATH"
    exit 1
fi

print_info "Selected app image: $APP_IMAGE"
echo ""

# Get image and partition information
print_header "Validation"
IMAGE_SIZE_BYTES=$(stat -c%s "$APP_IMAGE_PATH")
IMAGE_SIZE_MB=$((IMAGE_SIZE_BYTES / 1024 / 1024))
IMAGE_SIZE_GB=$((IMAGE_SIZE_MB / 1024))
IMAGE_SIZE_HUMAN=$(du -h "$APP_IMAGE_PATH" | cut -f1)

PARTITION_SIZE_BYTES=$(blockdev --getsize64 "$APP_PARTITION")
PARTITION_SIZE_MB=$((PARTITION_SIZE_BYTES / 1024 / 1024))
PARTITION_SIZE_GB=$((PARTITION_SIZE_MB / 1024))

print_info "Image size: ${IMAGE_SIZE_MB}MB (${IMAGE_SIZE_GB}GB) - $IMAGE_SIZE_HUMAN"
print_info "Partition size: ${PARTITION_SIZE_MB}MB (${PARTITION_SIZE_GB}GB)"

# Check if image fits in partition
if [ "$IMAGE_SIZE_BYTES" -gt "$PARTITION_SIZE_BYTES" ]; then
    print_error "Image is too large for partition!"
    print_error "Image: ${IMAGE_SIZE_MB}MB, Partition: ${PARTITION_SIZE_MB}MB"
    exit 1
fi

print_success "Image size validation passed"

# Check if partition is mounted
if mount | grep -q "$APP_PARTITION"; then
    print_warn "App partition is currently mounted"
    print_info "Attempting to unmount..."
    if umount "$APP_PARTITION" 2>/dev/null; then
        print_success "Unmounted app partition"
    else
        print_error "Failed to unmount app partition"
        print_error "Please manually unmount: umount $APP_PARTITION"
        exit 1
    fi
fi

# Final confirmation
echo ""
print_header "Confirmation"
print_warn "WARNING: This will OVERWRITE all data on $APP_PARTITION"
print_info "Target: $APP_PARTITION (/app partition)"
print_info "Source: $APP_IMAGE ($IMAGE_SIZE_HUMAN)"
echo ""
read -p "Are you sure you want to continue? (yes/no): " confirmation

if [[ "$confirmation" != "yes" ]]; then
    print_info "Restoration cancelled by user"
    exit 0
fi

# Restore app image
print_header "Restoring App Image"
echo ""

# Record start time
START_TIME=$(date '+%Y-%m-%d %H:%M:%S')
START_SECONDS=$(date +%s)
print_info "Start time: $START_TIME"
print_info "Restoring $APP_IMAGE to $APP_PARTITION..."
echo ""

# Use dd with progress if pv is available
if command -v pv &> /dev/null; then
    print_info "Using pv for progress indication..."
    if pv -N "Restoring app image" -pterb "$APP_IMAGE_PATH" | dd of="$APP_PARTITION" bs=16M conv=sync,noerror oflag=sync status=none iflag=fullblock; then
        DD_SUCCESS=true
    else
        DD_SUCCESS=false
    fi
else
    print_info "Restoring (this may take several minutes)..."
    if dd if="$APP_IMAGE_PATH" of="$APP_PARTITION" bs=16M conv=sync,noerror oflag=sync status=progress iflag=fullblock; then
        DD_SUCCESS=true
    else
        DD_SUCCESS=false
    fi
fi

# Sync to ensure all data is written
sync

# Record finish time
FINISH_TIME=$(date '+%Y-%m-%d %H:%M:%S')
FINISH_SECONDS=$(date +%s)
DURATION=$((FINISH_SECONDS - START_SECONDS))
DURATION_FORMATTED=$(printf '%02d:%02d:%02d' $((DURATION/3600)) $((DURATION%3600/60)) $((DURATION%60)))

echo ""
print_info "Finish time: $FINISH_TIME"
print_info "Duration: $DURATION_FORMATTED (${DURATION} seconds)"

if [ "$DD_SUCCESS" = true ]; then
    print_success "App image restored successfully"
else
    print_error "App image restoration failed"
    exit 1
fi

# Verify the restoration
print_header "Verification"
print_info "Verifying filesystem..."

# Check filesystem type
FSTYPE=$(blkid -o value -s TYPE "$APP_PARTITION" 2>/dev/null || echo "unknown")
print_info "Filesystem type: $FSTYPE"

# Run filesystem check and repair if needed
if [[ "$FSTYPE" == "ext4" ]] || [[ "$FSTYPE" == "ext3" ]] || [[ "$FSTYPE" == "ext2" ]]; then
    print_info "Running filesystem check..."
    if e2fsck -fy "$APP_PARTITION" >/dev/null 2>&1; then
        print_success "Filesystem check passed"
    else
        print_warn "Filesystem check reported issues (may be normal)"
    fi
    
    # Expand filesystem to fill partition if needed
    print_info "Expanding filesystem to fill partition..."
    if resize2fs "$APP_PARTITION" >/dev/null 2>&1; then
        print_success "Filesystem expanded successfully"
    else
        print_warn "Filesystem expansion not needed or failed"
    fi
fi

# Try to mount and check contents
TEMP_MOUNT="/mnt/app_verify_$$"
mkdir -p "$TEMP_MOUNT"

print_info "Verifying partition contents..."
if mount -o ro "$APP_PARTITION" "$TEMP_MOUNT" 2>/dev/null; then
    USED_SPACE=$(df -h "$TEMP_MOUNT" | tail -1 | awk '{print $3}')
    FILE_COUNT=$(find "$TEMP_MOUNT" -type f 2>/dev/null | wc -l)
    DIR_COUNT=$(find "$TEMP_MOUNT" -type d 2>/dev/null | wc -l)
    
    print_success "Partition mounted successfully"
    print_info "Used space: $USED_SPACE"
    print_info "Files: $FILE_COUNT"
    print_info "Directories: $DIR_COUNT"
    
    # Show top-level contents
    print_info "Top-level contents:"
    echo "----------------------------------------"
    ls -la "$TEMP_MOUNT" 2>/dev/null | head -10 || echo "Could not list contents"
    echo "----------------------------------------"
    
    umount "$TEMP_MOUNT" 2>/dev/null || true
else
    print_warn "Could not mount partition for verification"
fi

rmdir "$TEMP_MOUNT" 2>/dev/null || true

# Summary
print_header "App Image Restoration Complete"
print_success "App image restored successfully!"
echo ""
print_info "Restoration Summary:"
echo "  ✅ Target: $APP_PARTITION (/app partition)"
echo "  ✅ Source: $APP_IMAGE"
echo "  ✅ Size: $IMAGE_SIZE_HUMAN → ${PARTITION_SIZE_GB}GB partition"
echo "  ✅ Duration: $DURATION_FORMATTED"
echo "  ✅ Filesystem: $FSTYPE"
if [[ -n "${USED_SPACE:-}" ]]; then
    echo "  ✅ Used space: $USED_SPACE"
    echo "  ✅ Files: $FILE_COUNT"
fi
echo ""
print_info "The app partition is now ready for use."
print_success "App image restoration completed successfully!"

# Output specific message for automation detection
echo "App image restoration completed successfully"
