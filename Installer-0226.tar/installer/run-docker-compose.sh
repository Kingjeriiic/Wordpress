#!/bin/bash
# Run Docker Compose Script for ETAP Installer
# Runs docker-compose in target SSD partition 9 (/app/docker/)
# Usage: ./run-docker-compose.sh <target_disk>

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check if target disk is provided
if [ $# -ne 1 ]; then
    echo "Usage: $0 <target_disk>"
    echo "Example: $0 /dev/sdb"
    echo "Example: $0 /dev/nvme0n1"
    echo ""
    echo "This will run docker-compose in /app/docker/ on partition 9 of the target disk"
    exit 1
fi

TARGET_DISK="$1"

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Validate target disk
if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

# Safety check: Exclude sda disk
if [[ "$TARGET_DISK" == "/dev/sda"* ]]; then
    print_error "SAFETY ERROR: sda disk is excluded for safety!"
    print_error "sda is typically the installer/system disk."
    print_error "Supported disks: sdb, sdc, nvme*"
    exit 1
fi

# Get app partition (partition 9)
APP_PARTITION=$(get_partition_name 9)

if [ ! -b "$APP_PARTITION" ]; then
    print_error "App partition $APP_PARTITION not found."
    print_error "Make sure the disk has been properly partitioned and app image restored."
    exit 1
fi

# Banner
print_header "ETAP Docker Compose Setup"
echo ""
echo "Target disk: $TARGET_DISK"
echo "App partition: $APP_PARTITION"
echo ""

# Check if Docker is installed on the installer system
print_info "Checking Docker installation..."
if command -v docker &> /dev/null; then
    DOCKER_VERSION=$(docker --version 2>/dev/null || echo "unknown")
    print_success "Docker found: $DOCKER_VERSION"
else
    print_warn "Docker not found on installer system"
    print_info "Docker will need to be available on the target system"
fi

if command -v docker-compose &> /dev/null; then
    COMPOSE_VERSION=$(docker-compose --version 2>/dev/null || echo "unknown")
    print_success "Docker Compose found: $COMPOSE_VERSION"
else
    print_warn "Docker Compose not found on installer system"
    print_info "Docker Compose will need to be available on the target system"
fi

# Mount app partition
MOUNT_POINT="/mnt/app_docker_setup"
mkdir -p "$MOUNT_POINT"

print_info "Mounting app partition..."
if mount "$APP_PARTITION" "$MOUNT_POINT" 2>/dev/null; then
    print_success "Mounted app partition at $MOUNT_POINT"
else
    print_error "Failed to mount app partition $APP_PARTITION"
    print_error "Make sure the app partition is properly formatted and the app image was restored successfully."
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

# Check for docker directory and docker-compose.yml
DOCKER_DIR="$MOUNT_POINT/docker"
DOCKER_COMPOSE_FILE="$DOCKER_DIR/docker-compose.yml"

print_info "Checking for Docker directory and Docker Compose files..."

if [[ ! -d "$DOCKER_DIR" ]]; then
    print_error "/app/docker directory not found"
    print_error "Expected directory: $DOCKER_DIR"
    umount "$MOUNT_POINT" 2>/dev/null || true
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

print_success "Found /app/docker directory"

# List contents of docker directory
print_info "Contents of /app/docker/:"
echo "----------------------------------------"
ls -la "$DOCKER_DIR" 2>/dev/null || echo "Could not list directory contents"
echo "----------------------------------------"

# Check for docker-compose.yml
if [[ ! -f "$DOCKER_COMPOSE_FILE" ]]; then
    print_error "docker-compose.yml not found in /app/docker/"
    print_error "Expected file: $DOCKER_COMPOSE_FILE"
    umount "$MOUNT_POINT" 2>/dev/null || true
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

print_success "Found docker-compose.yml"

# Show docker-compose.yml info
COMPOSE_SIZE=$(du -h "$DOCKER_COMPOSE_FILE" | cut -f1)
print_info "Docker Compose file size: $COMPOSE_SIZE"

# Preview docker-compose.yml
print_info "Preview of docker-compose.yml (first 10 lines):"
echo "----------------------------------------"
head -10 "$DOCKER_COMPOSE_FILE" 2>/dev/null || echo "Could not preview file"
echo "----------------------------------------"

# Check for other expected files
EXPECTED_FILES=(
    "Dockerfile"
    "encoded-etap-kiosk"
    "tools"
)

print_info "Checking for additional files..."
for file in "${EXPECTED_FILES[@]}"; do
    if [[ -e "$DOCKER_DIR/$file" ]]; then
        if [[ -d "$DOCKER_DIR/$file" ]]; then
            print_success "Found directory: $file"
        else
            print_success "Found file: $file"
        fi
    else
        print_warn "Not found: $file"
    fi
done

# Create a script to run docker-compose on the target system
print_header "Creating Docker Compose Runner Script"

RUNNER_SCRIPT="$DOCKER_DIR/start-docker-compose.sh"
print_info "Creating startup script: /app/docker/start-docker-compose.sh"

cat > "$RUNNER_SCRIPT" << 'EOF'
#!/bin/bash
# Docker Compose Startup Script for ETAP Application
# This script runs docker-compose in the /app/docker directory

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_info "Starting ETAP Docker Compose Application..."
print_info "Working directory: /app/docker"

# Change to the docker directory
cd /app/docker

# Check if Docker is running
if ! docker info >/dev/null 2>&1; then
    print_error "Docker is not running or not accessible"
    print_info "Please ensure Docker service is started:"
    echo "  sudo systemctl start docker"
    echo "  sudo systemctl enable docker"
    exit 1
fi

# Check if docker-compose is available
if ! command -v docker-compose &> /dev/null; then
    print_error "docker-compose command not found"
    print_info "Please install docker-compose:"
    echo "  sudo apt-get install docker-compose"
    exit 1
fi

# Stop any existing containers
print_info "Stopping any existing containers..."
docker-compose down 2>/dev/null || true

# Pull latest images
print_info "Pulling Docker images..."
if docker-compose pull; then
    print_success "Images pulled successfully"
else
    print_error "Failed to pull images, continuing anyway..."
fi

# Start the application
print_info "Starting Docker Compose application..."
if docker-compose up -d; then
    print_success "Docker Compose application started successfully"
    
    # Show running containers
    print_info "Running containers:"
    docker-compose ps
    
    # Show logs for a few seconds
    print_info "Recent logs:"
    timeout 5 docker-compose logs --tail=20 || true
    
else
    print_error "Failed to start Docker Compose application"
    print_info "Check logs with: docker-compose logs"
    exit 1
fi

print_success "ETAP Docker application is now running!"
print_info "To view logs: docker-compose logs -f"
print_info "To stop: docker-compose down"
EOF

# Make the runner script executable
chmod +x "$RUNNER_SCRIPT"
print_success "Created executable startup script"

# Create systemd service for auto-start
print_info "Creating systemd service for auto-start..."
SERVICE_FILE="$MOUNT_POINT/etc/systemd/system/etap-docker.service"

# Check if we can access the root partition to create systemd service
ROOT_PARTITION=$(get_partition_name 2)
ROOT_MOUNT="/mnt/root_docker_service"
mkdir -p "$ROOT_MOUNT"

if mount "$ROOT_PARTITION" "$ROOT_MOUNT" 2>/dev/null; then
    print_success "Mounted root partition for systemd service creation"
    
    # Create systemd service
    mkdir -p "$ROOT_MOUNT/etc/systemd/system"
    cat > "$ROOT_MOUNT/etc/systemd/system/etap-docker.service" << EOF
[Unit]
Description=ETAP Docker Compose Application
Requires=docker.service
After=docker.service
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/app/docker
ExecStart=/app/docker/start-docker-compose.sh
ExecStop=/usr/bin/docker-compose down
TimeoutStartSec=300
User=root

[Install]
WantedBy=multi-user.target
EOF

    # Enable the service
    mkdir -p "$ROOT_MOUNT/etc/systemd/system/multi-user.target.wants"
    ln -sf /etc/systemd/system/etap-docker.service "$ROOT_MOUNT/etc/systemd/system/multi-user.target.wants/etap-docker.service" 2>/dev/null || true
    
    print_success "Created and enabled etap-docker.service"
    
    umount "$ROOT_MOUNT" 2>/dev/null || true
else
    print_warn "Could not mount root partition to create systemd service"
    print_info "You can manually create the service after boot"
fi

rmdir "$ROOT_MOUNT" 2>/dev/null || true

# Record completion time
FINISH_TIME=$(date '+%Y-%m-%d %H:%M:%S')
print_info "Setup completed at: $FINISH_TIME"

# Sync to ensure data is written
sync

# Unmount app partition
print_info "Unmounting app partition..."
if umount "$MOUNT_POINT" 2>/dev/null; then
    print_success "Unmounted app partition"
else
    print_warn "Could not unmount cleanly, but Docker setup was completed"
fi

rmdir "$MOUNT_POINT" 2>/dev/null || true

# Summary
print_header "Docker Compose Setup Complete"
print_success "Docker Compose setup completed successfully!"
echo ""
print_info "Setup Summary:"
echo "  ✅ Docker Compose file: /app/docker/docker-compose.yml"
echo "  ✅ Startup script: /app/docker/start-docker-compose.sh"
echo "  ✅ Systemd service: etap-docker.service (auto-start)"
echo "  ✅ Working directory: /app/docker"
echo ""
print_info "On the target system, the Docker application will:"
echo "  1. Start automatically on boot (via systemd service)"
echo "  2. Can be manually controlled with:"
echo "     - Start: sudo systemctl start etap-docker"
echo "     - Stop: sudo systemctl stop etap-docker"
echo "     - Status: sudo systemctl status etap-docker"
echo "  3. Manual control from /app/docker/:"
echo "     - Start: ./start-docker-compose.sh"
echo "     - Stop: docker-compose down"
echo "     - Logs: docker-compose logs -f"
echo ""
print_success "Docker Compose setup completed successfully!"

# Output specific message for installer detection
echo "Docker Compose setup completed successfully"
