#!/bin/bash
# Enhanced Non-interactive Restoration Script for ETAP installer
# Restores raw .img files from /extra/os/base-images with optimal alignment
# VERSION: 1GB App Partition (instead of 20GB)
# Usage: ./restoration-script-1gb-app.sh <target_disk>

set -euo pipefail

# Check if target disk is provided
if [ $# -ne 1 ]; then
    echo "Usage: $0 <target_disk>"
    echo "Example: $0 /dev/sdb"
    echo ""
    echo "NOTE: This version creates /app partition with 1GB (instead of 20GB)"
    exit 1
fi

TARGET_DISK="$1"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
BACKUP_DIR="/extra/os/base-images"

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Banner
print_header "Enhanced 4-Partition Restoration System (1GB App Version)"
echo ""
echo "This will restore EFI, Root, Home, and Var partitions from raw .img files"
echo "All partitions will be recreated with exact sizes and UUIDs"
echo "Includes automatic post-restoration fixes and optimal alignment"
echo "Backup location: $BACKUP_DIR"
echo ""
echo "VERSION: /app partition = 1GB (reduced from 20GB)"
echo ""
echo "SAFETY: sda disk is excluded to protect installer system"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Validate target disk
if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

# Safety check: Exclude sda disk to prevent accidental system damage
if [[ "$TARGET_DISK" == "/dev/sda"* ]]; then
    print_error "SAFETY ERROR: sda disk is excluded for safety!"
    print_error "sda is typically the system disk and should not be used for restoration."
    print_error "Supported disks: sdb, sdc, nvme*"
    print_error ""
    print_error "If you really need to restore to sda, use the interactive restoration script instead."
    exit 1
fi

print_info "Selected disk: $TARGET_DISK (safe disk confirmed)"
echo ""
echo "Target disk: $TARGET_DISK"
echo "Backup location: $BACKUP_DIR"
echo ""

# Check if backup directory exists
if [ ! -d "$BACKUP_DIR" ]; then
    print_error "Backup directory $BACKUP_DIR not found"
    exit 1
fi

# Check for required backup files (raw .img files)
REQUIRED_FILES=("uuid_mapping.txt" "efi.img" "root.img" "var.img" "home.img")
MISSING_FILES=()

print_info "Checking for required backup files..."
for file in "${REQUIRED_FILES[@]}"; do
    full_path="$BACKUP_DIR/$file"
    if [ ! -f "$full_path" ]; then
        MISSING_FILES+=("$file")
        print_error "Missing: $full_path"
    else
        size=$(du -h "$full_path" | cut -f1)
        print_info "Found: $file ($size)"
    fi
done

if [ ${#MISSING_FILES[@]} -gt 0 ]; then
    print_error "Cannot proceed! Missing ${#MISSING_FILES[@]} required backup files:"
    for file in "${MISSING_FILES[@]}"; do
        echo "  ❌ $BACKUP_DIR/$file"
    done
    echo ""
    print_error "Please ensure all required image files are present before running restoration."
    exit 1
fi

print_success "All required raw backup files found"
echo ""

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Unmount any mounted partitions from target disk
print_header "Unmounting Target Disk Partitions"
umount ${TARGET_DISK}* 2>/dev/null || true
swapoff ${TARGET_DISK}* 2>/dev/null || true
print_success "Target disk unmounted"
echo ""

# Wipe disk and create fresh partition table
print_header "Wiping Disk and Creating Partition Table"
print_info "Wiping partition table..."
wipefs -af "$TARGET_DISK" 2>/dev/null || true
dd if=/dev/zero of="$TARGET_DISK" bs=1M count=100 conv=fsync 2>/dev/null || true

print_info "Creating GPT partition table..."
parted -s "$TARGET_DISK" mklabel gpt &>/dev/null
print_success "GPT partition table created"
echo ""

# Define fixed partition sizes (in MiB) - 1GB App Version
print_header "Partition Layout Configuration (1GB App Version)"
EFI_SIZE=1536        # 1.5GB for EFI
ROOT_SIZE=30720      # 30GB for Root
HOME_SIZE=5120       # 5GB for Home (partition 3)
VAR_SIZE=15360       # 15GB for Var (partition 4)
VARLOG_SIZE=5120     # 5GB for /var/log
VARTMP_SIZE=2048     # 2GB for /var/tmp
VARAUDIT_SIZE=5120   # 5GB for /var/log/audit
EMBEDD_SIZE=2048     # 2GB for /embedd_d
APP_SIZE=1024        # 1GB for /app (REDUCED from 20GB)
TMP_SIZE=3072        # 3GB for /tmp
# EXTRA will use remaining space

print_info "Partition 1 (EFI): ${EFI_SIZE}MB (1.5GB)"
print_info "Partition 2 (Root /): ${ROOT_SIZE}MB (30GB)"
print_info "Partition 3 (Home): ${HOME_SIZE}MB (5GB)"
print_info "Partition 4 (Var): ${VAR_SIZE}MB (15GB)"
print_info "Partition 5 (/var/log): ${VARLOG_SIZE}MB (5GB)"
print_info "Partition 6 (/var/tmp): ${VARTMP_SIZE}MB (2GB)"
print_info "Partition 7 (/var/log/audit): ${VARAUDIT_SIZE}MB (5GB)"
print_info "Partition 8 (/embedd_d): ${EMBEDD_SIZE}MB (2GB)"
print_info "Partition 9 (/app): ${APP_SIZE}MB (1GB) ⚠️ REDUCED SIZE"
print_info "Partition 10 (/tmp): ${TMP_SIZE}MB (3GB)"
print_info "Partition 11 (/extra): Remaining space"
echo ""

# Calculate total disk size needed
TOTAL_FIXED=$((EFI_SIZE + ROOT_SIZE + VAR_SIZE + HOME_SIZE + VARLOG_SIZE + VARTMP_SIZE + VARAUDIT_SIZE + EMBEDD_SIZE + APP_SIZE + TMP_SIZE))
TOTAL_FIXED_GB=$((TOTAL_FIXED / 1024))
print_info "Total fixed partitions: ${TOTAL_FIXED}MB (${TOTAL_FIXED_GB}GB)"

# Get target disk size
disk_size_bytes=$(blockdev --getsize64 "$TARGET_DISK")
disk_size_mb=$((disk_size_bytes / 1024 / 1024))
disk_size_gb=$((disk_size_mb / 1024))
print_info "Target disk size: ${disk_size_mb}MB (${disk_size_gb}GB)"

# Check if disk is large enough
if [ $disk_size_mb -lt $TOTAL_FIXED ]; then
    print_error "Disk is too small! Need at least ${TOTAL_FIXED_GB}GB but disk is ${disk_size_gb}GB"
    exit 1
fi

remaining=$((disk_size_mb - TOTAL_FIXED - 2))  # Leave 2MB margin
remaining_gb=$((remaining / 1024))
print_info "Space for /extra partition: ${remaining}MB (${remaining_gb}GB)"
print_info "Space saved by 1GB app: 19GB (will be added to /extra)"
echo ""

# Read UUID mappings if available
print_header "Reading UUID Mappings"
declare -A PARTITION_UUIDS
declare -A PARTITION_FSTYPES
declare -A PARTITION_PARTUUIDS

if [ -f "$BACKUP_DIR/uuid_mapping.txt" ]; then
    while IFS=':' read -r part_num uuid fstype size_mb partuuid; do
        # Skip empty lines and comments
        [[ -z "$part_num" || "$part_num" =~ ^# ]] && continue
        
        PARTITION_UUIDS[$part_num]=$uuid
        PARTITION_FSTYPES[$part_num]=$fstype
        PARTITION_PARTUUIDS[$part_num]=$partuuid
        print_info "Partition $part_num: UUID=$uuid, FS=$fstype"
    done < "$BACKUP_DIR/uuid_mapping.txt"
else
    print_warn "uuid_mapping.txt not found, UUIDs will be auto-generated"
fi
echo ""

# Create partitions with optimal alignment
print_header "Creating Partitions with Optimal Alignment"

# Use parted's optimal alignment feature by specifying start and end in percentage
# This ensures partitions are aligned to physical sector boundaries

# First, we'll use a helper to create optimally aligned partitions
create_aligned_partition() {
    local part_num=$1
    local start_mb=$2
    local end_mb=$3
    local fs_type=$4
    local label=$5
    
    # Convert to sectors for better alignment (assuming 512 byte sectors)
    # Align to 2048 sectors (1MiB) boundaries
    local start_sector=$(( (start_mb * 2048 + 2047) / 2048 * 2048 ))
    local end_sector=$(( (end_mb * 2048) / 2048 * 2048 - 1 ))
    
    print_info "Creating partition $part_num ($label): ${start_mb}MiB - ${end_mb}MiB"
    
    parted -s -a optimal "$TARGET_DISK" mkpart primary "$fs_type" "${start_sector}s" "${end_sector}s" &>/dev/null || \
        parted -s "$TARGET_DISK" mkpart primary "$fs_type" "${start_mb}MiB" "${end_mb}MiB" &>/dev/null
}

# Calculate partition boundaries
p1_start=1
p1_end=$((p1_start + EFI_SIZE))

p2_start=$p1_end
p2_end=$((p2_start + ROOT_SIZE))

p3_start=$p2_end
p3_end=$((p3_start + HOME_SIZE))

p4_start=$p3_end
p4_end=$((p4_start + VAR_SIZE))

p5_start=$p4_end
p5_end=$((p5_start + VARLOG_SIZE))

p6_start=$p5_end
p6_end=$((p6_start + VARTMP_SIZE))

p7_start=$p6_end
p7_end=$((p7_start + VARAUDIT_SIZE))

p8_start=$p7_end
p8_end=$((p8_start + EMBEDD_SIZE))

p9_start=$p8_end
p9_end=$((p9_start + APP_SIZE))  # 1GB app partition

p10_start=$p9_end
p10_end=$((p10_start + TMP_SIZE))

p11_start=$p10_end
p11_end=$((disk_size_mb - 1))

# Create partitions with optimal alignment
create_aligned_partition 1 $p1_start $p1_end "fat32" "EFI"
parted -s "$TARGET_DISK" set 1 esp on &>/dev/null

create_aligned_partition 2 $p2_start $p2_end "ext4" "Root"
create_aligned_partition 3 $p3_start $p3_end "ext4" "Home"
create_aligned_partition 4 $p4_start $p4_end "ext4" "Var"
create_aligned_partition 5 $p5_start $p5_end "ext4" "/var/log"
create_aligned_partition 6 $p6_start $p6_end "ext4" "/var/tmp"
create_aligned_partition 7 $p7_start $p7_end "ext4" "/var/log/audit"
create_aligned_partition 8 $p8_start $p8_end "ext4" "/embedd_d"
create_aligned_partition 9 $p9_start $p9_end "ext4" "/app"
create_aligned_partition 10 $p10_start $p10_end "ext4" "/tmp"
create_aligned_partition 11 $p11_start $p11_end "ext4" "/extra"

print_success "All partitions created with optimal alignment"
echo ""

# Wait for kernel to update partition table
print_info "Waiting for partition table to update..."
sleep 2
partprobe "$TARGET_DISK" 2>/dev/null || true
sleep 2
echo ""

# Restore partition images
restore_partition_image() {
    local part_num=$1
    local label=$2
    local partition=$(get_partition_name $part_num)
    local image_file="$BACKUP_DIR/${label}.img"
    
    if [ ! -f "$image_file" ]; then
        print_warn "Image file $image_file not found, skipping"
        return
    fi
    
    if [ ! -b "$partition" ]; then
        print_error "Partition $partition not found"
        return 1
    fi
    
    print_header "Restoring: $label (Partition $part_num)"
    print_info "Image: $image_file → $partition"
    
    # Record start time
    local start_time=$(date '+%Y-%m-%d %H:%M:%S')
    print_info "Start time: $start_time"
    
    if command -v pv &> /dev/null; then
        pv -N "$label" -pterb "$image_file" | dd of="$partition" bs=16M conv=sync,noerror oflag=sync status=none iflag=fullblock
    else
        dd if="$image_file" of="$partition" bs=16M conv=sync,noerror oflag=sync status=progress iflag=fullblock
    fi
    sync
    
    # Record finish time
    local finish_time=$(date '+%Y-%m-%d %H:%M:%S')
    print_info "Finish time: $finish_time"
    
    # Calculate duration
    local start_seconds=$(date -d "$start_time" +%s)
    local finish_seconds=$(date -d "$finish_time" +%s)
    local duration=$((finish_seconds - start_seconds))
    local duration_formatted=$(printf '%02d:%02d:%02d' $((duration/3600)) $((duration%3600/60)) $((duration%60)))
    
    print_info "Duration: $duration_formatted (${duration} seconds)"
    print_success "Restored: $label"
    echo ""
}

print_header "Restoring Partition Images"
restore_partition_image 1 "efi"
restore_partition_image 2 "root"
restore_partition_image 3 "home"
restore_partition_image 4 "var"
echo ""

# Expand filesystems
print_header "Expanding Filesystems"
expand_filesystem() {
    local part_num=$1
    local label=$2
    local partition=$(get_partition_name $part_num)
    local fstype=${PARTITION_FSTYPES[$part_num]}
    
    [ ! -b "$partition" ] && return
    
    print_info "Expanding $label ($fstype)..."
    
    case $fstype in
        ext4|ext3|ext2)
            e2fsck -fy "$partition" >/dev/null 2>&1 || true
            resize2fs "$partition" >/dev/null 2>&1 && print_success "Expanded $label"
            ;;
    esac
}

expand_filesystem 2 "Root"
expand_filesystem 4 "Var"
echo ""

# Format additional partitions
print_header "Formatting Additional Partitions"
for part_num in {5..11}; do
    partition=$(get_partition_name $part_num)
    [ -b "$partition" ] && mkfs.ext4 -F "$partition" >/dev/null 2>&1 && print_info "Formatted partition $part_num"
done
echo ""

# Set UUIDs
print_header "Setting UUIDs"
for part_num in {1..11}; do
    partition=$(get_partition_name $part_num)
    uuid=${PARTITION_UUIDS[$part_num]}
    fstype=${PARTITION_FSTYPES[$part_num]}
    
    [ ! -b "$partition" ] || [ -z "$uuid" ] || [ "$uuid" = "unknown" ] && continue
    
    case $fstype in
        ext4|ext3|ext2)
            tune2fs -U "$uuid" "$partition" >/dev/null 2>&1 || true
            ;;
        vfat|fat32)
            fat_uuid=$(echo "$uuid" | tr -d '-' | cut -c1-8 | tr '[:lower:]' '[:upper:]')
            mlabel -i "$partition" -N "${fat_uuid}" >/dev/null 2>&1 || true
            ;;
    esac
    print_info "Set UUID for partition $part_num"
done
echo ""

# Mount and setup root
print_header "Setting Up Root Partition"
MOUNT_POINT="/mnt/restore_root"
mkdir -p "$MOUNT_POINT"
ROOT_PART=$(get_partition_name 2)

if mount "$ROOT_PART" "$MOUNT_POINT" 2>/dev/null; then
    print_success "Mounted root"
    
    # Create mount directories
    for dir in boot/efi home var var/log var/tmp var/log/audit embedd_d app tmp extra; do
        mkdir -p "$MOUNT_POINT/$dir"
    done
    
    # Set permissions
    chmod 1777 "$MOUNT_POINT/tmp" "$MOUNT_POINT/var/tmp" 2>/dev/null || true
    chmod 755 "$MOUNT_POINT/var/log" 2>/dev/null || true
    chmod 700 "$MOUNT_POINT/var/log/audit" 2>/dev/null || true
    
    # Clean up potential journal corruption before it starts
    print_info "Pre-cleaning journal directories..."
    if [ -d "$MOUNT_POINT/var/log/journal" ]; then
        # Remove any corrupted journal files from restored image
        find "$MOUNT_POINT/var/log/journal" -type f -name "*.journal*" -delete 2>/dev/null || true
        print_info "Cleaned journal directory in restored root"
    fi
    
    # Create fresh journal directory structure
    mkdir -p "$MOUNT_POINT/var/log/journal"
    chmod 2755 "$MOUNT_POINT/var/log/journal"
    print_success "Prepared clean journal directory"
    
    # Install fstab
    if [ -f "$BACKUP_DIR/fstab.backup" ]; then
        mkdir -p "$MOUNT_POINT/etc"
        cp "$BACKUP_DIR/fstab.backup" "$MOUNT_POINT/etc/fstab"
        print_success "Installed fstab"
    fi
    
    umount "$MOUNT_POINT"
fi

rmdir "$MOUNT_POINT" 2>/dev/null || true
echo ""

# Final verification
print_header "Verification"
lsblk "$TARGET_DISK" -o NAME,SIZE,FSTYPE,UUID
echo ""

# Summary
print_header "Restoration Complete (1GB App Version)"
print_success "All partitions restored successfully with optimal alignment!"
echo ""
print_info "Partition Summary:"
echo "  - /boot/efi (partition 1) - 1.5GB"
echo "  - / (partition 2) - 30GB"
echo "  - /home (partition 3) - 5GB"
echo "  - /var (partition 4) - 15GB"
echo "  - /var/log (partition 5) - 5GB"
echo "  - /var/tmp (partition 6) - 2GB"
echo "  - /var/log/audit (partition 7) - 5GB"
echo "  - /embedd_d (partition 8) - 2GB"
echo "  - /app (partition 9) - 1GB ⚠️ REDUCED SIZE"
echo "  - /tmp (partition 10) - 3GB"
echo "  - /extra (partition 11) - Remaining space (+19GB more than 20GB version)"
echo ""
print_warn "NOTE: /app partition is 1GB (reduced from 20GB)"
print_info "Extra 19GB has been added to /extra partition"
echo ""
print_success "Restoration complete!"

# Output specific message for installer detection
echo "Restoration completed successfully"

