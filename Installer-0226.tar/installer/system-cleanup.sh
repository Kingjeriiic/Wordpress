#!/bin/bash
# System Cleanup Script for ETAP Installer
# Cleans history files, Chromium data, and sets up log directories
# Usage: ./system-cleanup.sh <target_disk>

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check if target disk is provided
if [ $# -ne 1 ]; then
    echo "Usage: $0 <target_disk>"
    echo "Example: $0 /dev/sdb"
    exit 1
fi

TARGET_DISK="$1"

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Validate target disk
if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

# Safety check: Exclude sda disk
if [[ "$TARGET_DISK" == "/dev/sda"* ]]; then
    print_error "SAFETY ERROR: sda disk is excluded for safety!"
    print_error "sda is typically the installer/system disk."
    print_error "Supported disks: sdb, sdc, nvme*"
    exit 1
fi

# Get root partition (partition 2) and extra partition (partition 11)
ROOT_PART=$(get_partition_name 2)
EXTRA_PART=$(get_partition_name 11)

if [ ! -b "$ROOT_PART" ]; then
    print_error "Root partition $ROOT_PART not found."
    print_error "Make sure the disk has been properly partitioned and restored."
    exit 1
fi

if [ ! -b "$EXTRA_PART" ]; then
    print_error "Extra partition $EXTRA_PART not found."
    print_error "Make sure the disk has been properly partitioned."
    exit 1
fi

# Banner
print_header "ETAP System Cleanup"
echo ""
echo "Target disk: $TARGET_DISK"
echo "Root partition: $ROOT_PART"
echo "Extra partition: $EXTRA_PART"
echo ""

# Mount root partition
TARGET_ROOT="/mnt/system_cleanup"
mkdir -p "$TARGET_ROOT"

print_info "Mounting root partition..."
if mount -o rw "$ROOT_PART" "$TARGET_ROOT" 2>/dev/null; then
    print_success "Mounted root partition at $TARGET_ROOT (read-write)"
else
    print_error "Failed to mount root partition $ROOT_PART"
    rmdir "$TARGET_ROOT" 2>/dev/null || true
    exit 1
fi

# Clean history files
print_header "Cleaning History Files"
print_info "[$(date)] Cleaning history..."

# Bash history cleanup
BASH_HISTORY_FILES=(
    "$TARGET_ROOT/root/.bash_history"
    "$TARGET_ROOT/home/etdev/.bash_history"
    "$TARGET_ROOT/home/etkiosk/.bash_history"
)

for hist_file in "${BASH_HISTORY_FILES[@]}"; do
    if [ -f "$hist_file" ] || [ -d "$(dirname "$hist_file")" ]; then
        echo "" > "$hist_file" 2>/dev/null || true
        print_info "Cleared: $(basename "$(dirname "$hist_file")")/.bash_history"
    fi
done

# MySQL history cleanup
MYSQL_HISTORY_FILES=(
    "$TARGET_ROOT/root/.mysql_history"
    "$TARGET_ROOT/home/etdev/.mysql_history"
    "$TARGET_ROOT/home/etkiosk/.mysql_history"
)

for hist_file in "${MYSQL_HISTORY_FILES[@]}"; do
    if [ -f "$hist_file" ] || [ -d "$(dirname "$hist_file")" ]; then
        echo "" > "$hist_file" 2>/dev/null || true
        print_info "Cleared: $(basename "$(dirname "$hist_file")")/.mysql_history"
    fi
done

print_success "History files cleaned"
echo ""

# Clean Chromium singleton files
print_header "Cleaning Chromium Data"
print_info "Removing Chromium singleton files..."

# More comprehensive cleanup - remove all Chromium singleton and lock files
CHROMIUM_CLEANUP_PATTERNS=(
    "$TARGET_ROOT/home/*/snap/chromium/common/chromium/Singleton*"
    "$TARGET_ROOT/home/*/.config/chromium/Singleton*"
    "$TARGET_ROOT/root/snap/chromium/common/chromium/Singleton*"
    "$TARGET_ROOT/root/.config/chromium/Singleton*"
)

for pattern in "${CHROMIUM_CLEANUP_PATTERNS[@]}"; do
    for chromium_path in $pattern; do
        if [ -e "$chromium_path" ]; then
            rm -rf "$chromium_path" 2>/dev/null || true
            relative_path=$(echo "$chromium_path" | sed "s|$TARGET_ROOT||")
            print_info "Removed: $relative_path"
        fi
    done
done

# Also remove specific singleton files by name
SINGLETON_FILES=(
    "SingletonCookie"
    "SingletonLock" 
    "SingletonSocket"
)

CHROMIUM_DIRS=(
    "$TARGET_ROOT/home/etkiosk/snap/chromium/common/chromium"
    "$TARGET_ROOT/home/etdev/snap/chromium/common/chromium"
    "$TARGET_ROOT/home/etkiosk/.config/chromium"
    "$TARGET_ROOT/home/etdev/.config/chromium"
    "$TARGET_ROOT/root/snap/chromium/common/chromium"
    "$TARGET_ROOT/root/.config/chromium"
)

for chromium_dir in "${CHROMIUM_DIRS[@]}"; do
    if [ -d "$chromium_dir" ]; then
        for singleton_file in "${SINGLETON_FILES[@]}"; do
            if [ -f "$chromium_dir/$singleton_file" ]; then
                rm -f "$chromium_dir/$singleton_file" 2>/dev/null || true
                relative_path=$(echo "$chromium_dir/$singleton_file" | sed "s|$TARGET_ROOT||")
                print_info "Removed: $relative_path"
            fi
        done
    fi
done

print_success "Chromium data cleaned"
echo ""

# Unmount root partition
print_info "Unmounting root partition..."
if umount "$TARGET_ROOT" 2>/dev/null; then
    print_success "Unmounted root partition"
else
    print_warn "Could not unmount cleanly, but changes were saved"
fi

rmdir "$TARGET_ROOT" 2>/dev/null || true

# Mount extra partition and create log directories
print_header "Setting Up Log Directories"
EXTRA_MOUNT="/mnt/extra_cleanup"
mkdir -p "$EXTRA_MOUNT"

print_info "Mounting extra partition..."
if mount "$EXTRA_PART" "$EXTRA_MOUNT" 2>/dev/null; then
    print_success "Mounted extra partition at $EXTRA_MOUNT"
    
    print_info "[$(date)] Creating log files..."
    
    print_header "Creating /extra/logs Directory Structure"
    
    ## Steps: Create /extra/logs/kiosk
    # 1. Create the directory
    print_info "Step 1: Creating /extra/logs/kiosk directory..."
    mkdir -p "$EXTRA_MOUNT/logs/kiosk" 2>/dev/null || true
    if [ -d "$EXTRA_MOUNT/logs/kiosk" ]; then
        # 2. Set ownership to www-data:www-data
        print_info "Step 2: Setting ownership to www-data:www-data..."
        if id www-data &>/dev/null; then
            chown www-data:www-data "$EXTRA_MOUNT/logs/kiosk" 2>/dev/null || true
            # 3. Set permissions to 755 (drwxr-xr-x)
            print_info "Step 3: Setting permissions to 755 (drwxr-xr-x)..."
            chmod 755 "$EXTRA_MOUNT/logs/kiosk" 2>/dev/null || true
            print_success "Created: /extra/logs/kiosk (www-data:www-data, 755)"
        else
            chown root:root "$EXTRA_MOUNT/logs/kiosk" 2>/dev/null || true
            chmod 755 "$EXTRA_MOUNT/logs/kiosk" 2>/dev/null || true
            print_warn "Created: /extra/logs/kiosk (root:root, 755) - www-data user not found"
        fi
    else
        print_error "Failed to create /extra/logs/kiosk directory"
    fi
    
    print_info "===== ===== ===== ===== ===== ===== ===== ===== ===== ====="
    
    ## Steps: Create /extra/logs/.vladimir
    # 1. Create the directory
    print_info "Step 1: Creating /extra/logs/.vladimir directory..."
    mkdir -p "$EXTRA_MOUNT/logs/.vladimir" 2>/dev/null || true
    if [ -d "$EXTRA_MOUNT/logs/.vladimir" ]; then
        # 2. Set ownership to root:root
        print_info "Step 2: Setting ownership to root:root..."
        chown root:root "$EXTRA_MOUNT/logs/.vladimir" 2>/dev/null || true
        # 3. Set permissions to 755 (drwxr-xr-x)
        print_info "Step 3: Setting permissions to 755 (drwxr-xr-x)..."
        chmod 755 "$EXTRA_MOUNT/logs/.vladimir" 2>/dev/null || true
        print_success "Created: /extra/logs/.vladimir (root:root, 755)"
    else
        print_error "Failed to create /extra/logs/.vladimir directory"
    fi
    
    print_info "===== ===== ===== ===== ===== ===== ===== ===== ===== ====="
    
    ## Steps: Create /extra/logs/apache2
    # 1. Create the directory
    print_info "Step 1: Creating /extra/logs/apache2 directory..."
    mkdir -p "$EXTRA_MOUNT/logs/apache2" 2>/dev/null || true
    if [ -d "$EXTRA_MOUNT/logs/apache2" ]; then
        # 2. Set ownership to root:root
        print_info "Step 2: Setting ownership to root:root..."
        chown root:root "$EXTRA_MOUNT/logs/apache2" 2>/dev/null || true
        # 3. Set permissions to 755 (drwxr-xr-x)
        print_info "Step 3: Setting permissions to 755 (drwxr-xr-x)..."
        chmod 755 "$EXTRA_MOUNT/logs/apache2" 2>/dev/null || true
        print_success "Created: /extra/logs/apache2 (root:root, 755)"
    else
        print_error "Failed to create /extra/logs/apache2 directory"
    fi
    
    print_success "Log directories created"
    
    # Unmount extra partition
    print_info "[$(date)] Unmounting extra partition..."
    if umount "$EXTRA_MOUNT" 2>/dev/null; then
        print_success "Unmounted extra partition"
    else
        print_warn "Could not unmount extra partition cleanly"
    fi
    
else
    print_error "Failed to mount extra partition $EXTRA_PART"
fi

rmdir "$EXTRA_MOUNT" 2>/dev/null || true

# Summary
print_header "System Cleanup Complete"
print_success "System cleanup completed successfully!"
echo ""
print_info "Cleanup Summary:"
echo "  ✅ Bash history files cleared (root, etdev, etkiosk)"
echo "  ✅ MySQL history files cleared (root, etdev, etkiosk)"
echo "  ✅ Chromium singleton files removed (all users)"
echo "  ✅ Log directories created in /extra:"
echo "     - /logs/kiosk (www-data:www-data, 755)"
echo "     - /logs/.vladimir (root:root, 755)"
echo "     - /logs/apache2 (root:root, 755)"
echo ""
print_info "The system is now clean and ready for deployment."
print_success "System cleanup completed successfully!"

# Output specific message for installer detection
echo "System cleanup completed successfully"
