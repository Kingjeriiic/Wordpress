#!/bin/bash
# Fix Networking Script for ETAP Installer
# Ensures proper networking setup after installation
# Usage: ./fix-networking.sh <target_disk>

set -euo pipefail

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Print functions
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Check if target disk is provided
if [ $# -ne 1 ]; then
    echo "Usage: $0 <target_disk>"
    echo "Example: $0 /dev/sdb"
    exit 1
fi

TARGET_DISK="$1"

# Get partition naming convention
get_partition_name() {
    local part_num=$1
    if [[ "$TARGET_DISK" == *"nvme"* ]] || [[ "$TARGET_DISK" == *"mmcblk"* ]]; then
        echo "${TARGET_DISK}p${part_num}"
    else
        echo "${TARGET_DISK}${part_num}"
    fi
}

# Validate target disk
if [ ! -b "$TARGET_DISK" ]; then
    print_error "Disk $TARGET_DISK not found."
    exit 1
fi

# Safety check: Exclude sda disk
if [[ "$TARGET_DISK" == "/dev/sda"* ]]; then
    print_error "SAFETY ERROR: sda disk is excluded for safety!"
    print_error "sda is typically the installer/system disk."
    print_error "Supported disks: sdb, sdc, nvme*"
    exit 1
fi

# Get root partition (partition 2)
ROOT_PART=$(get_partition_name 2)

if [ ! -b "$ROOT_PART" ]; then
    print_error "Root partition $ROOT_PART not found."
    print_error "Make sure the disk has been properly partitioned and restored."
    exit 1
fi

# Banner
print_header "ETAP Networking Fix"
echo ""
echo "Target disk: $TARGET_DISK"
echo "Root partition: $ROOT_PART"
echo ""

# Mount root partition
MOUNT_POINT="/mnt/networking_fix"
mkdir -p "$MOUNT_POINT"

print_info "Mounting root partition..."
if mount "$ROOT_PART" "$MOUNT_POINT" 2>/dev/null; then
    print_success "Mounted root partition at $MOUNT_POINT"
else
    print_error "Failed to mount root partition $ROOT_PART"
    rmdir "$MOUNT_POINT" 2>/dev/null || true
    exit 1
fi

print_header "Configuring Network Services"

# Check current networking setup
print_info "Checking current networking configuration..."

# Check if NetworkManager is installed
if [ -f "$MOUNT_POINT/usr/bin/NetworkManager" ] || [ -f "$MOUNT_POINT/usr/sbin/NetworkManager" ]; then
    print_info "NetworkManager is installed"
    NETWORKMANAGER_INSTALLED=true
else
    print_warn "NetworkManager is not installed"
    NETWORKMANAGER_INSTALLED=false
fi

# Check if systemd-networkd is active
if [ -f "$MOUNT_POINT/lib/systemd/system/systemd-networkd.service" ]; then
    print_info "systemd-networkd is available"
    SYSTEMD_NETWORKD_AVAILABLE=true
else
    print_warn "systemd-networkd is not available"
    SYSTEMD_NETWORKD_AVAILABLE=false
fi

# Create NetworkManager configuration if not present
if [ "$NETWORKMANAGER_INSTALLED" = false ]; then
    print_info "Setting up systemd-networkd as primary network manager..."
    
    # Enable systemd-networkd and systemd-resolved
    mkdir -p "$MOUNT_POINT/etc/systemd/system/multi-user.target.wants"
    mkdir -p "$MOUNT_POINT/etc/systemd/system/sockets.target.wants"
    mkdir -p "$MOUNT_POINT/etc/systemd/system/network-online.target.wants"
    
    # Create symlinks to enable services
    if [ -f "$MOUNT_POINT/lib/systemd/system/systemd-networkd.service" ]; then
        ln -sf /lib/systemd/system/systemd-networkd.service "$MOUNT_POINT/etc/systemd/system/multi-user.target.wants/systemd-networkd.service" 2>/dev/null || true
        print_info "Enabled systemd-networkd.service"
    fi
    
    if [ -f "$MOUNT_POINT/lib/systemd/system/systemd-resolved.service" ]; then
        ln -sf /lib/systemd/system/systemd-resolved.service "$MOUNT_POINT/etc/systemd/system/multi-user.target.wants/systemd-resolved.service" 2>/dev/null || true
        print_info "Enabled systemd-resolved.service"
    fi
    
    if [ -f "$MOUNT_POINT/lib/systemd/system/systemd-networkd-wait-online.service" ]; then
        ln -sf /lib/systemd/system/systemd-networkd-wait-online.service "$MOUNT_POINT/etc/systemd/system/network-online.target.wants/systemd-networkd-wait-online.service" 2>/dev/null || true
        print_info "Enabled systemd-networkd-wait-online.service"
    fi
    
    # Create basic network configuration for DHCP
    mkdir -p "$MOUNT_POINT/etc/systemd/network"
    
    # Create DHCP configuration for all ethernet interfaces
    cat > "$MOUNT_POINT/etc/systemd/network/20-dhcp.network" << 'EOF'
[Match]
Name=en*
Name=eth*

[Network]
DHCP=yes
IPForward=no

[DHCP]
UseDomains=yes
EOF
    
    print_success "Created DHCP network configuration"
    
    # Create resolved configuration
    mkdir -p "$MOUNT_POINT/etc/systemd/resolved.conf.d"
    cat > "$MOUNT_POINT/etc/systemd/resolved.conf.d/dns.conf" << 'EOF'
[Resolve]
DNS=8.8.8.8 8.8.4.4
FallbackDNS=1.1.1.1 1.0.0.1
Domains=~.
DNSSEC=no
DNSOverTLS=no
EOF
    
    print_success "Created DNS resolver configuration"
    
    # Create symlink for /etc/resolv.conf
    rm -f "$MOUNT_POINT/etc/resolv.conf"
    ln -sf /run/systemd/resolve/resolv.conf "$MOUNT_POINT/etc/resolv.conf" 2>/dev/null || true
    print_info "Configured /etc/resolv.conf symlink"
    
else
    print_info "NetworkManager is installed, configuring NetworkManager..."
    
    # Enable NetworkManager
    mkdir -p "$MOUNT_POINT/etc/systemd/system/multi-user.target.wants"
    mkdir -p "$MOUNT_POINT/etc/systemd/system/network-online.target.wants"
    
    if [ -f "$MOUNT_POINT/lib/systemd/system/NetworkManager.service" ]; then
        ln -sf /lib/systemd/system/NetworkManager.service "$MOUNT_POINT/etc/systemd/system/multi-user.target.wants/NetworkManager.service" 2>/dev/null || true
        print_info "Enabled NetworkManager.service"
    fi
    
    if [ -f "$MOUNT_POINT/lib/systemd/system/NetworkManager-wait-online.service" ]; then
        ln -sf /lib/systemd/system/NetworkManager-wait-online.service "$MOUNT_POINT/etc/systemd/system/network-online.target.wants/NetworkManager-wait-online.service" 2>/dev/null || true
        print_info "Enabled NetworkManager-wait-online.service"
    fi
    
    # Disable systemd-networkd if NetworkManager is used
    rm -f "$MOUNT_POINT/etc/systemd/system/multi-user.target.wants/systemd-networkd.service" 2>/dev/null || true
    rm -f "$MOUNT_POINT/etc/systemd/system/network-online.target.wants/systemd-networkd-wait-online.service" 2>/dev/null || true
    print_info "Disabled conflicting systemd-networkd services"
    
    # Create basic NetworkManager configuration
    mkdir -p "$MOUNT_POINT/etc/NetworkManager/conf.d"
    cat > "$MOUNT_POINT/etc/NetworkManager/conf.d/10-globally-managed-devices.conf" << 'EOF'
[keyfile]
unmanaged-devices=none
EOF
    
    print_success "Created NetworkManager configuration"
fi

# Ensure networking is enabled at boot
print_info "Ensuring networking is enabled at boot..."

# Enable networking service if it exists
if [ -f "$MOUNT_POINT/lib/systemd/system/networking.service" ]; then
    mkdir -p "$MOUNT_POINT/etc/systemd/system/multi-user.target.wants"
    ln -sf /lib/systemd/system/networking.service "$MOUNT_POINT/etc/systemd/system/multi-user.target.wants/networking.service" 2>/dev/null || true
    print_info "Enabled networking.service"
fi

# Create a script to fix networking on first boot if needed
print_info "Creating first-boot networking fix script..."
mkdir -p "$MOUNT_POINT/usr/local/bin"
cat > "$MOUNT_POINT/usr/local/bin/fix-networking-first-boot.sh" << 'EOF'
#!/bin/bash
# Fix networking on first boot
# This script runs once on first boot to ensure networking is working

echo "$(date): Running first-boot networking fixes..."

# Restart networking services
if systemctl is-active --quiet NetworkManager; then
    echo "$(date): NetworkManager is active"
elif systemctl is-enabled --quiet NetworkManager 2>/dev/null; then
    echo "$(date): Starting NetworkManager..."
    systemctl start NetworkManager
elif systemctl is-enabled --quiet systemd-networkd 2>/dev/null; then
    echo "$(date): Starting systemd-networkd..."
    systemctl start systemd-networkd
    systemctl start systemd-resolved
fi

# Wait for network to come up
echo "$(date): Waiting for network connectivity..."
for i in {1..30}; do
    if ping -c 1 8.8.8.8 >/dev/null 2>&1; then
        echo "$(date): Network connectivity established"
        break
    fi
    sleep 2
done

# Remove this script after running
rm -f /usr/local/bin/fix-networking-first-boot.sh
rm -f /etc/systemd/system/fix-networking-first-boot.service
systemctl daemon-reload

echo "$(date): First-boot networking fixes completed"
exit 0
EOF

chmod +x "$MOUNT_POINT/usr/local/bin/fix-networking-first-boot.sh"

# Create systemd service to run the fix on first boot
mkdir -p "$MOUNT_POINT/etc/systemd/system"
cat > "$MOUNT_POINT/etc/systemd/system/fix-networking-first-boot.service" << 'EOF'
[Unit]
Description=Fix networking on first boot
After=multi-user.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/fix-networking-first-boot.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

# Enable the service to run on next boot
mkdir -p "$MOUNT_POINT/etc/systemd/system/multi-user.target.wants"
ln -sf /etc/systemd/system/fix-networking-first-boot.service "$MOUNT_POINT/etc/systemd/system/multi-user.target.wants/fix-networking-first-boot.service" 2>/dev/null || true

print_success "Created first-boot networking fix service"

# Unmount
print_info "Unmounting root partition..."
if umount "$MOUNT_POINT" 2>/dev/null; then
    print_success "Unmounted root partition"
else
    print_warn "Could not unmount cleanly, but changes were saved"
fi

rmdir "$MOUNT_POINT" 2>/dev/null || true

# Summary
print_header "Networking Fix Complete"
print_success "Networking configuration has been fixed!"
echo ""
print_info "Configuration Summary:"
if [ "$NETWORKMANAGER_INSTALLED" = true ]; then
    echo "  ✅ NetworkManager enabled and configured"
    echo "  ✅ Conflicting services disabled"
else
    echo "  ✅ systemd-networkd enabled and configured"
    echo "  ✅ systemd-resolved enabled and configured"
    echo "  ✅ DHCP configuration created"
fi
echo "  ✅ First-boot networking fix service created"
echo "  ✅ DNS configuration updated"
echo ""
print_info "The system will have proper networking after the next boot."
print_success "Networking fix completed successfully!"

# Output specific message for installer detection
echo "Networking fix completed successfully"
