#!/bin/bash

# ETAP Installer Runner
# This script sets up and runs the ETAP installer

echo "ETAP Installer Setup"
echo "===================="

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "ERROR: This installer must be run as root"
    echo "Please run: sudo ./run-installer.sh"
    exit 1
fi

# Make scripts executable
chmod +x installer.sh
chmod +x restoration-script.sh
chmod +x vpn-restoration.sh

# Check for required directories
echo "Checking required directories..."

if [ ! -d "/extra/os/base-images" ]; then
    echo "WARNING: /extra/os/base-images directory not found"
    echo "This directory should contain:"
    echo "  - efi.img.gz"
    echo "  - root.img.gz" 
    echo "  - var.img.gz"
    echo "  - home.img.gz"
    echo "  - uuid_mapping.txt (optional)"
    echo ""
fi

if [ ! -d "/extra/os/app-images" ]; then
    echo "WARNING: /extra/os/app-images directory not found"
    echo "This directory should contain app image files (.img or .img.gz)"
    echo ""
fi

# Check for dialog
if ! command -v dialog &> /dev/null; then
    echo "Installing dialog package..."
    apt-get update && apt-get install -y dialog
fi

echo "Starting ETAP Installer..."
echo ""

# Run the installer
./installer.sh

echo ""
echo "ETAP Installer finished."
