#!/bin/bash

# ETAP Installer Utilities
# Helper functions and utilities for the ETAP installer

# Function to check system requirements
check_requirements() {
    echo "Checking ETAP Installer Requirements..."
    echo "======================================"
    
    local errors=0
    
    # Check if running as root
    if [ "$EUID" -ne 0 ]; then
        echo "❌ ERROR: Must run as root"
        ((errors++))
    else
        echo "✅ Running as root"
    fi
    
    # Check for required commands
    local required_commands=("dialog" "parted" "lsblk" "mount" "umount" "dd" "gzip" "expect")
    for cmd in "${required_commands[@]}"; do
        if command -v "$cmd" &> /dev/null; then
            echo "✅ Command available: $cmd"
        else
            echo "❌ Missing command: $cmd"
            ((errors++))
        fi
    done
    
    # Check for required directories
    if [ -d "/extra/os/base-images" ]; then
        echo "✅ Base images directory exists: /extra/os/base-images"
        
        # Check for required image files
        local required_images=("efi.img.gz" "root.img.gz" "var.img.gz" "home.img.gz")
        for image in "${required_images[@]}"; do
            if [ -f "/extra/os/base-images/$image" ]; then
                local size=$(du -h "/extra/os/base-images/$image" | cut -f1)
                echo "  ✅ $image ($size)"
            else
                echo "  ❌ Missing: $image"
                ((errors++))
            fi
        done
    else
        echo "❌ Missing directory: /extra/os/base-images"
        ((errors++))
    fi
    
    if [ -d "/extra/os/app-images" ]; then
        local app_count=$(find /extra/os/app-images -name "*.img" -o -name "*.img.gz" 2>/dev/null | wc -l)
        echo "✅ App images directory exists: /extra/os/app-images ($app_count images)"
    else
        echo "⚠️  App images directory not found: /extra/os/app-images (optional)"
    fi
    
    # Check available disks
    echo ""
    echo "Available Installation Disks:"
    echo "============================="
    local disk_count=0
    while IFS= read -r line; do
        if [[ $line == /dev/sdb* ]] || [[ $line == /dev/sdc* ]] || [[ $line == /dev/nvme* ]]; then
            local size=$(lsblk -b -d -o SIZE "$line" 2>/dev/null | tail -n1)
            if [[ -n $size ]]; then
                local size_gb=$((size / 1024 / 1024 / 1024))
                echo "✅ $line (${size_gb}GB)"
                ((disk_count++))
            fi
        fi
    done < <(lsblk -d -n -o NAME | sed 's/^/\/dev\//')
    
    if [ $disk_count -eq 0 ]; then
        echo "❌ No suitable installation disks found (sdb, sdc, nvme*)"
        ((errors++))
    fi
    
    echo ""
    if [ $errors -eq 0 ]; then
        echo "✅ All requirements met! Ready to run installer."
        return 0
    else
        echo "❌ Found $errors error(s). Please fix before running installer."
        return 1
    fi
}

# Function to create sample directory structure
create_sample_structure() {
    echo "Creating sample directory structure..."
    
    # Create base directories
    mkdir -p /extra/os/base-images
    mkdir -p /extra/os/app-images
    
    echo "Created directories:"
    echo "  /extra/os/base-images (for partition images)"
    echo "  /extra/os/app-images (for application images)"
    echo ""
    echo "Please place your backup files in these directories:"
    echo "  - efi.img.gz"
    echo "  - root.img.gz"
    echo "  - var.img.gz"
    echo "  - home.img.gz"
    echo "  - uuid_mapping.txt (optional)"
    echo "  - fstab.backup (optional)"
}

# Function to show installer status
show_status() {
    echo "ETAP Installer Status"
    echo "===================="
    echo "Version: 1.0"
    echo "Features:"
    echo "  ✅ 3-screen dialog interface"
    echo "  ✅ 11-partition restoration layout"
    echo "  ✅ App image selection with search"
    echo "  ✅ VPN configuration integration"
    echo "  ✅ IP address display (bottom right)"
    echo "  ✅ Alphabetical sorting"
    echo "  ✅ Professional multi-dialog workflow"
    echo ""
    echo "Supported disks: sdb, sdc, nvme* (sda excluded for safety)"
    echo "Partition layout: EFI(1.5GB) + Root(30GB) + Var(10GB) + Home(5GB) + 7 additional partitions"
}

# Function to install missing dependencies
install_dependencies() {
    echo "Installing ETAP Installer dependencies..."
    
    # Update package list
    apt-get update
    
    # Install required packages
    local packages=("dialog" "parted" "pv" "pigz" "bc" "expect")
    for package in "${packages[@]}"; do
        if ! dpkg -l | grep -q "^ii  $package "; then
            echo "Installing $package..."
            apt-get install -y "$package"
        else
            echo "$package already installed"
        fi
    done
    
    echo "Dependencies installation complete!"
}

# Main function
main() {
    case "${1:-}" in
        "check"|"requirements")
            check_requirements
            ;;
        "setup"|"create")
            create_sample_structure
            ;;
        "status"|"info")
            show_status
            ;;
        "deps"|"dependencies")
            install_dependencies
            ;;
        *)
            echo "ETAP Installer Utilities"
            echo "======================="
            echo "Usage: $0 [command]"
            echo ""
            echo "Commands:"
            echo "  check        - Check system requirements"
            echo "  setup        - Create sample directory structure"
            echo "  status       - Show installer information"
            echo "  deps         - Install missing dependencies"
            echo ""
            echo "Examples:"
            echo "  $0 check     - Verify system is ready for installation"
            echo "  $0 setup     - Create /extra/os directories"
            echo "  $0 deps      - Install required packages"
            ;;
    esac
}

# Run main function with all arguments
main "$@"
